Takanas HaShavin Reader source, Simanim 1-13. Final source-collated upload candidate.
Upload Takanat_HaShavin.json to sources/akiva/Takanat_HaShavin.json after checking main has not changed.
29 distinct corrected notes, 36 correction operations, including 10 precise relocations.
All 1891 Simanim 1-13 footnote markers, 31 Hebrew-side markers, original Hebrew,
all English text outside notes, data-ref links, and Simanim 10-15 preserved.
Unresolved: not every note independently checked against source, and 186 note clusters still need review.
This ZIP is a GitHub source replacement ZIP, not the separately generated offline Reader download ZIP.
