Takanas HaShavin Reader Source Upload Candidate - October 29, 2026
Replacement target: sources/akiva/Takanat_HaShavin.json
This is NOT the older offline reader ZIP: this ZIP contains the complete updated GitHub Reader source JSON.
Sections 10-13 are preserved from the live Reader; Introduction and sections 14-15 are unchanged.
28 editing operations across 21 footnotes (10 relocations), sourced from original checked audits.
Unresolved: additional checks on 186 crowded clusters and several parallel citations.
Do not claim that all 1,891 marker sources in Simanim 1-13 have been independently checked.
