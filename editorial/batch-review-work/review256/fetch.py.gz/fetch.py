import json, urllib.request, urllib.parse, concurrent.futures, sys
from pathlib import Path
P=Path(__file__).with_name('primary.json')
D=json.loads(P.read_text()) if P.exists() else {}
def fetch(ref):
    url='https://www.sefaria.org/api/texts/'+urllib.parse.quote(ref.replace(' ','_'),safe=':,')+'?context=0&pad=0'
    try:
        with urllib.request.urlopen(url,timeout=15) as response:
            data=json.load(response)
        data['_retrievedFrom']=url
        return ref,data
    except Exception as exc:
        return ref,{'error':str(exc),'url':url}
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
    for ref,data in pool.map(fetch,[r for r in sys.argv[1:] if r not in D or 'error' in D[r]]):
        D[ref]=data
        P.write_text(json.dumps(D,ensure_ascii=False,indent=2)+'\n')
        print(ref, data.get('error') or data.get('ref'),flush=True)
