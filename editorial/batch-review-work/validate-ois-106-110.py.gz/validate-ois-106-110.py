import json,re,html,hashlib
from pathlib import Path
from collections import Counter
ROOT=Path('/workspace/scratch/f85ae98f1669');SITE=ROOT/'tmp/batch-engineering/current-site';P=ROOT/'review-work/ois-106-110.json'
data=json.loads(P.read_text());cache=json.loads((ROOT/'review-work/ois106-primary.json').read_text())
catalog=json.loads((SITE/'mcp-data/catalog.json').read_text())['books'];connections=json.loads((SITE/'library/connected-ideas/catalog.json').read_text())['records']
def plain(t):return html.unescape(re.sub('<[^>]*>','',t))
def clean(t):return re.sub(r'\s+',' ',plain(t)).strip()
def norm(t):return re.sub(r'[^\u05d0-\u05ea]','',t)
def strings(x):
 if isinstance(x,str):yield x
 elif isinstance(x,list):
  for y in x:yield from strings(y)
 elif isinstance(x,dict):
  for y in x.values():yield from strings(y)
results=[];overlaps=[]
for e in data['entries']:
 rows=json.loads((SITE/f"library/data/tzidkat-hatzadik/{e['section']-1}.json").read_text());r=next(r for r in rows if r['n']==e['rowN'])
 assert plain(r['p'][e['phraseIndex']][0]).startswith(e['heAnchorPrefix']),e['id']
 assert e['heCharOffset']==len(e['heAnchorPrefix']),e['id']
 assert all(e[k] for k in ('ref','he','en','context','sourceEvidence')),e['id']
 ev=e['sourceEvidence'][0]
 assert ev['he']==e['he'] and ev['en']==e['en'],e['id']
 assert ev['heSha256']==hashlib.sha256(e['he'].encode()).hexdigest(),e['id']
 if e.get('readerRef'):
  f=SITE/ev['canonicalSourceFile'];source=next(r for r in json.loads(f.read_text())['paras'] if r['r']==e['readerRef'])
  h=clean(' '.join(x[0] for x in source['p']) if'p'in source else source['t'])
  assert e['he'] in h,e['id'];book=next(b for b in catalog if b['slug']==f.stem)
  assert e['url']=='#/read/'+book['sections'][source['s']]['ref'].replace(' ','_'),e['id']
 elif e.get('citationOnly'):
  assert all(k not in e for k in ['url','readerRef','openExternal','connectionsUrl']),e['id']
  orig=json.loads((ROOT/ev['verificationFile']).read_text())
  assert e['he']==orig['he'] and e['en']==orig['en'],e['id']
  assert ev.get('originalScanCatalogURL') and ev.get('originalPublicOCRURL'),e['id']
 else:
  assert e['url'].startswith('https://'),e['id']
  assert ev.get('retrievalURL') or ev.get('webRef'),e['id']
  if ev.get('cacheRef'):
   sh=' '.join(strings(cache[ev['cacheRef']]['he']));assert norm(e['he']) in norm(sh),e['id']
  elif ev.get('verificationFile'):
   original=json.loads((ROOT/ev['verificationFile']).read_text());assert any(norm(e['he']) in norm(s['he']) for s in original['sources']),e['id']
 existing=[f for r in rows for f in r.get('footnotes',[])]+[r for r in connections if r.get('originRef','').startswith(f"Tzidkat HaTzadik {e['section']}:") or r.get('originRef')==f"Tzidkat HaTzadik {e['section']}"]
 nh=norm(e['he']);overlap=any(nh in norm(s) for old in existing for s in strings(old) if len(norm(s))>=len(nh))
 if overlap:overlaps.append(e['id'])
 visible=' '.join(e.get(k,'') for k in ('ref','url','he','en','context'))
 assert not re.search(r'Biur|Meshulav|Mishulav|Neimos|Ne.imot|\.pdf(?:$|[?#])',visible,re.I),e['id']
 results.append({'section':e['section'],'id':e['id'],'anchor':'exact','source':'verified','canonicalHebrew':'exact-contiguous' if e.get('readerRef') else None,'destinationDuplicate':overlap,'citationOnly':e.get('citationOnly',False)})
assert not overlaps,overlaps
assert len(set((e['section'],e['id']) for e in data['entries']))==len(data['entries'])
assert data['reviewedSections']==list(range(106,111))
out={'status':'passed','entries':len(results),'counts':dict(Counter(e['section'] for e in data['entries'])),'internalCanonicalQuotations':sum(bool(e.get('readerRef')) for e in data['entries']),'checks':results,'proposalSha256':hashlib.sha256(P.read_bytes()).hexdigest()}
(ROOT/'review-work/ois-106-110-validation.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='checks'}))
