exec(open('/workspace/scratch/f85ae98f1669/review-work/build-ois-106-110.py').read())
E.sort(key=lambda e:(e['section'],e['rowN'],e['phraseIndex'],e['heCharOffset']))
finished=sorted(set(e['section'] for e in E))
coverage=[]
for s in finished:
 rows=json.loads((LIVE/f'{s-1}.json').read_text())
 coverage.append({'section':s,'sourcePageRanges':P[s],'status':'reviewed-add-only','additions':sum(e['section']==s for e in E),'existingNotes':[f['number'] for r in rows for f in r.get('footnotes',[])],'existingConnectedRefs':[c['targetRef'] for c in CONNECTED if c.get('originRef','').startswith(f'Tzidkat HaTzadik {s}:')],'selectionReason':'Both supplied editions and all existing native and connected notes reviewed. Added missing direct sources and complete explanatory primary parallels; already quoted passages are preserved and not repeated.'})
output={'schemaVersion':1,'reviewedSections':finished,'entries':E,'coverage':coverage,'observationsNotApplied':['All author text, existing notes, connected quotations, paragraph divisions, and numbers are preserved. Only new proposals are written.','Birkat HaZevach on Temurah 15b was not independently located. No new quotation or unsupported original locator is supplied for it.','All internal Hebrew selections are exact contiguous canonical reader text. External source selections retain the qualifications needed for their meaning.']}
p=ROOT/'review-work/ois-106-110.json';p.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
(ROOT/'review-work/ois-106-110-evidence.json').write_text(json.dumps({'proposal':str(p),'primaryCache':'ois106-primary.json','sources':[{'section':e['section'],'id':e['id'],'ref':e['ref'],'sourceEvidence':e['sourceEvidence'],'reviewEvidence':e['reviewEvidence']} for e in E]},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'entries':len(E),'finished':finished,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
