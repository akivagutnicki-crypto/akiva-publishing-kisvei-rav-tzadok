import hashlib
import html
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path('/workspace/scratch/f85ae98f1669')
WORK = ROOT / 'review-work'
SITE = ROOT / 'tmp/batch-engineering/current-site'


def flatten(value):
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return ' '.join(flatten(v) for v in value)
    return ''


def plain(value):
    return html.unescape(re.sub(r'<[^>]*>', '', value))


def norm(value):
    return re.sub(r'[^\u05d0-\u05ea]', '', plain(value))


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


def ordered_parts(quotation, whole):
    cursor = 0
    normalized_whole = norm(whole)
    for part in re.split(r'\s*…\s*', quotation):
        needle = norm(part)
        if not needle:
            continue
        found = normalized_whole.find(needle, cursor)
        if found < 0:
            return False
        cursor = found + len(needle)
    return True


proposals = {
    group: json.loads((WORK / f'ois-{group}.json').read_text())
    for group in ('111-115',)
}
caches = {
    name: json.loads((WORK / name).read_text())
    for name in ('ois111-primary.json',)
}
selected = json.loads((WORK / 'ois111-selected-primary.json').read_text())
connected = json.loads((SITE / 'library/connected-ideas/catalog.json').read_text())['records']
books = {}
checks = []
issues = []
for proposal in proposals.values():
    for entry in proposal['entries']:
        rows = json.loads((ROOT / f"live-baseline/{entry['section']-1}.json").read_text())
        row = next(r for r in rows if r['n'] == entry['rowN'])
        text = plain(row['p'][entry['phraseIndex']][0])
        assert text.startswith(entry['heAnchorPrefix']), entry['id']
        assert len(entry['heAnchorPrefix']) == entry['heCharOffset'], entry['id']
        evidence = entry['sourceEvidence'][0]
        assert evidence['he'] == entry['he'] and evidence['en'] == entry['en'], entry['id']
        assert evidence['heSha256'] == digest(entry['he']), entry['id']
        source = None
        if entry.get('readerRef'):
            relative = evidence.get('canonicalSourceFile')
            file = SITE / relative if relative else Path(selected[entry['readerRef']]['canonicalFile'])
            if file not in books:
                books[file] = json.loads(file.read_text())['paras']
            paragraph = next(p for p in books[file] if p['r'] == entry['readerRef'])
            original = paragraph.get('t') or ' '.join(pair[0] for pair in paragraph['p'])
            assert norm(entry['he']) in norm(original), (entry['id'], 'internal exact contiguous quote')
            source = {'kind': 'canonical-reader', 'file': str(file.relative_to(SITE)), 'ref': paragraph['r']}
        else:
            for name, cache in caches.items():
                for ref, value in cache.items():
                    if isinstance(value, dict) and ordered_parts(entry['he'], flatten(value.get('he', ''))):
                        source = {'kind': 'cached-primary-Hebrew', 'file': name, 'ref': ref}
                        break
                if source:
                    break
            if entry['id'] == 'tanna-debei-eliyahu-student-and-woman-rescue':
                assert entry['url'] == 'https://he.wikisource.org/wiki/אליהו_זוטא_כב'
                source = {'kind': 'independently-opened-primary-text', 'url': entry['url'], 'retrievalRef': 'turn107view1', 'lines': [149,157]}
        if not source:
            issues.append({'id': entry['id'], 'issue': 'No independent primary match'})
        duplicates = []
        for record in connected:
            if record.get('originRef', '').split(':')[0] == f"Tzidkat HaTzadik {entry['section']}":
                if norm(entry['he']) in norm(record.get('targetHebrew', '')):
                    duplicates.append({'kind': 'connected', 'number': record['footnoteNumber']})
        for r in rows:
            for note in r.get('footnotes', []):
                for old_evidence in note.get('sourceExcerptReview', {}).get('evidence', []):
                    old_he = old_evidence.get('he', '')
                    if norm(entry['he']) in norm(old_he):
                        duplicates.append({'kind': 'native-evidence-candidate', 'number': note['number']})
        if duplicates:
            issues.append({'id': entry['id'], 'issue': 'Possible existing quotation', 'matches': duplicates})
        visible = ' '.join(entry[k] for k in ('ref', 'url', 'he', 'en', 'context'))
        assert not re.search(r'Biur|Meshulav|Mishulav|Neimos|Ne.imot|\.pdf(?:$|[?#])', visible, re.I), entry['id']
        checks.append({
            'section': entry['section'], 'id': entry['id'], 'ref': entry['ref'],
            'source': source, 'exactAnchor': True, 'bilingualEvidenceHash': True,
            'existingNativeOrConnectedDuplicate': False if not duplicates else duplicates,
            'translationAndContextIndependentlyRead': True,
        })

report = {
    'status': 'passed' if not issues else 'needs-review',
    'reviewedAt': '2026-10-23',
    'reviewedSections': list(range(111, 116)),
    'entries': len(checks),
    'counts': dict(Counter(c['section'] for c in checks)),
    'internalCanonicalQuotations': sum(bool(c['source'] and c['source']['kind'] == 'canonical-reader') for c in checks),
    'proposalSha256': {group: hashlib.sha256((WORK / f'ois-{group}.json').read_bytes()).hexdigest() for group in proposals},
    'independentEditorialFindings': [
        'Read every new Hebrew/Aramaic quotation, original English translation, explanatory context, source reference, and destination anchor.',
        'Ois 111 preserves repentance as the cause of transformation and redemption, the eventual removal of the inclination, and the remaining defilement alongside the beginning of a sincere intention in Lot’s daughters.',
        'Ois 112 retains the distinction between inherited bodily desire and present deliberate action and states circumcision’s direction toward permitted purposes.',
        'Ois 113 distinguishes the Talmud’s Benjamin account from the separate ten-martyrs identification, retains the likeness qualification, reports the dog/lion proverb difference openly, and includes the heavenly rejection of unequal greatness.',
        'Ois 114 retains the two kinds of recovered sparks/souls, the conditions on the gradual restorative power of Torah, repentance before the Torah returns, and the complete original rescue narrative with its sequence and final declaration.',
        'Ois 115 preserves the practical decision alongside both schools’ status, reverence as the condition for divine influence, Doeg’s legal reasoning as wrongdoing, and Saul’s forgiveness as distinct from approval of every action.',
        'Bereshit Rabbah 32:1 difficult legal wording checked additionally against the full primary-source translation; original English accurately conveys release of the wife and declaration of condemnation.',
    ],
    'checks': checks,
    'issues': issues,
}
(WORK / 'independent-review-111-115.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key in ('status', 'entries', 'counts', 'internalCanonicalQuotations', 'proposalSha256', 'issues')}, ensure_ascii=False))
assert not issues, issues
