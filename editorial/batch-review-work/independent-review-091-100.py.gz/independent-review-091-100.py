import hashlib
import html
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path('/workspace/scratch/f85ae98f1669')
WORK = ROOT / 'review-work'
SITE = ROOT / 'tmp/batch-engineering/current-site'


def flatten(value):
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return ' '.join(flatten(v) for v in value)
    return ''


def plain(value):
    return html.unescape(re.sub(r'<[^>]*>', '', value))


def norm(value):
    return re.sub(r'[^\u05d0-\u05ea]', '', plain(value))


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


def ordered_parts(quotation, whole):
    cursor = 0
    normalized_whole = norm(whole)
    for part in re.split(r'\s*…\s*', quotation):
        needle = norm(part)
        if not needle:
            continue
        found = normalized_whole.find(needle, cursor)
        if found < 0:
            return False
        cursor = found + len(needle)
    return True


proposals = {
    group: json.loads((WORK / f'ois-{group}.json').read_text())
    for group in ('91-95', '96-100')
}
caches = {
    name: json.loads((WORK / name).read_text())
    for name in ('ois91-primary.json', 'ois96-primary.json')
}
selected = json.loads((WORK / 'ois96-selected-primary.json').read_text())
connected = json.loads((SITE / 'library/connected-ideas/catalog.json').read_text())['records']
books = {}
checks = []
issues = []
resolved_overlaps = []
web_sources = {
    "heikhalot-the-qualities-of-torah": {"url": "https://mobile.tora.ws/html/15061-27.html", "retrievalRef": "turn101view0", "line": 11},
    "heikhalot-the-stones-and-the-revealed-secret": {"url": "https://mobile.tora.ws/html/15061-30.html", "retrievalRef": "turn101view1", "line": 18},
    "tzetel-katan-reciting-prohibition": {"url": "https://he.wikisource.org/wiki/נועם_אלימלך/הצעטיל_הקטן", "retrievalRef": "turn101view2", "lines": [121, 122]},
}
for proposal in proposals.values():
    for entry in proposal['entries']:
        rows = json.loads((ROOT / f"live-baseline/{entry['section']-1}.json").read_text())
        row = next(r for r in rows if r['n'] == entry['rowN'])
        text = plain(row['p'][entry['phraseIndex']][0])
        assert text.startswith(entry['heAnchorPrefix']), entry['id']
        assert len(entry['heAnchorPrefix']) == entry['heCharOffset'], entry['id']
        evidence = entry['sourceEvidence'][0]
        assert evidence['he'] == entry['he'] and evidence['en'] == entry['en'], entry['id']
        assert evidence['heSha256'] == digest(entry['he']), entry['id']
        source = None
        if entry.get('readerRef'):
            relative = evidence.get('canonicalSourceFile')
            file = SITE / relative if relative else Path(selected[entry['readerRef']]['canonicalFile'])
            if file not in books:
                books[file] = json.loads(file.read_text())['paras']
            paragraph = next(p for p in books[file] if p['r'] == entry['readerRef'])
            original = paragraph.get('t') or ' '.join(pair[0] for pair in paragraph['p'])
            assert norm(entry['he']) in norm(original), (entry['id'], 'internal exact contiguous quote')
            source = {'kind': 'canonical-reader', 'file': str(file.relative_to(SITE)), 'ref': paragraph['r']}
        else:
            for name, cache in caches.items():
                for ref, value in cache.items():
                    if isinstance(value, dict) and ordered_parts(entry['he'], flatten(value.get('he', ''))):
                        source = {'kind': 'cached-primary-Hebrew', 'file': name, 'ref': ref}
                        break
                if source:
                    break
        if entry['id'] in web_sources:
            assert entry['url'] == web_sources[entry['id']]['url']
            source = {'kind': 'independently-opened-primary-text', **web_sources[entry['id']]}
        if not source:
            issues.append({'id': entry['id'], 'issue': 'No independent primary match'})
        duplicates = []
        for record in connected:
            if record.get('originRef', '').split(':')[0] == f"Tzidkat HaTzadik {entry['section']}":
                if norm(entry['he']) in norm(record.get('targetHebrew', '')):
                    duplicates.append({'kind': 'connected', 'number': record['footnoteNumber']})
        for r in rows:
            for note in r.get('footnotes', []):
                for old_evidence in note.get('sourceExcerptReview', {}).get('evidence', []):
                    old_he = old_evidence.get('he', '')
                    if norm(entry['he']) in norm(old_he):
                        duplicates.append({'kind': 'native-evidence-candidate', 'number': note['number']})
        if duplicates and entry['id'] == 'sanhedrin-the-short-extension-after-the-long':
            assert duplicates == [{'kind': 'native-evidence-candidate', 'number': 385}, {'kind': 'native-evidence-candidate', 'number': 386}]
            old_notes = {n['number']: n for r in rows for n in r.get('footnotes', [])}
            expected = {
                385: 'Sanhedrin 108b:5: “Rav said: These were the days of mourning for Methuselah, teaching that the eulogy of the righteous delays calamity.”',
                386: 'Sanhedrin 108b:5: “Another explanation: Those seven days were when He gave them a foretaste of the World to Come, so that they would know the good they had denied themselves.”',
            }
            for number, quotation in expected.items():
                assert quotation in [p['text'] for p in old_notes[number]['paragraphs']]
                assert entry['en'] not in ' '.join(p['text'] for p in old_notes[number]['paragraphs'])
            resolved_overlaps.append({'id': entry['id'], 'existingNumbers': [385, 386], 'finding': 'Old hidden evidence contains the complete multi-interpretation source segment; the visible old quotations supply mourning and the World to Come, while the new long/short-extension sentence is absent. Exact old visible quotations pinned; neither old note is changed.'})
            duplicates = []
        if duplicates:
            issues.append({'id': entry['id'], 'issue': 'Possible existing quotation', 'matches': duplicates})
        visible = ' '.join(entry[k] for k in ('ref', 'url', 'he', 'en', 'context'))
        assert not re.search(r'Biur|Meshulav|Mishulav|Neimos|Ne.imot|\.pdf(?:$|[?#])', visible, re.I), entry['id']
        checks.append({
            'section': entry['section'], 'id': entry['id'], 'ref': entry['ref'],
            'source': source, 'exactAnchor': True, 'bilingualEvidenceHash': True,
            'existingNativeOrConnectedDuplicate': False if not duplicates else duplicates,
            'translationAndContextIndependentlyRead': True,
        })

report = {
    'status': 'passed' if not issues else 'needs-review',
    'reviewedAt': '2026-10-23',
    'reviewedSections': list(range(91, 101)),
    'entries': len(checks),
    'counts': dict(Counter(c['section'] for c in checks)),
    'internalCanonicalQuotations': sum(bool(c['source'] and c['source']['kind'] == 'canonical-reader') for c in checks),
    'proposalSha256': {group: hashlib.sha256((WORK / f'ois-{group}.json').read_bytes()).hexdigest() for group in proposals},
    'independentEditorialFindings': [
        'Read all 64 Hebrew/Aramaic quotations, original English translations, explanatory contexts, source references, and anchors.',
        'Ois 91 retains the distinction between present ownerless creatures and future repair, and between Yaakov himself and his descendants before Sinai.',
        'Ois 92 preserves lower versus higher repentance, the unsuccessful opening given to the Flood generation, and the human response required after a divine initiative.',
        'Ois 93 retains Rabbeinu Bahya’s constant/hovering presence distinction, the differing Heikhalot enumeration, Ramchal’s exclusion of mocking or distorting study, and the distinction between wisdom’s range and prophecy’s clarity.',
        'Ois 94 keeps the alternative opinion about prayer gates and the communal-prayer distinction, while attributing the connection with repentance at death to Rav Tzadok.',
        'Ois 95 preserves the distinction between a hidden root and its expression, the ongoing refinement of mixed motives, and repentance as the condition connected with the rainbow.',
        'Ois 96 now includes and translates the full Balaam chronology/soul-root argument in Resisei Layla 44, and preserves the exceptional prophetic basis of Moshe’s separation.',
        'Ois 97 now includes and translates the textual variants, complete-repentance qualification, severity comparison, and Kiddushin argument in Takanat HaShavin 15; voluntary thoughts are distinguished from the following involuntary-dream discussion.',
        'Ois 98 treats Tzetel Katan as an original parallel without claiming it locates the teaching in the Ari; Mei HaShiloach retains the concrete gradual replacement of anger by love.',
        'Ois 99 now includes and translates Machshavot Charutz’s light/name/garment/new-world explanation and denial qualification; Rabbeinu Yonah’s remembrance/forgiveness distinction and the alternative confession teaching remain distinct.',
        'Ois 100 retains love versus fear in repentance, unforced individual choice in Akeidat Yitzchak, the context of David’s failed request for a trial, and acquired character in Shaarei Kedusha.',
    ],
    'resolvedEvidenceOverlaps': resolved_overlaps,
    'publicationFollowup': 'Two independently verified Heikhalot source URLs need exact pack-bound reader support before batch 7 publication; no quotation or existing content change is required.',
    'checks': checks,
    'issues': issues,
}
(WORK / 'independent-review-091-100.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key in ('status', 'entries', 'counts', 'internalCanonicalQuotations', 'proposalSha256', 'issues')}, ensure_ascii=False))
assert not issues, issues
