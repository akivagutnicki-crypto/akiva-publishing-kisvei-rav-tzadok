"""Independently check proposed notes against the preserved reader and source cache.

This is a review aid: exact text checks do not certify translation or context.
Those require the recorded source review and a human-language reading.
"""
import argparse, hashlib, html, json, re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'live-baseline'
BOOKS = ROOT / 'site-current/mcp-data/text'
HE_MARKS = re.compile(r'[\u0591-\u05bd\u05bf-\u05c2\u05c4-\u05c5\u05c7]')
def plain(value):
    if isinstance(value,list):
        return ' '.join(plain(v) for v in value)
    return html.unescape(re.sub(r'<[^>]*>','',str(value))).replace('\u200e','').replace('\u200f','')
def norm(value):
    return ' '.join(HE_MARKS.sub('',plain(value)).split())
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('proposals',nargs='+')
    ap.add_argument('--output',required=True)
    args=ap.parse_args()
    books={}
    primary=[]
    cache_roots=[ROOT/'review-work',Path('/workspace/scratch/f85ae98f1669/review-work')]
    for cache_root in cache_roots:
        for cp in cache_root.rglob('*primary*.json'):
            try:cached=json.loads(cp.read_text())
            except (ValueError,OSError):continue
            if not isinstance(cached,dict):continue
            for key,value in cached.items():
                if not isinstance(value,dict):continue
                data=value.get('data',value)
                if not isinstance(data,dict):continue
                text=data.get('he')
                if not text:
                    versions=data.get('versions',[])
                    hebrew=[v for v in versions if v.get('language')=='he' or v.get('actualLanguage')=='he']
                    if hebrew:text=hebrew[0].get('text')
                    elif len(versions)==1 and re.search('[א-ת]',str(versions[0].get('text',''))):text=versions[0].get('text')
                if text:primary.append((str(data.get('ref',key)),norm(text),str(cp)))
    report={'ok':True,'notes':[],'errors':[],'translationAndContext':'Requires separate scholarly review; not certified by this script.'}
    seen=set()
    for name in args.proposals:
        obj=json.loads(Path(name).read_text())
        for e in obj['entries']:
            issues=[]
            key=(e['section'],e['id'])
            if key in seen:issues.append('duplicate proposed identity')
            seen.add(key)
            if e['section'] in (40,74,154):issues.append('protected or absent ois')
            rows=json.loads((BASE/f"{e['section']-1}.json").read_text())
            row=next(r for r in rows if r['n']==e['rowN'])
            actual=plain(row['p'][e['phraseIndex']][0])
            if not actual.startswith(e['heAnchorPrefix']):issues.append('Hebrew prefix differs')
            ev=[v for v in e['sourceEvidence'] if v.get('ref')==e['ref'] and v.get('he')==e['he'] and v.get('en')==e['en']]
            if not ev:issues.append('exact bilingual evidence missing')
            if re.search(r'biur\s+m[eiu]sh|ne[i’\x27]?im[oô]s|נעימות\s+הצדק|ביאור\s+משולב',e['ref']+' '+e['en']+' '+e['context'],re.I):issues.append('secondary-edition public attribution')
            for r in rows:
                for n in r.get('footnotes',[]):
                    old=n.get('reviewedSourceExcerpt',{})
                    if norm(old.get('he',''))==norm(e['he']):issues.append('exact quotation already in native notes')
            internal=e.get('url','').startswith('#/read/') or 'github.io/akiva-publishing-kisvei-rav-tzadok/library/#/read/' in e.get('url','')
            source_check='external-source-review-recorded'
            if internal:
                refs={e.get('readerRef',e['ref'])}
                matched=[]
                for v in ev:
                    p=v.get('canonicalSourceFile')
                    if p:
                        bp=ROOT/'site-current'/p
                        if bp.exists():
                            if str(bp) not in books:books[str(bp)]=json.loads(bp.read_text())['paras']
                            matched.extend(p for p in books[str(bp)] if p['r'] in refs)
                if not matched:
                    for bp in BOOKS.glob('*.json'):
                        if str(bp) not in books:books[str(bp)]=json.loads(bp.read_text()).get('paras',[])
                        matched.extend(p for p in books[str(bp)] if p['r'] in refs)
                texts=[plain([x[0] for x in p['p']]) if 'p' in p else plain(p.get('t','')) for p in matched]
                if not texts:issues.append('internal reference missing from canonical texts')
                elif not any(norm(e['he']) in norm(t) for t in texts):issues.append('internal Hebrew not contiguous canonical source text')
                else:source_check='contiguous-canonical-hebrew-confirmed'
            else:
                evidence=norm(e['he'])
                relevant=[(ref,text,cp) for ref,text,cp in primary if e['ref']==ref or e['ref'].startswith(ref+':') or e['ref'].startswith(ref+' ') or ref.startswith(e['ref']+':')]
                matches=[(ref,cp) for ref,text,cp in relevant if evidence in text]
                if matches:source_check={'fetchedPrimaryPassageMatches':matches[:2]}
                elif relevant:source_check={'needsManualCheck':'Not one contiguous quotation in cached primary section; check range, editions and punctuation.','available':[ref for ref,_,_ in relevant]}
                else:source_check={'needsManualCheck':'No matching ref in indexed fetched-primary cache; check separately recorded evidence.'}
            item={'section':e['section'],'id':e['id'],'ref':e['ref'],'anchorTail':e['heAnchorPrefix'][-110:],'englishWords':len(e['en'].split()),'sourceCheck':source_check,'issues':issues}
            report['notes'].append(item)
            if issues:report['errors'].append(item)
    report['ok']=not report['errors']
    Path(args.output).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'ok':report['ok'],'notes':len(report['notes']),'errors':report['errors']},ensure_ascii=False))
if __name__=='__main__':main()
