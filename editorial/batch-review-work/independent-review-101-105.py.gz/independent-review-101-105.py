import hashlib
import html
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path('/workspace/scratch/f85ae98f1669')
WORK = ROOT / 'review-work'
SITE = ROOT / 'tmp/batch-engineering/current-site'


def flatten(value):
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return ' '.join(flatten(v) for v in value)
    return ''


def plain(value):
    return html.unescape(re.sub(r'<[^>]*>', '', value))


def norm(value):
    return re.sub(r'[^\u05d0-\u05ea]', '', plain(value))


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


def ordered_parts(quotation, whole):
    cursor = 0
    normalized_whole = norm(whole)
    for part in re.split(r'\s*…\s*', quotation):
        needle = norm(part)
        if not needle:
            continue
        found = normalized_whole.find(needle, cursor)
        if found < 0:
            return False
        cursor = found + len(needle)
    return True


def primary_he(value):
    if not isinstance(value, dict): return ''
    if 'result' in value: return primary_he(value['result'])
    if 'data' in value: return primary_he(value['data'])
    if 'he' in value: return flatten(value['he'])
    return ' '.join(flatten(v.get('text','')) for v in value.get('versions', []) if v.get('languageFamilyName') == 'hebrew')

web_sources = {
    'zohar-little-folly-and-wisdom': {'url': 'https://he.wikisource.org/wiki/זהר_חלק_ג_מז_ב', 'retrievalRef': 'turn106view0', 'lines': [145,146]},
    'zohar-covenantal-designation-righteous': {'url': 'https://he.wikisource.org/wiki/זהר_חלק_א_צג_א', 'retrievalRef': 'turn106view1', 'lines': [129,133]},
    'zohar-jewish-spirits-and-yosef': {'url': 'https://he.wikisource.org/wiki/זהר_חלק_ג_רנג_א', 'retrievalRef': 'turn106view2', 'line': 139},
    'zohar-guarding-the-covenant-and-righteousness': {'url': 'https://he.wikisource.org/wiki/זהר_חלק_א_נט_ב', 'retrievalRef': 'turn105view3', 'line': 134},
}

proposals = {
    group: json.loads((WORK / f'ois-{group}.json').read_text())
    for group in ('101-105',)
}
caches = {
    name: json.loads((WORK / name).read_text())
    for name in ('primary-101-105.json', 'extra-primary-101-105.json')
}
selected = {}
connected = json.loads((SITE / 'library/connected-ideas/catalog.json').read_text())['records']
books = {}
checks = []
issues = []
for proposal in proposals.values():
    for entry in proposal['entries']:
        rows = json.loads((ROOT / f"live-baseline/{entry['section']-1}.json").read_text())
        row = next(r for r in rows if r['n'] == entry['rowN'])
        text = plain(row['p'][entry['phraseIndex']][0])
        assert text.startswith(entry['heAnchorPrefix']), entry['id']
        assert len(entry['heAnchorPrefix']) == entry['heCharOffset'], entry['id']
        evidence = entry['sourceEvidence'][0]
        assert evidence['he'] == entry['he'] and evidence['en'] == entry['en'], entry['id']
        assert evidence['heSha256'] == digest(entry['he']), entry['id']
        source = None
        if entry.get('readerRef'):
            relative = evidence.get('canonicalSourceFile')
            file = SITE / relative if relative else Path(selected[entry['readerRef']]['canonicalFile'])
            if file not in books:
                books[file] = json.loads(file.read_text())['paras']
            paragraph = next(p for p in books[file] if p['r'] == entry['readerRef'])
            original = paragraph.get('t') or ' '.join(pair[0] for pair in paragraph['p'])
            assert norm(entry['he']) in norm(original), (entry['id'], 'internal exact contiguous quote')
            source = {'kind': 'canonical-reader', 'file': str(file.relative_to(SITE)), 'ref': paragraph['r']}
        else:
            for name, cache in caches.items():
                for ref, value in cache.items():
                    if isinstance(value, dict) and ordered_parts(entry['he'], primary_he(value)):
                        source = {'kind': 'cached-primary-Hebrew', 'file': name, 'ref': ref}
                        break
                if source:
                    break
        if entry['id'] in web_sources:
            assert entry['url'] == web_sources[entry['id']]['url']
            source = {'kind': 'independently-opened-primary-text', **web_sources[entry['id']]}
        if not source:
            issues.append({'id': entry['id'], 'issue': 'No independent primary match'})
        duplicates = []
        for record in connected:
            if record.get('originRef', '').split(':')[0] == f"Tzidkat HaTzadik {entry['section']}":
                if norm(entry['he']) in norm(record.get('targetHebrew', '')):
                    duplicates.append({'kind': 'connected', 'number': record['footnoteNumber']})
        for r in rows:
            for note in r.get('footnotes', []):
                for old_evidence in note.get('sourceExcerptReview', {}).get('evidence', []):
                    old_he = old_evidence.get('he', '')
                    if norm(entry['he']) in norm(old_he):
                        duplicates.append({'kind': 'native-evidence-candidate', 'number': note['number']})
        if duplicates:
            issues.append({'id': entry['id'], 'issue': 'Possible existing quotation', 'matches': duplicates})
        visible = ' '.join(entry[k] for k in ('ref', 'url', 'he', 'en', 'context'))
        assert not re.search(r'Biur|Meshulav|Mishulav|Neimos|Ne.imot|\.pdf(?:$|[?#])', visible, re.I), entry['id']
        checks.append({
            'section': entry['section'], 'id': entry['id'], 'ref': entry['ref'],
            'source': source, 'exactAnchor': True, 'bilingualEvidenceHash': True,
            'existingNativeOrConnectedDuplicate': False if not duplicates else duplicates,
            'translationAndContextIndependentlyRead': True,
        })

report = {
    'status': 'passed' if not issues else 'needs-review',
    'reviewedAt': '2026-10-23',
    'reviewedSections': list(range(101, 106)),
    'entries': len(checks),
    'counts': dict(Counter(c['section'] for c in checks)),
    'internalCanonicalQuotations': sum(bool(c['source'] and c['source']['kind'] == 'canonical-reader') for c in checks),
    'proposalSha256': {group: hashlib.sha256((WORK / f'ois-{group}.json').read_bytes()).hexdigest() for group in proposals},
    'independentEditorialFindings': [
        'Read all 39 Hebrew/Aramaic quotations, original English translations, explanatory contexts, source references, and exact anchors.',
        'Ois 101 preserves Etz Chaim’s restriction of mixture to garments, the two reasons for combining mercy and judgment, Rabbi Meir’s differing opinion, and the particular greeting enactment in Rashi.',
        'Ois 102 preserves the qualification that Hillel’s pleasures are already for Heaven, the danger as well as transformative advantage of the place of repentance, and Shaar HaGilgulim’s specified fifty-or-more drops from five unions.',
        'Ois 103 retains after-the-fact reassurance versus beforehand prayer, the vow-law context of circumcision terminology, and the Zohar’s acknowledgement of sin alongside its covenantal designation; its later protection qualification is expressly stated in context and independently checked.',
        'Ois 104 distinguishes individual patriarchal attainment from descendants’ further refinement; Ramban retains the normal Torah/mitzvot reading as well as the names tradition; Peri Tzadik distinguishes joyful acceptance of Torah from forced human service.',
        'Ois 105 preserves all three judgment categories, both possible intermediate outcomes, Yoma 88a:10 as distinct from the existing following segment, and Pardes’s rejection of the alternative identification.',
        'Unlocated Birkat HaZevach text and the printed ois 102 insertion lacking a canonical anchor remain documented omissions; no original text or existing note was changed.',
    ],
    'checks': checks,
    'issues': issues,
}
(WORK / 'independent-review-101-105.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key in ('status', 'entries', 'counts', 'internalCanonicalQuotations', 'proposalSha256', 'issues')}, ensure_ascii=False))
assert not issues, issues
