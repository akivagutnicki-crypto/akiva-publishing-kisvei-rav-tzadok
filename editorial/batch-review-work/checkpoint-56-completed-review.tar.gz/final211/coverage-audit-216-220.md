# Original-source review: Tzidkat HaTzadik 216–220

Prepared on 2026-10-25. Status: ready for root review and integration; not published by this reviewer.

## Deliverable

`ois-216-220.json` contains 21 additions: 7 in216, 2 in217, 3 in218, 6 in219 and 3 in220. Every addition has an exact current public Hebrew anchor, a consecutive original Hebrew/Aramaic quotation, a full independent English translation, an actual source reference/link, matching bilingual evidence and a Hebrew content hash. Internal sources use the present canonical reader wording, preferring an interlinear paragraph when available. Context is internal evidence only.

All five manuscripts and all their existing native and connected quotations were read. Both supplied discovery editions were reviewed across the ranges recorded in the JSON coverage array. Existing body text and every existing note are unchanged. No arbitrary minimum number of additions was used.

## Primary-source and structural checks

- `structural-216-220.json` checks exact current anchors, identical bilingual evidence, content hashes and canonical Hebrew containment. All21 entries pass.
- `exact-reference-checks.json` records15 independently resolved exact external references. All15 return original Hebrew containing the selected passage. HTML tags and invisible page-overlay attributes are excluded from text comparison.
- The other6 sources are exact contiguous selections from the current canonical internal texts.
- English contains no square-bracket insertions. Existing source parentheses and qualifications are retained in translation. The Zohar’s end marker and cross-reference between the selected paragraphs are translated as well.
- `new-primary.json` preserves the retrieved original texts and retrieval URLs. `build-216-220.py` and `common.py` reproduce the deliverable.

## Coverage decisions

###216

Added the daily-renewal teaching in Bereshit Rabbah, Rav Tzadok’s reconciliation of the two teachings about Shabbat, the complete three-meal Zohar sequence, Torah vitality within food, Tosafot’s explanation of Rav Nachman’s fast, the manna discussion including Rabbi Yishmael’s objection, and the source for tasting Shabbat food on Friday.

The received image of the world as a book and Torah as its commentary was located in Machshavot Charutz11:4, but the entire quotation already appears in the connected note at232. The proposed repeat was removed. Pirkei Avot3:5 is already quoted at104, and the manna/Mekhilta source is supplied in the reviewed211 proposal. Existing direct sources on the creation-through-Torah theme, blessings, Shema, uninterrupted Torah, changing garments, Shabbat rest, the sea and Friday’s double portion remain intact.

The canonical/Sefaria continuation of Peri Tzadik, Bechukotai1:2 contains an awkward truncated clause after the quoted reconciliation. The selected source unit ends before that clause; nothing was silently reconstructed from the discovery compilation.

###217

Added the direct authorial parallel about officers of thousands and the king’s myriad, and Rabbi Chaim Vital’s report of the Ari explaining how anger uproots the soul. The latter retains its explicit warning about anger ostensibly for a mitzvah.

Several apparent gaps were already covered globally: the exact three-camp teaching in Mei HaShiloach Nasso4 at258 note2636; Sha’arei Kedusha1:1:4 at144/155/210; Rambam Forbidden Intercourse22:21 at152 note3370; Avot4:1 at147/187; and Ravina’s qualification about gentleness at117/199. They were therefore not repeated. Existing Zohar, Ramban, Talmudic, scriptural and connected quotations cover the remaining explicit sources.

###218

Added the complete Midrash unit on Cain’s dispute, including its alternative opinions; Rav Tzadok’s distinction between holy restraint before sin and anger after sin; and the explicit tefillin version in Yalkut Shimoni238:1. The last was verified in the original Yalkut text, because the corresponding Mekhilta text uses the word tefillah and an editorial gloss. No silent harmonization was used.

Existing sources on Torah as seasoning, divine/head tefillin, bodily cleanliness, Elijah, judicial fasting and studying rather than retaliating remain unchanged. Existing Ishbitz–Radzin parallels are preserved. Earlier quotations about gentleness and the two kinds of gratification were not duplicated.

###219

Added Kohelet Rabbah’s age-thirteen teaching, Rambam’s explanation of the king’s collective heart, the explicit self-reference to98, Rambam’s entire healing/protective-recitation distinction, the concealed-blessing passage and a precise authorial comparison of Torah light in a mitzvah with Torah study.

Kohelet Rabbah supplies the age when the good inclination joins the person; it is not made to assert the additional intensification of the evil inclination. The Mei HaShiloach Talmud anthology passage that reproduces this very ois was rejected as circular evidence. Taanit8b concerns blessing in concealed produce; its relevance to hidden miracles is identified internally as a parallel, not misattributed as a statement about amulet permutations. Rambam’s permission for a healthy person’s protective recitation is included with the prohibition. The Peri Tzadik comparison retains its temporary/enduring distinction even though it does not exactly duplicate every formulation in the manuscript.

###220

Added Tanya27:1–4 on redirecting unwanted thoughts, Zohar Shelach46:333–335 on the strap and the two colors, and Pri Etz Chaim’s distinction between the encompassing lights of tallit and tefillin. Their complete relevant source qualifications were translated.

The already-published Tanya27:8–10 and Zohar Shelach46:332 are different paragraphs, and their full quotations were compared. Existing Resisei Layla, Tiferet Yosef and Talmudic/scriptural sources remain intact. Short isolated repetitions about encompassing light were not added simply to increase the count.

## Global duplication review

`global-overlaps-216-220.json` was generated using the enhanced native, connected-ideas and source-connections inventory. There are no complete exact Hebrew quotation duplicates remaining. Same-chapter matches were inspected in full English as well: Bereshit Rabbah49, Bereshit Rabbah22, Likkutei Maamarim16, Taanit8b, Peri Tzadik Chanukah23, Tanya27 and Zohar Shelach46 concern distinct selected units. The Machshavot11:4 connected-note duplicate was removed before finalization.

No missing verification is represented as completed. The optional follow-up question of correcting old source transcriptions is outside this add-only batch and has not changed any published material.
