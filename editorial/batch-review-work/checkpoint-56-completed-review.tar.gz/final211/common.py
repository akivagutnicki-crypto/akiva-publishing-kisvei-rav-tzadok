import json,re,html,hashlib
from pathlib import Path

HERE=Path(__file__).parent
ROOT=HERE.parent.parent
BASE=ROOT/'live-baseline/library/data/tzidkat-hatzadik'
CANON=ROOT/'live-baseline/mcp-data/text'
PAGES={216:{'neimosB':list(range(172,178)),'integratedB':list(range(181,187))},217:{'neimosB':list(range(177,184)),'integratedB':list(range(186,193))},218:{'neimosB':list(range(183,188)),'integratedB':list(range(193,198))},219:{'neimosB':list(range(187,193)),'integratedB':list(range(197,202))},220:{'neimosB':list(range(192,197)),'integratedB':list(range(201,206))}}
def plain(t):
    if isinstance(t,list):t=' '.join(plain(v) for v in t)
    return ' '.join(html.unescape(re.sub('<[^>]*>','',t)).replace('\u200e','').replace('\u200f','').split())
def bare(t):return re.sub('[\u0591-\u05bd\u05bf\u05c1-\u05c2\u05c4-\u05c5\u05c7]','',plain(t))
def norm(t):return re.sub('[^א-ת]','',plain(t))
def source(ref,*indexes,cache='new-primary.json'):
    z=json.loads((HERE/cache).read_text())[ref];z=z.get('data',z);v=z['he']
    for i in indexes:v=v[i-1]
    return bare(v)
_books={}
def local(book,ref,lo=0,hi=None):
    if book not in _books:_books[book]=json.loads((CANON/f'{book}.json').read_text())['paras']
    ps=[p for p in _books[book] if p['r']==ref]
    p=next((p for p in ps if 'p' in p),ps[0])
    return plain([x[0] for x in p['p'][lo:hi]]) if 'p' in p else plain(p['t'])
def cut(s,a,b=None):
    i=s.index(a)
    return s[i:] if b is None else s[i:s.index(b,i)+len(b)]
entries=[]
def add(section,id,phrase,ref,he,en,context,book=None,cacheRef=None,cache='new-primary.json',dedup=None):
    row=next(r for r in json.loads((BASE/f'{section-1}.json').read_text()) if r.get('n')==1)
    prefix=plain(row['p'][phrase][0]);he=plain(he)
    assert '[' not in en and ']' not in en
    url=('#/read/'+ref.replace(' ','_')) if book else 'https://www.sefaria.org/'+ref.replace(' ','_')
    evidence={'ref':ref,'url':url,'he':he,'en':en,'heSha256':hashlib.sha256(he.encode()).hexdigest(),'translation':'Original English translation prepared directly from the original Hebrew or Aramaic.','coverage':'Complete consecutive selected source unit; relevant qualifications are retained.'}
    if book:
        assert he in local(book,ref),(id,'noncontiguous canonical source')
        evidence.update(canonicalReaderRef=ref,canonicalSourceFile=f'mcp-data/text/{book}.json')
    else:
        assert norm(he) in norm(source(cacheRef or ref,cache=cache)),(id,'source mismatch')
        evidence.update(retrievalCache=f'review-work/final211/{cache}',retrievalCacheRef=cacheRef or ref)
    entry={'section':section,'id':id,'rowN':1,'phraseIndex':phrase,'heAnchorPrefix':prefix,'heCharOffset':len(prefix),'ref':ref,'url':url,'he':he,'en':en,'context':context,'sourceEvidence':[evidence],'reviewEvidence':{'pdfPages':PAGES[section],'preserveExisting':True,'status':'verified','dedup':dedup or 'Current destination notes and global source-reference inventory compared; no repeated selected quotation identified.','method':'Both supplied commentary editions reviewed as discovery aids; quotation verified against the original source; English independently translated; exact current public anchor checked.'}}
    if book:entry['readerRef']=ref
    else:entry['openExternal']=True
    entries.append(entry)
def save(complete=False,decisions=None,observations=None):
    cov=[]
    catalog=json.loads((ROOT/'live-baseline/library/connected-ideas/catalog.json').read_text())['records']
    for s in range(216,221):
        f=BASE/f'{s-1}.json';rows=json.loads(f.read_text())
        linked=[r['targetRef'] for r in catalog if r['originRef'].startswith(f'Tzidkat HaTzadik {s}:')]+[r['originRef'] for r in catalog if r['targetRef'].startswith(f'Tzidkat HaTzadik {s}:')]
        cov.append({'section':s,'status':'complete-add-only-review' if complete else 'draft-checkpoint','bothSuppliedEditionsRead':True,'pdfPages':PAGES[s],'existingNativeNumbersPreserved':[n['number'] for r in rows for n in r.get('footnotes',[])],'existingConnectedSourcesPreserved':sorted(set(linked)),'baselineSha256':hashlib.sha256(f.read_bytes()).hexdigest(),'additions':sum(e['section']==s for e in entries),'decisions':(decisions or {}).get(s,[])})
    out={'schemaVersion':1,'reviewedSections':list(range(216,221)),'reviewMode':'Add only missing original-source quotations; preserve all existing body text and notes.','entries':entries,'coverage':cov,'observationsNotApplied':observations or [],'sourceVerification':'Exact contiguous canonical Hebrew for internal sources; public primary-source Hebrew verified for external sources; full original English translations. No public attribution to discovery compilations.','reproducibleBuilder':'review-work/final211/build-216-220.py'}
    (HERE/'ois-216-220.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('saved',len(entries),'entries','complete' if complete else 'checkpoint')
