"""Merge independently reviewed source-coverage additions without altering prior entries."""
import collections
import json
from pathlib import Path

root = Path(__file__).resolve().parent
candidates = json.loads((root / 'coverage-candidates-241-255.json').read_text())['entries']
counts = {}
for first in (241, 246, 251):
    last = first + 4
    file = root / f'ois-{first}-{last}.json'
    data = json.loads(file.read_text())
    original = {(entry['section'], entry['id']): entry for entry in data['entries']}
    merged = dict(original)
    selected = [entry for entry in candidates if first <= entry['section'] <= last]
    for entry in selected:
        key = (entry['section'], entry['id'])
        if key in original:
            public_before = {key: value for key, value in original[key].items() if key != 'reviewEvidence'}
            public_after = {key: value for key, value in entry.items() if key != 'reviewEvidence'}
            assert public_before == public_after, f'Approved supplemental content differs: {key}'
        merged[key] = entry
    data['entries'] = list(merged.values())
    data['entries'].sort(key=lambda entry: (entry['section'], entry['phraseIndex'], entry['id']))
    merged = {(entry['section'], entry['id']): entry for entry in data['entries']}
    supplemental_keys = {(entry['section'], entry['id']) for entry in selected}
    assert all(merged[key] == value for key, value in original.items() if key not in supplemental_keys)
    by_section = collections.Counter(entry['section'] for entry in data['entries'])
    for coverage in data.get('coverage', []):
        section = coverage['section']
        coverage['additions'] = by_section[section]
        extra = [entry['ref'] for entry in selected if entry['section'] == section]
        if extra:
            coverage['supplementalSourceReview'] = {
                'status': 'independently-reviewed',
                'additionalPrimarySources': extra,
                'scope': 'Explicit primary-source citations and a directly relevant authorial parallel checked after the initial source-gap review.',
            }
    file.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    counts[f'{first}-{last}'] = len(data['entries'])
print(json.dumps({'supplementalNotes': len(candidates), 'counts': counts, 'notes': sum(counts.values())}))
