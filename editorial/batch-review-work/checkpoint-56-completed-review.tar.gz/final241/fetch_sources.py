import json,pathlib,urllib.request,urllib.parse,concurrent.futures,time
P=pathlib.Path(__file__).parent/'primary.json'
def fetch(refs):
 o=json.loads(P.read_text()) if P.exists() else {}
 def one(ref):
  url='https://www.sefaria.org/api/texts/'+urllib.parse.quote(ref.replace(' ','_'),safe=':_,-')+'?commentary=0&context=0&pad=0'
  try:
   req=urllib.request.Request(url,headers={'User-Agent':'AkivaSourceReview/1.0'})
   data=json.load(urllib.request.urlopen(req,timeout=20));return ref,{'url':url,'data':data}
  except Exception as e:return ref,{'error':str(e),'url':url}
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:
  for ref,r in ex.map(one,[r for r in refs if r not in o or 'error'in o[r]]):o[ref]=r;print(ref,'ERROR '+str(r.get('error',r.get('data',{}).get('error'))) if ('error'in r or r.get('data',{}).get('error')) else 'ok')
 P.write_text(json.dumps(o,ensure_ascii=False,indent=2));return o
if __name__=='__main__':
 import sys;fetch(sys.argv[1:])
