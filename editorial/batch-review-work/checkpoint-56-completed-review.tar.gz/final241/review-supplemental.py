from pathlib import Path
import contextlib
import hashlib
import html
import io
import json
import re
import runpy
import unicodedata

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FILE = HERE / 'coverage-candidates-241-255.json'

def clean(s):
    return re.sub(r'\s+', ' ', html.unescape(re.sub('<[^>]*>', '', s))).strip()

def unpoint(s):
    return ''.join(c for c in clean(s) if not unicodedata.combining(c))

def letters(s):
    return re.sub('[^א-ת]', '', s)

with contextlib.redirect_stdout(io.StringIO()):
    checker = runpy.run_path(str(ROOT / 'review-work/find-proposal-overlaps.py'))
old = checker['old']
entries = json.loads(FILE.read_text())['entries']
selections = {
    'zohar-balaams-serpents-and-seminal-power': ('Zohar,_Balak_13:176-185.json', slice(6, 10)),
    'zohar-the-impure-spirit-during-dreams': ('Zohar,_Vayishlach_4:75-86.json', slice(7, 9)),
    'zohar-the-hebrew-servant-and-the-feminine-world': ('Zohar,_Mishpatim_3:212-222.json', slice(6, 10)),
    'zohar-six-years-of-service-and-prayer': ('Zohar,_Mishpatim_8:395-397.json', 0),
    'pri-etz-chaim-the-reincarnation-of-esau': ('Pri_Etz_Chaim,_Gate_of_The_New_Month,_Chanukah,_and_Purim_3.json', slice(28, 30)),
}
proposals = []
for p in sorted((ROOT / 'review-work').glob('final*/ois-*.json')):
    if 'duplicates' in p.name:
        continue
    data = json.loads(p.read_text())
    if isinstance(data, dict):
        for e in data.get('entries', []):
            proposals.append((str(p.relative_to(ROOT)), e))

errors, checks, exact_duplicates, cross_duplicates = [], [], [], []
for e in entries:
    eid = e['id']
    rows = json.loads((ROOT / f'live-baseline/library/data/tzidkat-hatzadik/{e["section"] - 1}.json').read_text())
    row = next(r for r in rows if r['n'] == e['rowN'])
    anchor = clean(row['p'][e['phraseIndex']][0])
    anchor_ok = anchor.startswith(e['heAnchorPrefix']) and e['heCharOffset'] == len(e['heAnchorPrefix'])
    if not anchor_ok:
        errors.append({'id': eid, 'error': 'anchor mismatch'})
    if eid in selections:
        name, selection = selections[eid]
        d = json.loads((ROOT / 'review-work/coverage241-cache' / name).read_text())
        source = d['he'][selection]
        if isinstance(source, list):
            source = ' '.join(source)
        source = unpoint(source)
        if eid == 'zohar-six-years-of-service-and-prayer':
            source = source[source.index('דבצלותא דבר נש'):]
        if eid == 'pri-etz-chaim-the-reincarnation-of-esau':
            source = source[source.index('ועשו היה מצד הדין'):]
        source_ok = source == e['he']
        source_ref = d['ref']
    else:
        d = json.loads((ROOT / 'live-baseline/mcp-data/text/likkutei-maamarim.json').read_text())
        p = next(p for p in d['paras'] if p['r'] == e['ref'])
        source = unpoint(' '.join(pair[0] for pair in p['p']) if 'p' in p else p['t'])
        source = source[source.index("והיינו דיש ב' מיני מעוררים"):]
        source_ok = source == e['he']
        source_ref = p['r']
    if not source_ok:
        errors.append({'id': eid, 'error': 'exact primary text mismatch'})
    evidence = e['sourceEvidence'][0]
    evidence_ok = evidence['he'] == e['he'] and evidence['en'] == e['en'] and evidence['ref'] == e['ref'] and evidence['url'] == e['url'] and evidence['heSha256'] == hashlib.sha256(e['he'].encode()).hexdigest()
    if not evidence_ok:
        errors.append({'id': eid, 'error': 'source evidence/hash mismatch'})
    if '[' in e['en'] or ']' in e['en']:
        errors.append({'id': eid, 'error': 'English square brackets'})
    same_source = []
    for o in old:
        if o['he'] and letters(e['he']) in letters(o['he']):
            exact_duplicates.append({'id': eid, 'section': o['section'], 'number': o['number'], 'refs': o['refs']})
        if any(checker['stem'](ref) == checker['stem'](e['ref']) for ref in o['refs']):
            same_source.append({'section': o['section'], 'number': o['number'], 'refs': o['refs']})
    for path, other in proposals:
        if other['id'] == eid:
            continue
        if letters(e['he']) in letters(other.get('he', '')):
            cross_duplicates.append({'id': eid, 'file': path, 'section': other['section'], 'otherId': other['id'], 'ref': other['ref']})
    checks.append({'id': eid, 'section': e['section'], 'ref': e['ref'], 'sourceCacheRef': source_ref, 'anchorVerified': anchor_ok, 'exactPrimarySelectionVerified': source_ok, 'evidenceAndHashVerified': evidence_ok, 'HebrewEnglishReview': 'Read in full against exact Hebrew and surrounding primary context; all retained qualifications reviewed.', 'sameSourceMatchesReviewed': same_source})

audit = {
    'status': 'pass' if not errors and not exact_duplicates and not cross_duplicates else 'review-required',
    'candidateCount': len(entries),
    'proposalFileSha256': hashlib.sha256(FILE.read_bytes()).hexdigest(),
    'errors': errors,
    'remainingWholeSeferCompleteQuoteDuplicates': exact_duplicates,
    'crossBatchCompleteQuoteDuplicates': cross_duplicates,
    'checks': checks,
    'scholarlyDecisions': [
        'Balak 13:182–185 is the complete selected concluding sequence. Paragraph 182 itself identifies the serpents as coming from Balaam’s bones; 185 retains the restriction on revealing secrets and the concluding verses.',
        'Vayishlach 4:82–83 preserves the complete dream/impurity unit and its practical closing statement. Existing Zohar Bereshit 94:347 at section 110 is a distinct, shorter parallel about spirits giving birth; it does not supply this complete unit.',
        'Mishpatim 3:218–221 covers service, release, refusal, blemish and conditional restoration. Paragraph 222 was read; it continues into the separate case of failed reincarnation and childlessness. The selected unit does not claim restoration without the qualifications stated in 221. Printed alternate אתבר is retained literally and explicitly as a variant.',
        'Mishpatim 8:395 selection begins דבצלותא and ends ונאמן, a complete interpretation of service as prayer. The limitation to someone unable to pray is retained. The surrounding 396–397 comparison of prayer with Shema was read. The precise current primary locator is 8:395, mapped to 115b; the author’s manuscript reference 116b remains unchanged.',
        'Likkutei Maamarim, Festivals 14:1 closing paragraph belongs at section 252’s God-as-heart anchor. Section 12 note 2675 quotes the different earlier discussion of prayer, atonement and discernment. The selected unit retains its opening account of human intellect and closing preference for refuge in God.',
        'Pri Etz Chaim, Gate of The New Month, Chanukah, and Purim 3:29–30: read adjacent paragraphs 28 and 31 as well as the selected end of 29 and all of 30. Exact source unit preserves Esau’s holy spark, the hope of rectification, explicit reincarnation, compressed causal clause and burial explanation. Anchor ends immediately after Esau, before Ishmael. This source establishes only the Esau half; neither the Ishmael half nor the body’s attribution to the Zohar was established. Native English parallels in Sanhedrin/Berakhot about pushing away a pupil are distinct passages, not complete duplicates.',
    ],
    'dedupScope': 'Full existing sefer native notes, connected-ideas catalog, source-connections catalog, and final proposal packs. Same-source native English-only quotations and additional diagnostic English phrase matches were read manually.',
    'frozenOriginal29': 'Original ois-241-245, ois-246-250 and ois-251-255 files were not modified by this review.',
}
out = HERE / 'supplemental-peer-review-241-255.json'
out.write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: audit[k] for k in ['status', 'candidateCount', 'errors', 'remainingWholeSeferCompleteQuoteDuplicates', 'crossBatchCompleteQuoteDuplicates']}, ensure_ascii=False))
