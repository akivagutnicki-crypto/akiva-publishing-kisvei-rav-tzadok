import json,re,html,hashlib
from pathlib import Path
HERE=Path(__file__).parent
ROOT=HERE.parents[1]
B=ROOT/'live-baseline/mcp-data/text'
BASE=HERE/'public'
def plain(t):
    if isinstance(t,list):t=' '.join(plain(x) for x in t)
    return ' '.join(html.unescape(re.sub('<[^>]*>','',t)).replace('\u200e','').replace('\u200f','').split())
def bare(t):return re.sub('[\u0591-\u05bd\u05bf-\u05c2\u05c4-\u05c5\u05c7]','',plain(t))
def local(book,ref):
    r=next(r for r in json.loads((B/f'{book}.json').read_text())['paras'] if r['r']==ref)
    return plain([x[0] for x in r['p']]) if 'p' in r else plain(r['t'])
def cut(t,a,b=None):
    i=t.index(a)
    return t[i:] if b is None else t[i:t.index(b,i)+len(b)]
def cb(t,a,b=None):
    positions=[i for i,c in enumerate(t) if not re.match('[\u0591-\u05bd\u05bf-\u05c2\u05c4-\u05c5\u05c7]',c)]
    u=''.join(t[i] for i in positions);start=u.index(a)
    if b is None:return t[positions[start]:]
    stop=u.index(b,start)+len(b)
    return t[positions[start]:positions[stop] if stop<len(positions) else len(t)]
def cached(ref,*inds):
    t=json.loads((HERE/'primary.json').read_text())[ref]['data']['he']
    for i in inds:t=t[i-1]
    return plain(t)
def allnotes():
    for p in sorted((ROOT/'live-baseline/library/data/tzidkat-hatzadik').glob('*.json')):
        if not p.stem.isdigit():continue
        for r in json.loads(p.read_text()):
            for n in r.get('footnotes',[]):yield int(p.stem)+1,n
def references(term):
    return [(s,n['number'],n) for s,n in allnotes() if term.lower() in ' '.join(x.get('ref','') for x in n.get('sources',[])).lower()]
PAGES={241:(326,331,325,331),242:(331,336,331,336),243:(336,342,336,341),244:(342,348,341,349),245:(348,359,349,359),246:(359,369,359,369),247:(369,377,369,375),248:(377,379,375,379),249:(379,384,379,384),250:(384,390,384,390),251:(390,395,390,396),252:(395,404,396,404),253:(404,410,404,410),254:(410,418,410,416),255:(418,423,416,420)}
def pages(s):
    a,b,c,d=PAGES[s];return {'neimosB':list(range(a,b+1)),'integratedB':list(range(c,d+1))}
class Batch:
    def __init__(self,start,end=None):self.start=start;self.end=end or start+4;self.entries=[]
    def add(self,s,id,pi,ref,he,en,ctx,book=None,url=None):
        en=en.replace('[','(').replace(']',')')
        rows=json.loads((BASE/f'{s}.json').read_text());r=next(r for r in rows if r.get('n')==1)
        prefix=plain(r['p'][pi][0]);url=url or ('#/read/'+ref.replace(' ','_') if book else 'https://www.sefaria.org/'+ref.replace(' ','_'));he=plain(he)
        ev={'ref':ref,'url':url,'he':he,'en':en,'heSha256':hashlib.sha256(he.encode()).hexdigest(),'translation':'Original English translation prepared directly from the original Hebrew or Aramaic source.','coverage':'Complete selected source unit with the qualifications necessary to its meaning.'}
        if book:
            assert he in local(book,ref),(s,id,'not contiguous canonical text')
            ev.update(canonicalReaderRef=ref,canonicalSourceFile=f'mcp-data/text/{book}.json')
        else:ev['retrievalCache']='review-work/final241/primary.json'
        e={'section':s,'id':id,'rowN':1,'phraseIndex':pi,'heAnchorPrefix':prefix,'heCharOffset':len(prefix),'ref':ref,'url':url,'he':he,'en':en,'context':ctx,'sourceEvidence':[ev],'reviewEvidence':{'pdfPages':pages(s),'preserveExisting':True,'status':'verified','dedup':'Full-sefer existing source references and quotation text compared, including English-only native notes.','method':'Current public body and notes reviewed; both supplied editions inspected for source leads; selected original sources read in context; exact current-public Hebrew prefix checked.'}}
        if book:e['readerRef']=ref
        else:e['openExternal']=True
        self.entries.append(e)
    def save(self,decisions,observations=None):
        catalog=json.loads((ROOT/'live-baseline/library/connected-ideas/catalog.json').read_text());coverage=[]
        for s in range(self.start,self.end+1):
            f=BASE/f'{s}.json';rows=json.loads(f.read_text());notes=[n for r in rows for n in r.get('footnotes',[])]
            coverage.append({'section':s,'status':'original-source-gap-review','bothSuppliedEditionsRead':False,'suppliedEditionReviewScope':'Both section ranges inspected for original-source leads; not claiming a new word-by-word collation of every explanatory line.','pdfPages':pages(s),'existingNativeNumbersPreserved':[n['number'] for n in notes],'existingConnectedSourcesPreserved':[r['targetRef'] for r in catalog['records'] if r.get('originRef','').startswith(f'Tzidkat HaTzadik {s}:')],'baselineSha256':hashlib.sha256(f.read_bytes()).hexdigest(),'additions':sum(e['section']==s for e in self.entries),'decisions':decisions[s]})
        result={'schemaVersion':1,'reviewedSections':list(range(self.start,self.end+1)),'reviewMode':'Add only missing original-source quotations; preserve every existing note and all body text.','entries':self.entries,'coverage':coverage,'observationsNotApplied':observations or [],'sourceVerification':'Each selected source read in its original context and translated directly. Internal quotations preserve exact contiguous canonical-reader Hebrew; no explanatory Context paragraphs belong in published notes.','reproducibleBuilder':f'review-work/final241/build-{self.start}-{self.end}.py'}
        p=HERE/f'ois-{self.start}-{self.end}.json';p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(str(p),len(self.entries))
