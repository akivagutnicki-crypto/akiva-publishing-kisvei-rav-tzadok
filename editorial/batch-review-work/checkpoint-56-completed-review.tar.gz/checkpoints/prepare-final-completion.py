"""Build the final, self-contained research and publication evidence checkpoint."""
import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent


def read(name):
    return json.loads((ROOT / name).read_text())


def build():
    status = read('final-review-status-20261025.json')
    completion = read('final-completion-20261025.json')
    assert status['confirmedLiveThrough'] == 264
    assert status['totalPublishedAdditions'] == 1371
    assert not status['remainingBatches']
    assert completion['ok'] is True
    assert completion['continuationNewNotes'] == 285
    assert completion['confirmedLiveThrough'] == 264

    previous = read('checkpoints/checkpoint-55-manifest.json')
    selected = {entry['path'] for entry in previous.get('files', previous.get('entries', []))}
    for directory in ('final211', 'final221', 'final226', 'final241', 'final256'):
        for path in (ROOT / directory).rglob('*'):
            # Full copied libraries are reproducible from the pinned publication;
            # retain the selected primary snapshots and editorial evidence here.
            if any(part in ('canonical', 'baseline', 'live', 'public') for part in path.relative_to(ROOT / directory).parts[:-1]):
                continue
            if path.is_file() and path.suffix in ('.json', '.py', '.mjs', '.md', '.txt'):
                selected.add(path.relative_to(ROOT).as_posix())
    selected.update(path.name for path in ROOT.glob('final-*.json'))
    selected.update([
        'coverage-gap-audit-241-255.json',
        'source-preview-repair-static-verification.json',
        'local-source-preview-independent-review.json',
        'resisei5-source-preview-diagnosis.json',
        'checkpoints/prepare-final-completion.py',
    ])
    for first, last in ((211, 225), (226, 240), (241, 255), (256, 264)):
        selected.add(f'release-{first}-{last}-verification.json')
        directory = ROOT / f'release{first}-evidence'
        if first == 256:
            directory /= 'successful-retry'
        assert directory.is_dir(), directory
        for path in directory.glob('*.json'):
            selected.add(path.relative_to(ROOT).as_posix())
        for name in ('local-report.json', 'live-report.json', 'tzidkat-batch-live-verification.json'):
            matches = list(directory.rglob(name))
            assert matches, (directory, name)
            selected.update(path.relative_to(ROOT).as_posix() for path in matches)
        report_name = f'tzidkat-batch-review-{first}-{last}-20261025.json'
        matches = list(directory.rglob(report_name))
        assert len(matches) == 1, (directory, report_name, len(matches))
        selected.add(matches[0].relative_to(ROOT).as_posix())

    for first, names in {
        211: ('live-ois225-1280.png', 'live-ois221-390.png'),
        226: ('live-ois240-1280.png', 'live-ois237-390.png'),
        241: ('live-ois255-1280.png', 'live-ois246-390.png'),
        256: ('live-ois264-1280.png', 'live-ois262-390.png'),
    }.items():
        directory = ROOT / f'release{first}-evidence'
        if first == 256:
            directory /= 'successful-retry'
        for name in names:
            matches = list(directory.rglob(name))
            assert len(matches) == 1, (name, len(matches))
            selected.add(matches[0].relative_to(ROOT).as_posix())

    failed = ROOT / 'release256-evidence/failed-attempt-1'
    selected.update(path.relative_to(ROOT).as_posix() for path in failed.glob('*.json'))
    log = failed / 'github-failed-job.log'
    if log.exists():
        selected.add(log.relative_to(ROOT).as_posix())

    archive_path = OUT / 'checkpoint-56-completed-review.tar.gz'
    manifest_path = OUT / 'checkpoint-56-manifest.json'
    entries = []
    with archive_path.open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for name in sorted(selected):
                    path = (ROOT / name).resolve()
                    assert path.is_relative_to(ROOT) and path.is_file(), name
                    data = path.read_bytes()
                    if path.suffix == '.json':
                        json.loads(data)
                    entries.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
                    info = tarfile.TarInfo(name)
                    info.size, info.mode, info.mtime = len(data), 0o644, 0
                    archive.addfile(info, io.BytesIO(data))
    data = archive_path.read_bytes()
    manifest = {
        'checkpoint': 56,
        'confirmedLiveThrough': 264,
        'continuationNewNotes': 285,
        'totalPublishedAdditions': 1371,
        'liveCommit': completion['liveCommit'],
        'liveRun': completion['liveRun'],
        'archive': archive_path.name,
        'archiveBytes': len(data),
        'archiveSha256': hashlib.sha256(data).hexdigest(),
        'entries': entries,
    }
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    with tarfile.open(archive_path, 'r:gz') as archive:
        members = archive.getmembers()
        assert [member.name for member in members] == [entry['path'] for entry in entries]
        for member, entry in zip(members, entries):
            assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == entry['sha256']
    print(json.dumps({key: value for key, value in manifest.items() if key != 'entries'} | {'files': len(entries)}))


if __name__ == '__main__':
    build()
