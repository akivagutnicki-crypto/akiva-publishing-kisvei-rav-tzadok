import glob, json, pathlib, re, sys
ROOT = pathlib.Path(__file__).resolve().parent.parent
def he(value): return re.sub('[^א-ת]', '', value)
def stem(ref):
    ref = ref.lower().replace('–', '-').replace('_', ' ')
    match = re.match(r'^(.*?\d+[ab]?)(?:[:\-]|$)', ref)
    return match[1] if match else ref
old = []
for filename in glob.glob(str(ROOT / 'live-baseline/library/data/tzidkat-hatzadik/*.json')):
    if not pathlib.Path(filename).stem.isdigit(): continue
    section = int(pathlib.Path(filename).stem) + 1
    for row in json.load(open(filename)):
        for note in row.get('footnotes', []):
            excerpt = note.get('reviewedSourceExcerpt', {})
            old.append({'section': section, 'number': note['number'], 'refs': [s['ref'] for s in note.get('sources', [])], 'he': excerpt.get('he', ''), 'en': '\n'.join(p['text'] for p in note.get('paragraphs', []))})
known={(x['section'],x['number'])for x in old}
for rec in json.load(open(ROOT/'live-baseline/library/connected-ideas/catalog.json'))['records']:
    match=re.match(r'^Tzidkat HaTzadik (\d+)',rec.get('originRef',''))
    if not match:continue
    section=int(match[1]);number=rec.get('footnoteNumber',rec['id'])
    if (section,number)in known:continue
    old.append({'section':section,'number':number,'catalog':'connected-ideas','refs':[rec['targetRef']],'he':rec.get('targetHebrew',''),'en':rec.get('targetEnglish','')})
for rec in json.load(open(ROOT/'live-baseline/library/source-connections/catalog.json'))['records']:
    match=re.match(r'^Tzidkat HaTzadik (\d+)',rec.get('targetRef',''))
    if not match:continue
    old.append({'section':int(match[1]),'number':rec.get('footnoteNumber',rec['id']),'catalog':'source-connections','refs':rec.get('sourceRefs',[]),'he':rec.get('sourceHebrew',''),'en':rec.get('sourceEnglish','')})
result = []
for filename in sys.argv[1:]:
    for entry in json.load(open(filename))['entries']:
        eh = he(entry['he'])
        exact = [x for x in old if x['he'] and eh in he(x['he'])]
        same = [x for x in old if any(stem(ref) == stem(entry['ref']) for ref in x['refs'])]
        if exact or same:
            result.append({'section': entry['section'], 'id': entry['id'], 'ref': entry['ref'], 'he': entry['he'], 'en': entry['en'], 'exactHebrew': exact, 'sameSource': same})
print(json.dumps(result, ensure_ascii=False, indent=2))
