import json,hashlib,re,html
from pathlib import Path
HERE=Path(__file__).parent;WORK=HERE.parent;ROOT=WORK.parent
extra={
 'kohelet-rabbah-the-young-and-old-inclinations':{'section':219,'reviewedAddition':'kohelet-rabbah-the-good-inclination-at-thirteen'},
 'megillah-outward-worship-and-the-threat':{'section':228,'number':1687,'reviewedAddition':'megillah-outward-bowing-and-the-outward-decree','coverage':'Existing paragraph9 plus the earlier new batch’s complete paragraph10 together supply the whole selected passage.'},
 'yoma-the-five-differences-between-the-temples':{'section':93,'number':393},
 'sukkah-messiah-son-of-joseph-and-the-inclination':{'section':47,'number':158,'additionalSection':157,'additionalNumber':912},
 'megillah-moshes-birth-and-death-in-adar':{'section':259,'number':2102},
 'berakhot-the-leaven-within':{'section':263,'number':2171,'additionalSection':262,'additionalNumber':2141},
 'zohar-nogah-and-its-holy-aspect':{'section':228,'number':1697},
 'shemot-rabbah-praise-from-the-wicked':{'section':258,'number':2060},
 'bereshit-rabbah-the-burning-palace':{'section':228,'number':1686,'additionalSection':189,'additionalNumber':1229},
 'kiddushin-a-taste-of-the-fruit-of-deeds':{'section':145,'number':813},
}
report=[]
def plain(t):return ' '.join(html.unescape(re.sub('<[^>]*>','',t)).split())
for name in ['ois-256-260','ois-261-261','ois-262-262']:
 p=json.loads((WORK/(name+'.json')).read_text())
 matches=json.loads((HERE/(name+'-existing-duplicates.json')).read_text())
 duplicates={x['id']:x['matches']for x in matches}
 kept=[]
 for e in p['entries']:
  if e['id']in duplicates or e['id']in extra:
   decision={'section':e['section'],'id':e['id'],'ref':e['ref'],'reason':'Source quotation already supplied in published notes elsewhere in the sefer.','existing':duplicates.get(e['id'],extra.get(e['id']))}
   report.append(decision);p.setdefault('observationsNotApplied',[]).append(decision)
  else:
   if e['id']=='divrei-soferim-torah-purifies-like-fire':
    r=next(r for r in json.loads((ROOT/'live-baseline/mcp-data/text/divrei-soferim.json').read_text())['paras']if r['r']=='Divrei Soferim 26:1')
    lead=r['p'][3][0];lead=lead[lead.index('וְכָךְ אֵשׁ שֶׁל גֵּיהִנֹּם'):]
    e['he']=plain(lead+' '+r['p'][4][0])
    for ev in e['sourceEvidence']:
     ev['he']=e['he'];ev['heSha256']=hashlib.sha256(e['he'].encode()).hexdigest()
    e['reviewEvidence']['finalAdjustment']='Included the immediately preceding Hebrew words identifying the fire of Gehinnom, matching the opening of the complete English translation.'
   e['reviewEvidence']['wholeSeferDedup']='Checked full Hebrew containment and native English source quotations across all 264 sections; duplicate full passages excluded.'
   kept.append(e)
 p['entries']=kept
 for c in p.get('coverage',[]):
  c['additions']=[e['id']for e in kept if e['section']==c['section']]
 (HERE/(name+'.json')).write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
 print(name,len(kept))
(HERE/'dedup-decisions-256-262.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
parts=[json.loads((HERE/(name+'.json')).read_text())for name in['ois-261-261','ois-262-262','ois-263-264']]
combined={**parts[0],'reviewedSections':list(range(261,265)),'entries':sum([p['entries']for p in parts],[]),'coverage':sum([p['coverage']for p in parts],[]),'observationsNotApplied':sum([p.get('observationsNotApplied',[])for p in parts],[])}
(HERE/'ois-261-264.json').write_text(json.dumps(combined,ensure_ascii=False,indent=2)+'\n')
print('combined261-264',len(combined['entries']))
