import json,pathlib,re,html,hashlib,unicodedata,collections
R=pathlib.Path(__file__).resolve().parent
ROOT=R.parent.parent
entries=[]
observations=[]
OMIT={
 'resisei-layla-the-thorns-do-not-define-the-inner-soul':{'section':75,'number':2913},
 'rashi-all-beginnings-are-difficult':{'section':170,'number':3467},
 'resisei-layla-soul-exchange-during-sleep-and-its-remedy':{'section':238,'number':2492},
}
def clean(t):
    t=re.sub(r'<sup\b[^>]*class="footnote-marker"[^>]*>.*?</sup>','',t,flags=re.S)
    t=re.sub(r'<i\b[^>]*class="footnote"[^>]*>.*?</i>','',t,flags=re.S)
    return re.sub(r'\s+',' ',html.unescape(re.sub('<[^>]*>','',t))).strip()
def unpointed(t):return ''.join(c for c in t if not unicodedata.combining(c))
def primary(name, ix=None, folder=None):
    path=(folder or R/'primary')/(name.replace('/','_').replace(' ','_')+'.json')
    j=json.load(open(path));v=j['he']
    if ix is not None:
        for i in (ix if isinstance(ix,list) else [ix]):v=v[i-1]
    def flatten(a):
        if isinstance(a,list):return ' '.join(flatten(x) for x in a)
        return a
    if isinstance(v,list):v=flatten(v)
    return unpointed(clean(v)),str(path.relative_to(ROOT))
def canonical(name,ref):
    p=ROOT/'live-baseline/mcp-data/text'/f'{name}.json'
    j=json.load(open(p));a=[a for a in j['paras'] if a['r']==ref]
    assert len(a)==1,(ref,len(a))
    a=a[0];t=' '.join(x[0] for x in a['p']) if 'p'in a else a['t']
    return unpointed(clean(t)),str(p.relative_to(ROOT))
def cut(t,start=None,end=None):
    if start:t=t[t.index(start):]
    if end:t=t[:t.index(end)+len(end)]
    return t
def add(section,id,phrase,ref,source,en,context,pages,he=None,internal=False):
    if id in OMIT:
        observations.append({'section':section,'id':id,'ref':ref,'decision':'omit-new-quotation','reason':'Already quoted completely in the current public sefer, including connected-source catalog entries.','existing':OMIT[id]})
        save()
        return
    if ref in {'Mesillat Yesharim 26:22-23','Magen Avraham 46:10','Tzidkat HaTzadik 91:1'}:
        en=en.replace('[','(').replace(']',')')
    text,cache=source
    he=he if he is not None else text
    assert unpointed(he) in unpointed(text),(ref,'source selection not found')
    row=json.load(open(R/'live'/f'{section}.json'))[0]
    prefix=clean(row['p'][phrase][0])
    url=('#/read/' if internal else 'https://www.sefaria.org/')+ref.replace(' ','_')
    e={'section':section,'id':id,'rowN':1,'phraseIndex':phrase,'heAnchorPrefix':prefix,'heCharOffset':len(prefix),'ref':ref,'url':url,'he':he,'en':en,'context':context,
       'sourceEvidence':[{'ref':ref,'url':url,'he':he,'en':en,'heSha256':hashlib.sha256(he.encode()).hexdigest(),'translation':'Original English translation prepared directly from the Hebrew or Aramaic primary source.','coverage':'Complete selected source argument; essential qualifications retained.','retrievalCache':cache}],
       'reviewEvidence':{'pdfPages':pages,'preserveExisting':True,'status':'verified','method':'Source-edition pointers compared with independently retrieved primary text; full selected Hebrew and original translation read; exact public phrase prefix validated.','dedup':'Whole-sefer Hebrew and matching-source English comparison completed in final audit.'}}
    e['reviewEvidence'].update({
        'independentScholarlyStatus':'accepted',
        'independentReviewer':'root',
        'independentReview':'Root independently read all22 new Hebrew/Aramaic quotations and original English translations and checked their exact anchors; no substantive correction. English square brackets changed to parentheses for house consistency; Hebrew unchanged.',
        'wholeSeferDedupStatus':'accepted-after-native-and-connected-catalog-review',
    })
    if id=='tzidkat-actions-sustain-corresponding-creatures':
        e['reviewEvidence']['independentReview']='Root independently read all 22 new Hebrew/Aramaic quotations and original English translations and checked their exact anchors. English square brackets changed to parentheses. Root subsequently replaced the external abbreviated Hebrew with the same selected unit from the linked internal canonical text and corrected “as they said” to “as it is written”; canonical Hebrew, translation, and evidence remain aligned.'
    if internal:e['readerRef']=ref
    else:e['openExternal']=True
    entries.append(e)
    save()
def save():
    counts=collections.Counter(e['section'] for e in entries)
    out={'schemaVersion':1,'reviewedSections':[236,237,238,239,240],'reviewMode':'Independently verified original-source quotations; public body and all existing notes preserved. Context fields are internal audit only.','entries':entries,'coverage':[], 'observationsNotApplied':observations,'sourceVerification':'Selected quotations checked against bounded Sefaria public responses or complete current public canonical primary texts.','reproducibleBuilder':'review-work/final226/build236.py'}
    for n in range(236,241):
        p=R/'live'/f'{n}.json';rows=json.load(open(p))
        out['coverage'].append({'section':n,'status':'in-progress' if n not in completed else 'complete-add-only-review','existingNativeNumbersPreserved':[f['number'] for row in rows for f in row.get('footnotes',[])],'baselineSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'additions':counts[n]})
    (R/'ois-236-240.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
completed=set()

# Ois 236: renewal, speech, and the unity of name and will.
s=canonical('likkutei-maamarim','Likkutei Maamarim, Compositions on the Festivals 13:3')
t=unpointed(s[0]);h=cut(t,'ובספר הישר לרבנו תם','ועל זה אמרו (בראשית רבה פרשה ט, ו): "\'טוב מאד\' – זו שינה".')
add(236,'likkutei-maamarim-falls-sleep-and-renewed-service',0,'Likkutei Maamarim, Compositions on the Festivals 13:3',s,
'Rabbenu Tam also mentions this in Sefer HaYashar: a person has times when he desires something and times when he recoils from it; see there. These are the familiar falls referred to by the verse, “A righteous person falls seven times and rises”: a person does not remain at his level without moving away from his service even for a moment. Since he was created with an inclination, if he remained that way it would be impossible to separate evil from good at all. This separation takes place through the power of repentance, and is accomplished through the sleep in between. Afterward he wakes from his sleep, returns, and regrets; through this, evil is gradually separated from good. The good remains by itself, while the evil passes away during the periods of sleep. Without sleep, however, separation is impossible; one could only make the evil good and transform it. This cannot be accomplished completely in this world, in which the evil inclination has already been created. Concerning this they said: “Very good”—this is sleep.',
'Direct parallel for the opening account of unavoidable falls and recovery; the final qualification distinguishes gradual separation from complete transformation in this world.',{'integratedB':[296],'neimosB':[296]},he=h,internal=True)

s=primary('Jerusalem Talmud Berakhot 5:1',3)
h=cut(s[0],'אַף אֵלִיָּהוּ') if 'אַף אֵלִיָּהוּ' in s[0] else cut(s[0],'אף אליהו')
add(236,'yerushalmi-elijah-and-elisha-depart-with-torah',11,'Jerusalem Talmud Berakhot 5:1:3',s,
'Elijah, too, parted from Elisha only amid words of Torah: “As they were walking, walking and speaking.” What were they occupied with? Rabbi Achvah son of Rabbi Zeira said: They were occupied with the recitation of Shema, as it says, “You shall speak of them.” Rabbi Yehudah ben Pazi said: They were occupied with the creation of the world, as it says, “By the word of the Lord the heavens were made.” Rabbi Yudan son of Rabbi Aivu said: They were occupied with consolations for Jerusalem, as it says, “Speak to the heart of Jerusalem.” The Rabbis said: They were occupied with the divine chariot, as it says, “And behold, a chariot of fire and horses of fire,” and so forth.',
'The explicitly cited Yerushalmi source is distinct from the existing Taanit quotation. All four explanations of their speech are retained.',{'integratedB':[298],'neimosB':[298]},he=h)

s=primary('Shenei Luchot HaBerit, Toldot Adam, Beit Hashem 1-30',19)
h=cut(s[0],'אמנם למעלה')
add(236,'shelah-the-name-and-the-will',23,'Shenei Luchot HaBerit, Toldot Adam, Beit Hashem 19',s,
'But above, in the highest heights, at the root of the roots of the roots, before the revelation of emanation, “He” and “His name” are one essence. There the Great Name is related only to the will, insofar as He wills to bestow goodness so that the modes of being and the names may be apprehended. This will is the source of the modes of being and their names, and He and His name are one: there “He” is His name, and His name is “He.” This is hinted at in the word hu, “He,” whose initial letters signify “He and His name are one.” There the name Y-H-V-H is neither read nor written even in thought, even by Michael the great prince. When we speak there in the highest heights of His essence, we mean the mystery of the will: the concealment beyond the name Y-H-V-H, as stated. This will, in the supreme concealment beyond all concealments, is called “His name,” for shemo, “His name,” has the same numerical value as ratzon, “will.” This alludes to the profound concealment of Y-H-V-H, which amounts to the numerical value of shemo and ratzon. How? Y-H multiplied by Y-H, and V-H multiplied by V-H, amounts to shemo.',
'The printed paragraph numbering differs from the digital segmentation. The exact passage is Beit Hashem19, and directly states the gematria invoked in the body.',{'integratedB':[300],'neimosB':[300]},he=h)

s=primary('Tanya, Part II; Shaar HaYichud VehaEmunah 8',1)
add(236,'tanya-the-unity-of-essence-will-and-attributes',24,'Tanya, Part II; Shaar HaYichud VehaEmunah 8:1',s,
'What Rambam, of blessed memory, wrote—that the Holy One, blessed be He, His being, His essence, and His knowledge are all truly one, a simple unity with no composition at all—applies in precisely the same way to all the attributes of the Holy One, blessed be He, and to all His holy names and the descriptions given to Him by the prophets and our Sages, of blessed memory, such as “gracious,” “merciful,” “kind,” and the like. The same applies to His being called “wise,” as it is written, “He too is wise,” and to His will: “The Lord desires those who fear Him,” “He desires kindness,” “He desires the repentance of the wicked and does not desire their death and their wickedness,” and “too pure of eyes to behold evil.” His will, His wisdom, His kindness, His compassion, and His other attributes add no plurality or composition, God forbid, to His being and essence. Rather, His essence and being, His will, His wisdom, His understanding and knowledge, His kindness and might, His compassion and beauty comprising His kindness and might, and likewise all His other holy attributes, are all a truly simple unity, which is His very essence and being.',
'Supplies the explicit qualification that the attributes and will are a simple unity, the point of the following body phrase.',{'integratedB':[300],'neimosB':[300,301]})
completed.add(236);save()

# Ois 237: Shabbat, the received teaching on letters, and the inner center.
s=canonical('peri-tzadik','Peri Tzadik, Mishpatim 2:2')
h=cut(s[0],"רק הפי' דעל ידי שמירת שבת",'אם יתקעו שופר בעיר ועם לא יחרדו.')
add(237,'peri-tzadik-shabbat-arouses-awe-and-repentance',4,'Peri Tzadik, Mishpatim 2:2',s,
'Rather, the explanation is that through observing Shabbat one merits awe and fear, as the Jerusalem Talmud says: “The awe of Shabbat rests upon an unlearned person.” Through awe he comes to repentance, as has often been explained from the Talmud: awe and repentance are one, for each depends on the other. This is “the lower Shabbat is awe, and awe rests within it,” as stated in the Zohar. This is the shofar, which signifies fear and awe, as it is said: “If a shofar is sounded in a city, will the people not tremble?”',
'This passage expressly connects Shabbat’s restorative power with awe leading to repentance, preserving the qualification against automatic forgiveness without repentance.',{'integratedB':[301,302],'neimosB':[301]},he=h,internal=True)

s=canonical('mei-hashiloach','Mei HaShiloach, Volume I, Leviticus, Behar 3')
add(237,'mei-hashiloach-large-and-small-letters-shabbat-and-shemittah',14,'Mei HaShiloach, Volume I, Leviticus, Behar 3',s,
'“The land shall rest a Sabbath to the Lord.” The meaning of the sabbatical year is that it is a sign for Israel that “the earth and all that fills it belong to the Lord.” As stated in the holy Zohar, there are large letters and small letters. The small letters signify Shabbat, for Shabbat is a sign to Israel that the blessed God brings about everything and that nothing is accomplished through human actions. The large letters signify the sabbatical year: when seven years have passed, there must be an entire year in which it is shown that the earth belongs to the Lord, and that no person possesses the power of action; it belongs to the Lord alone.',
'The precise written parallel for the received teaching on the large and small letters and their manifestation as years and days.',{'integratedB':[302],'neimosB':[302]},internal=True)

s=primary('Rashi on Exodus 21:1',2)
add(237,'rashi-setting-the-laws-before-them-with-their-reasons',27,'Rashi on Exodus 21:1:2',s,
'“Which you shall set before them”: The Holy One, blessed be He, said to Moses: Do not think of saying, “I will repeat the chapter and the law to them two or three times, until they have it arranged in their mouths as it was taught, but I will not trouble myself to make them understand the reasons for the matter and its explanation.” Therefore it says, “Which you shall set before them”—like a table set and prepared before a person for eating.',
'The missing direct source for understanding the reason, rather than merely repeating the rule.',{'integratedB':[303],'neimosB':[303,304]})

s=primary('Sefer Yetzirah 4:3')
add(237,'sefer-yetzirah-six-directions-and-the-central-sanctuary',55,'Sefer Yetzirah 4:3',s,
'The seven double letters—bet, gimel, dalet, kaf, pe, resh, and tav—correspond to seven extremities. Six of them are the extremities above and below, east and west, north and south; the Holy Palace is aligned in the center and sustains them all.',
'Direct source for the six extremities and the central seventh; digital text differs in its opening wording from the commentary-edition quotation.',{'integratedB':[304],'neimosB':[305]})

s=primary('Derekh Chayim 5:15',11)
h=cut(s[0],'מספר שבעה מורה')
add(237,'maharal-the-seventh-as-the-nonphysical-center',55,'Derekh Chayyim 5:15:11',s,
'The number seven signifies the level at which the physical and the nonphysical are joined. It is known that seven corresponds to the six extremities and the center, which is called the “Holy Palace” among them. This is known to those who understand: seven corresponds to the six extremities and the Holy Palace among them. The six extremities are especially related to the physical, for they possess extension, and extension belongs to a body. The center, however, has no extension at all, for extension does not apply to the center; it is therefore related to the nonphysical. This is why they called the center the “Holy Palace” within the six extremities: it is separate from the physical, and this is its holiness.',
'Maharal explains the significance of the central seventh, beyond merely listing the six directions in Sefer Yetzirah.',{'integratedB':[304],'neimosB':[305]},he=h)

s=canonical('resisei-layla','Resisei Layla 10:2')
h=cut(s[0],'וכמו שאמרו בסנהדרין (מד.):','שמצד קומת היושר יש מדרגות בנפשות.')
add(237,'resisei-layla-the-thorns-do-not-define-the-inner-soul',56,'Resisei Layla 10:2',s,
'As they said in Sanhedrin: “It is like a myrtle standing among thorns; its name is myrtle,” and so forth. They compared the sins surrounding a person to thorns surrounding a rose. They are not part of the person’s essence; rather, they surround and encompass him from the aspect of his outward extension. But from the aspect of the very essence of an Israelite soul, there is no sin at all. There are, however, levels in the degree of cleaving, and in this respect the differences belong to the souls themselves, for in the upright configuration there are different levels among souls.',
'The direct parallel explains the rose-and-thorns image while retaining the distinction between essential attachment and different attained levels of cleaving.',{'integratedB':[304,305],'neimosB':[305]},he=h,internal=True)

s=canonical('peri-tzadik','Peri Tzadik, Yitro 9:1')
h=cut(s[0],'אך הענין שבדברות ראשונות','שהוא בהשתדלות מהאדם.')
add(237,'peri-tzadik-remember-and-guard-before-and-after-the-fall',104,'Peri Tzadik, Yitro 9:1',s,
'The explanation is that in the first tablets it is written, “Remember.” The Zohar describes a place where there is no forgetting and forgetting does not abide. As the Midrash says, when Israel heard “I am,” Torah study became fixed in their hearts, and when they heard “You shall have no other,” the evil inclination was uprooted from their hearts. It was enough to remember verbally at the beginning of Shabbat, and throughout Shabbat one would be guarded by the holiness of Shabbat, which is fixed and established by the blessed God. In the second tablets, after the damage, it is written, “Guard”: guarding is required all day so that one does not cause damage, God forbid. As the Midrash on Psalms says: “What was created on the seventh day? Shabbat,” and so forth; “He found it entirely holiness and rest,” and so forth. “Afterward He saw that a person sins on it and incurs guilt against his life, and said, ‘This too is vanity.’” Since Scripture speaks of “those who desecrate it,” the evil inclination can enter and cause someone to desecrate Shabbat, God forbid. “Guard” is therefore required through awe, which involves human effort.',
'This parallel explains the specific distinction made at the end of237, rather than simply repeating the existing remember-and-guard Talmud quotation.',{'integratedB':[308],'neimosB':[308]},he=h,internal=True)
completed.add(237);save()

# Ois 238: renewal in sleep and the contributions of successive generations.
s=primary('Beit Yosef, Orach Chayim 4:2-30',[4,1])
h=cut(s[0],'ואם תשאל מאי שנא תפלת השחר','קודם עבודתו עכ"ל')
add(238,'beit-yosef-new-creation-and-morning-sanctification',12,'Beit Yosef, Orach Chayim 4:5:1',s,
'If you ask: Why is the morning prayer different from the afternoon and evening prayers? It may be answered: Because in the morning we become like a new creation, as it is written, “New every morning; great is Your faithfulness.” We must thank Him, blessed be He, for creating us for His glory, to serve Him and bless His name. For this reason they instituted in the morning all those blessings that we recite each and every morning. We must therefore sanctify ourselves with His holiness and wash our hands from a vessel, like a priest who sanctifies his hands from the basin before his service. This concludes his words.',
'Beit Yosef quotes Rashba’s explanation of morning washing and the morning blessings. This selected unit does not present a practical ruling for someone who stayed awake all night.',{'integratedB':[309],'neimosB':[309,310]},he=h)

s=primary('Rashi on Exodus 19:5:1')
add(238,'rashi-all-beginnings-are-difficult',21,'Rashi on Exodus 19:5:1',s,
'“And now”: If you accept it upon yourselves now, it will become pleasant for you from this point onward, for all beginnings are difficult. (Mekhilta.)',
'Direct formulation of the cited rule; the promise that the difficulty gives way to pleasantness is preserved.',{'integratedB':[309],'neimosB':[310]})

s=primary('Pri Etz Chaim, Gate of the Recitation of the Shema Before Retiring 1',3,ROOT/'review-work/final221/source-cache')
h=cut(s[0],'אך השינה ביום')
add(238,'ari-daytime-sleep-and-the-preservation-of-ibbur',23,'Pri Etz Chaim, Gate of the Recitation of the Shema Before Retiring 1:3',s,
'Sleep during the day is harmful for the righteous and beneficial for the wicked. This is what our Sages said: “Sleep for the wicked is beneficial to them and beneficial to the world.” The explanation is that, through his deeds, a righteous person may receive the souls of the righteous in ibbur when he sleeps at night. His soul returns to him and draws with it the souls of the righteous to assist him. When he sleeps during the day, those souls return and separate from him. In particular, at night a person deposits his soul in the care of Malkhut, and it returns pure, clear, and complete. During the day, however, the soul finds no resting place in which to be deposited, and therefore loses what it received at night. With the wicked, the opposite occurs: at night they are not taken into safekeeping beneath the wings of the Shekhinah, and their souls wander through the world and draw out souls of the wicked, which come with them in ibbur. If they sleep during the day, it is possible that, through a good deed those wicked people performed that day, these souls will separate from them when they sleep. Thus there are righteous people to whom the lot of the wicked comes, and wicked people to whom the lot of the righteous comes. However, for a person of great standing, like the earlier sages, it is possible that even if he sleeps during the day, he will gain as he does at night.',
'Full relevant source account, including the final exception for a person of exceptional spiritual standing, which the discovery-edition quotation omitted.',{'integratedB':[309,310],'neimosB':[310]},he=h)

s=primary('Akeidat Yitzchak 67:2-10',[7,16])
h=cut(s[0],'כי מחשבות הרשע הנפסדות','כמו שהוא מפורש בפ\' שמיני שער ס\'.')
add(238,'akeidat-yitzchak-regret-even-after-evil-actions',41,'Akeidat Yitzchak 67:8:16',s,
'For the wicked person’s corrupt thoughts sadden their owner’s soul and continually cause it pain, because it was hewn from an exalted place. Even though it consents to evil deeds, it becomes distressed after doing them or when contemplating them. The philosopher wrote this in chapter five of the ninth book of the Ethics: “The wicked are full of regrets,” and so forth. They also tend to be continually distressed by fear of the punishments that will overtake them, as the wise man said: “What the wicked person fears will come upon him,” as explained in the discussion of Shemini, gate sixty.',
'A precisely located early written formulation of the regret saying. It attributes the formulation to the philosopher, not to a fabricated Talmudic source; no body correction applied.',{'integratedB':[311],'neimosB':[311]},he=h)

s=canonical('poked-akarim','Poked Akarim 6:1')
h=cut(s[0],'כי כל דור ההולך,','ורק הטוב הוא הנשאר והנקבע בכל הלבבות.')
add(238,'poked-akarim-the-enduring-merit-of-earlier-generations',60,'Poked Akarim 6:1',s,
'For every generation that passes, its Torah and commandments remain and become fixed in the hearts of the children of Israel in the next generation. Were it otherwise, what purpose would the length of the exile serve, while the generations grow ever smaller? Where would there be hope of meriting the coming of the Messiah, speedily in our days, when the earlier generations, greater and better than these, did not merit it? Although the generations themselves grow smaller and are called the “footsteps of the Messiah,” because their souls are from the heels, nevertheless all the merits of all the earlier generations, and all the Torah and commandments they acquired in this world, remain fixed and firmly planted in the depths of the hearts of the last generation. From this perspective, each later generation possesses an advantage of preparedness and standing. The familiar comparison made concerning wisdom—a dwarf atop a giant—also applies to service, Torah, and commandments. From this perspective the generations continually ascend from level to level, through the additional merits and attainments renewed in every generation, which remain forever. Sins and deficiencies, however, are cleansed by death; they gradually pass away, and nothing of them remains. Only the good remains and becomes fixed in all hearts.',
'This supplies the mechanism of accumulated merit; the existing native Resisei13 quotation supplies the dwarf-and-giant image, so that complete passage is not repeated.',{'integratedB':[312],'neimosB':[313,314]},he=h,internal=True)
completed.add(238);save()

# Ois 239: soul exchange and the conditions of spiritual repair.
s=primary('Mesillat Yesharim 26:22-23')
add(239,'mesillat-yesharim-materiality-finds-its-own-kind',51,'Mesillat Yesharim 26:22-23',s,
'What helps one attain this quality [holiness] is solitude and extensive withdrawal, so that, in the absence of distractions, one’s soul can strengthen itself more fully and cleave to the Creator. What damages this quality is a lack of true knowledge and excessive association with people, for materiality finds its own kind, awakens, and gains strength. The soul then remains trapped within it and cannot leave its imprisonment.',
'Ramchal applies the same finds-its-kind expression to the spiritual effects of company and materiality. The paired enabling and damaging conditions are both retained.',{'integratedB':[316],'neimosB':[317]})

s=canonical('resisei-layla','Resisei Layla 3:1')
add(239,'resisei-layla-soul-exchange-during-sleep-and-its-remedy',69,'Resisei Layla 3:1',s,
'During sleep it is possible for a soul to be exchanged. Our Sages expounded in the Midrash on Psalms, on the verse “New every morning,” that the Holy One, blessed be He, does not exchange souls. This implies that an exchange is possible, but the Holy One, blessed be He, is faithful and does not exchange what is deposited with Him. This applies to one who deposits his soul in the care of the Holy One, blessed be He, saying, “Into Your hand I entrust my spirit.” But for one who considers everything chance and the world merely following its ordinary course, an exchange can occur. They said that sleep is one sixtieth of death. Just as they said regarding the state after death, “If the righteous person merits it, he takes his own share and his fellow’s share in the Garden of Eden; if the wicked person is found guilty,” and so forth, so during sleep the good portion in a wicked person’s soul may be exchanged and come to another who merits it, while he takes in the evil in his fellow. Concerning the conduct of the wicked it says that they rose early in the morning, and conversely we find: “May we rise early and find our heart’s hope,” and so forth. This is what they said: “Sleep for the wicked is beneficial to them”—in accordance with their way—“and beneficial to the world.” The reverse applies to the righteous: although a righteous person takes in that good, it is nevertheless mixed with much evil at its original root and requires cleansing and repair. Thus it is harmful to them and harmful to the world, whose creatures lose that good when he takes it in during sleep. The counsel for both is the recitation of Shema before bed and a verse of mercy, “Into Your hand I entrust my spirit.” No evil goes forth from Him, blessed be He, to any creature in the world; therefore everything will be for good.',
'Complete direct parallel on the interchange described here. Includes its qualification about entrusting the soul and its concluding counsel; not a substitute for the Ari quotation in238.',{'integratedB':[309,317],'neimosB':[318,319]},internal=True)

s=primary('Magen Avraham 46:10')
add(239,'magen-avraham-nighttime-attachment-of-another-soul',70,'Magen Avraham 46:10',s,
'“Even a convert”: This means that he should say, “Who made me a convert,” for this is called making, as it is written, “The souls that they made in Haran.” [Darkhei Moshe.] Shelah and Bach wrote that it is inappropriate to say this, because becoming a convert resulted from his own choice to choose the religion of Israel. He should therefore not recite this blessing, but only the two concerning a slave and a woman. This concludes their words. According to their view, one must say that “Who did not make me a slave” refers to his original creation. Although at his original creation his status was inferior to that of a slave, nevertheless, if he had been a slave he could not have converted unless his master freed him. But according to what the kabbalists wrote, these blessings are recited concerning the soul’s departure at night—that the soul of a gentile or a slave did not attach itself to it. If so, a convert, too, can recite them in this form.',
'The complete comment preserves the differing halakhic views before the final kabbalistic explanation, so the quoted phrase these blessings has its original context.',{'integratedB':[318],'neimosB':[319]})

s=primary("Sha'ar HaKavanot, Sermons on the Falling on the Face Prayer 2",4)
h=cut(s[0],'ובזה תבין סוד גדול','שיהיה צדיק גמור או שעל הפחות יכוין בתפי\' ההיא מתחלתה ועד סופה כנ"ל')
add(239,'ari-yochanan-the-high-priest-and-nefilat-apayim',76,"Sha'ar HaKavanot, Sermons on the Falling on the Face Prayer 2:4",s,
'Through this you will understand a great mystery. We have observed a puzzling matter: sometimes a person is completely righteous and afterward becomes another person and turns completely wicked, as we find with Yochanan the High Priest, who served in the priesthood for eighty years and ultimately became a Sadducee. The explanation is that when a person surrenders his soul to death during the falling-on-the-face prayer, down to the place of the shell, some sin he has committed may prevent his soul from ascending from there. The shells seize it, and it remains there forever; they then give him another, evil soul from the side of the shells. This is what our Sages meant when they said that the wicked are called dead even during their lifetimes: during the falling-on-the-face prayer they descend to the place of death and remain there, their souls do not emerge, and an evil soul is given them in exchange. They do not perceive this within themselves, and then become completely wicked, may the Merciful One save us. Therefore I warn you very strongly about this: a person directing his intention during the falling-on-the-face prayer in the manner described must be completely righteous, or at least direct his intention throughout that prayer from beginning to end, as explained above.',
'Original Ari account behind the reference to Yochanan. It describes replacement by another soul; the body’s ibbur formulation is preserved without alteration. The source’s express condition for this intention is retained.',{'integratedB':[317],'neimosB':[319,320]},he=h)
completed.add(239);save()

# Ois 240: eating, reincarnation, and refinement through wisdom.
s=primary("Sha'ar HaMitzvot, Eikev 22-23")
h=cut(s[0],"והרי נת' ענין האכילה בשתי בחינותי'")
add(240,'ari-eating-and-the-repair-of-reincarnated-souls',6,"Sha'ar HaMitzvot, Eikev 22-23",s,
'The matter of eating has thus been explained in its two aspects. The first is to repair and separate out the dross in that food, and the second is to repair the souls reincarnated in that food. A person must therefore exercise the greatest care while eating and not eat like cattle and other living creatures that do not distinguish good from evil. Our Sages accordingly spoke at length about this, saying that a table resembles an altar, because the altar accomplished these two things. They also said that the table atones for a person’s sins, and made many similar statements. Since some souls reincarnated because of the transgressions they committed may be present in that food—or even in the water one drinks—or even if no reincarnated soul is present and there are only the dross and shells within the food, which is the first aspect: if the person eating is righteous and a Torah scholar, not only will these not become mixed into his soul, but, on the contrary, he will repair them, separate the food from the waste, and repair those reincarnated souls, as will be explained. But if the person is wicked or unlearned, not only does he fail to repair them; through his deeds he may actually damage and spoil the souls reincarnated there, or that food, beyond their existing damage. There is a third possibility as well: they may instead overpower him, cause him to sin, and lead him along an evil path, until they bring his soul harm from which he cannot be healed. This is the mystery of those people upon whom a harsh and evil occurrence sometimes suddenly comes, who change their religion, God forbid, and leave the faith, as in the case of Yochanan the High Priest who became a Sadducee, and similar cases. Everything depends on the character of the reincarnated soul that became mixed with him—whether it was completely wicked or not. Know that an unlearned person does not repair any level at all, even a soul reincarnated in an animal. If he eats that animal’s meat, he cannot repair it, and certainly cannot repair what is reincarnated in a plant, and still less in the inanimate. For someone reincarnated in the inanimate must rise through three levels. Even if he rises through them together, as explained above—for example, when a person eats a little earth—he still requires a far greater repair than one who rises through only two levels, and greater power is needed to repair him. Likewise, one lacking only one level is repaired much more easily than one needing two levels. An unlearned person lacks the power to separate, repair, and raise even one level. It would follow that he should be forbidden even inanimate and plant food. However, because he is not to be penalized for failing to repair two or three levels together, he is permitted inanimate and plant food. Animal flesh, however, is forbidden to him, because he lacks the power to repair even one level, from animal to human.',
'The original source explicitly treats both food’s sparks and reincarnated souls, with the distinction between a Torah scholar and an unlearned person and the permission for plant food. It is quoted as a mystical source, not applied as a new practical ruling.',{'integratedB':[320],'neimosB':[322]},he=h)

s=primary("Sha'ar HaGilgulim 3",1)
h=cut(s[0],"הנה בחי' העבור היא בחיים",'נתעברה נפש דוד ביונתן.')
add(240,'ari-ibbur-through-a-mitzvah-during-life',21,"Sha'ar HaGilgulim 3:1",s,
'Ibbur takes place during life, as explained above. That is, sometimes a person encounters a particular commandment and performs it properly. A soul of an earlier righteous person who performed that same commandment properly then becomes available to him. Since they resemble one another in this commandment, that righteous person’s soul enters him in ibbur. Moreover, it is also possible for this to happen while that righteous person is living at the same time as he is. When this person performs a commandment, or commandments related to that righteous person, which the righteous person also performed properly in the same way, that righteous person’s soul enters him in ibbur even while both are alive. This is the mystery of the verse, “David’s soul became attached to Jonathan”: while both were alive together, David’s soul entered Jonathan in ibbur.',
'The source’s wording concerning David and Jonathan is retained exactly, although its formulation reverses the order in1Samuel18:1. This is the precise source for an additional soul-power acquired through a deed rather than at birth.',{'integratedB':[321],'neimosB':[322]},he=h)

s=canonical('tzidkat-hatzadik','Tzidkat HaTzadik 91:1')
h=cut(s[0],'כל קניני האדם','ובצומחים: סם הממית רחמנא לצלן וכיוצא.')
add(240,'tzidkat-actions-sustain-corresponding-creatures',38,'Tzidkat HaTzadik 91:1',s,
'All a person’s possessions are portions of his vitality extending into created things, as it is written: “In the beginning”—for the sake of Israel, and so forth. We say that He continually renews the work of creation in His goodness every day, and each day the renewal is for Israel’s sake. Every part of the world belongs to a particular Israelite soul; that is, the light of its vitality sustains those creatures. Good deeds sustain good and pure creatures [while thoughts and desires produce angels and spiritual beings]; evil deeds produce evil creatures [in the manner of the saying in Eruvin that the emission of seed in vain produces spirits, demons, and night spirits]: harmful animals, and likewise murderous idolaters. Among inanimate things, this includes a stone used for stoning and wood on which someone was hanged [this is the mystery of the saying in Tanna DeVei Eliyahu that the Holy One, blessed be He, will exact payment from everything, even from a stone, and so forth. This is “Evil pursues sinners,” as well as “I created the destroyer to ruin,” and the teaching in Bereshit Rabbah that fire goes forth from the bodies of the wicked and burns them]. Among growing things, it includes a deadly poison, may the Merciful One save us, and the like.',
'Direct parallel for human actions sustaining corresponding creatures. It is not presented as independent identification of the oral teacher. Later portions of91 already quoted at86 and197 are not repeated.',{'integratedB':[322],'neimosB':[323]},he=h,internal=True)

s=primary('Keter Shem Tov 1:208:2-209:1')
h=cut(s[0],'ועיקר הבירור של השבירה')
add(240,'keter-shem-tov-refinement-through-wisdom-and-detachment',63,'Keter Shem Tov 1:208:2-209:1',s,
'The essential refinement of the shattered vessels cannot take place if a person is attached to, desires, and delights in physical pleasure, God forbid. How could he separate out what is pure if he willingly desires the waste? Rather, refinement takes place through cleaving to the blessed God with love and awe, and bringing everything through awe to “nothing,” which is wisdom. This means understanding that physical pleasure is vanity and comes to be despised in his eyes. Of his own will he would not enjoy such physical pleasures as eating, drinking, and sexual relations, except because of the Creator’s commandment and because they also contain a spark of the Creator’s love and delight. Through this, the delight separates itself from the waste, and desire for the waste becomes repugnant to him through wisdom. It is like a wise person who is brought an inferior object—a coin or a garment—covered with a very fine color. A fool imagines that it is entirely good, but the wise person understands that only the color is good. This is what the Zohar says: “Everything is refined through wisdom.”',
'Exact original teaching underlying the discovery editions’ citation209a. The digital text spans208:2 and209:1; both halves are included, preserving the condition of love, awe, and detachment.',{'integratedB':[324],'neimosB':[325]},he=h)
completed.add(240);save()

s=primary('Zohar, Pekudei 51:663-674',11)
add(240,'zohar-refining-the-dross-within-thought',63,'Zohar, Pekudei 51:673',s,
'Come and see: At the head, the beginning of faith, within thought, the lamp of impenetrable darkness struck and rose within thought—another reading: and brought forth—sparks. It cast glimmering sparks (Vayikra 292b) in three hundred and twenty directions, separated dross from within thought, and was refined.',
'Traditional ZoharII254b maps through the primary index to Pekudei51:673. Its exact wording concerns thought; Keter Shem Tov supplies the wisdom formulation used in the body. The printed alternative reading is translated rather than silently discarded.',{'integratedB':[323],'neimosB':[325]})
observations.extend([
 {'section':236,'decision':'omit-repeat','ref':'Rashi on Berakhot 25a:1:1','reason':'Already quoted in ois6 note21, ois194 note1266, and ois208 note3715.'},
 {'section':236,'decision':'omit-repeat','ref':'Bava Metzia 85b:6','reason':'The operative teaching method and conclusion that Torah not be forgotten are already quoted in ois188 note1218; the prayer passage is already present locally.'},
 {'section':238,'decision':'omit-repeat','ref':"Sha'ar HaGilgulim 1:12-13",'reason':'Already quoted in ois165 note3446, including the qualification that the highest soul remains in its place.'},
 {'section':238,'decision':'omit-repeat','ref':"Sha'ar HaGilgulim 38:154",'reason':'Already quoted in ois165 note3449; the additional later-generations passage selected here instead concerns accumulated merit.'},
 {'section':239,'decision':'omit-repeat','ref':'Tanya, Part I; Likkutei Amarim 48:3-4','reason':'Same passage selected by the211–215 batch at213; no second complete quotation added.'},
 {'section':239,'decision':'omit-repeat','ref':'Likkutei Maamarim, On Shimshon 1','reason':'The same crown-as-nothing source segment is selected by the261–264 batch at264.'},
 {'section':240,'decision':'no-unverified-attribution','observation':'No independent written Mei HaShiloach source identified for the reported oral teaching about actions producing animals. Tzidkat91 supplies a verified direct parallel without assigning an unverified oral source.'},
 {'section':240,'decision':'source-wording-preserved','ref':"Sha'ar HaGilgulim 3:1",'observation':'The source itself says David’s soul attached to Jonathan, reversing the order of1Samuel18:1. Original quotation retained; body and existing notes untouched.'},
])
entries.sort(key=lambda e:(e['section'],e['phraseIndex'],e['id']))
save()
