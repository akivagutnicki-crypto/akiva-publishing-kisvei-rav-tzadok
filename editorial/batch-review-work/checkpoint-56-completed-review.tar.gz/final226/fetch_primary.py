import concurrent.futures, json, pathlib, sys, urllib.request, urllib.parse, time
OUT=pathlib.Path(__file__).parent/'primary'
OUT.mkdir(exist_ok=True)
def get(ref):
    path=OUT/(ref.replace('/','_').replace(' ','_')+'.json')
    if path.exists():
        return ref, 'cached'
    url='https://www.sefaria.org/api/texts/'+urllib.parse.quote(ref.replace(' ','_'),safe=':,.')+'?context=0'
    try:
        with urllib.request.urlopen(url, timeout=25) as response:
            raw=response.read()
        data=json.loads(raw)
        if 'error' in data:return ref, data['error']
        data['_retrieval']={'url':url,'retrievedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
        path.write_text(json.dumps(data,ensure_ascii=False,indent=2))
        return ref, 'saved '+str(len(raw))
    except Exception as e:return ref,str(e)
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:
    for r in ex.map(get,sys.argv[1:]):print(*r,sep=' | ')
