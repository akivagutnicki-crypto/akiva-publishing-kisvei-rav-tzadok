from pathlib import Path
import json,re,html,hashlib
R=Path(__file__).parent; W=R.parent

def plain(t):
 if isinstance(t,list):return ' '.join(plain(x) for x in t)
 return ' '.join(html.unescape(re.sub('<[^>]*>','',str(t))).split())
def norm(t):return re.sub('[^א-ת]','',plain(t))
cache=[]
for d in ['review-136-150','review121','review151','review196','review256']:
 for f in (W/d).glob('*.json'):
  if 'primary' not in f.name and not any(x in f.name for x in ['guide','brit','asara']):continue
  try:o=json.loads(f.read_text())
  except:continue
  if not isinstance(o,dict):continue
  for k,v in o.items():
   if not isinstance(v,dict):continue
   t=v.get('he') or v.get('data',{}).get('he') or [a.get('text','') for a in v.get('versions',[]) if a.get('language') in ['he','source']]
   if t:cache.append((k,str(f.relative_to(W)),norm(t)))
canonical=[]
for f in (R/'canonical').glob('*.json'):
 d=json.loads(f.read_text())
 for p in d.get('paras',[]):canonical.append((p['r'],str(f),plain([x[0] for x in p['p']]) if 'p' in p else plain(p.get('t',''))))
allout=[]
for name in ['ois-226-230.json','ois-231-235.json']:
 d=json.loads((W/name).read_text()); results=[]
 for e in d['entries']:
  rows=json.loads((R/'live'/f"{e['section']}.json").read_text());row=next(r for r in rows if r['n']==e['rowN'])
  matches=[(k,f) for k,f,v in cache if norm(e['he']) in v]
  imatches=[(k,f) for k,f,v in canonical if k==e.get('readerRef',e['ref']) and norm(e['he']) in norm(v)]
  anchors=plain(row['p'][e['phraseIndex']][0]).startswith(e['heAnchorPrefix'])
  refs=[]
  for r in rows:
   for n in r.get('footnotes',[]):
    for s in n.get('sources',[]):
     if s.get('ref')==e['ref']:refs.append(n['number'])
  results.append({'id':e['id'],'section':e['section'],'ref':e['ref'],'exactAnchor':anchors,'primaryMatches':matches,'canonicalMatches':imatches,'sameRefExistingNotes':refs})
 for v in results:
  if not v['exactAnchor'] or (not v['primaryMatches'] and not v['canonicalMatches']) or v['sameRefExistingNotes']:print(v)
 allout.extend(results)
(R/'recovered-structural-audit.json').write_text(json.dumps(allout,ensure_ascii=False,indent=2)+'\n')
print('Audited',len(allout),'entries;',sum(bool(x['primaryMatches'] or x['canonicalMatches']) for x in allout),'source matches;',sum(x['exactAnchor'] for x in allout),'exact anchors')
