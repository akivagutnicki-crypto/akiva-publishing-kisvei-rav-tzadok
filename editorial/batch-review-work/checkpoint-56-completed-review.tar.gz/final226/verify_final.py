from pathlib import Path
import json,re,html,hashlib,collections
R=Path(__file__).resolve().parent
ROOT=R.parent.parent
def plain(x):
    if isinstance(x,list):return ' '.join(plain(v) for v in x)
    return re.sub(r'\s+',' ',html.unescape(re.sub('<[^>]*>','',str(x)))).strip()
def norm(x):return re.sub('[^א-ת]','',plain(x))
pool=[]
def register(j,f,key=''):
    if not isinstance(j,dict):return
    text=j.get('he') or j.get('data',{}).get('he') if isinstance(j.get('data',{}),dict) else j.get('he')
    if not text:text=[v.get('text','') for v in j.get('versions',[]) if isinstance(v,dict) and v.get('language') in ('he','source')]
    if text:pool.append((j.get('ref',key),str(f.relative_to(ROOT)),norm(text)))
    else:
        for k,v in j.items():
            if isinstance(v,dict):register(v,f,k)
for d in ['review-136-150','review121','review151','review196','review256']:
    for f in (R.parent/d).glob('*.json'):
        if 'primary' not in f.name and not any(s in f.name for s in ['guide','brit','asara']):continue
        try:register(json.loads(f.read_text()),f)
        except Exception:pass
for f in (R/'primary').glob('*.json'):
    register(json.loads(f.read_text()),f)
for f in (ROOT/'live-baseline/mcp-data/text').glob('*.json'):
    j=json.loads(f.read_text())
    if not isinstance(j,dict):continue
    for p in j.get('paras',[]):
        he=[x[0] for x in p['p']] if 'p'in p else p.get('t','')
        pool.append((p['r'],str(f.relative_to(ROOT)),norm(he)))
results=[];ids=set()
for name in ['ois-226-230.json','ois-231-235.json','ois-236-240.json']:
    j=json.loads((R/name).read_text())
    for e in j['entries']:
        row=next(x for x in json.loads((R/'live'/f"{e['section']}.json").read_text()) if x['n']==e['rowN'])
        anchor=plain(row['p'][e['phraseIndex']][0]).startswith(e['heAnchorPrefix'])
        needle=norm(e['he'])
        matches=[{'ref':ref,'file':file} for ref,file,he in pool if needle and needle in he]
        exactref=[x for x in matches if x['ref']==e['ref']]
        ev=e['sourceEvidence'][0]
        result={'section':e['section'],'id':e['id'],'ref':e['ref'],'exactPublicAnchor':anchor,'correctOffset':len(e['heAnchorPrefix'])==e.get('heCharOffset',len(e['heAnchorPrefix'])),'primarySourceMatched':bool(matches),'exactRefMatched':bool(exactref),'matches':exactref or matches,'evidenceTextMatches':ev['he']==e['he'] and ev['en']==e['en'],'sourceHashMatches':ev['heSha256']==hashlib.sha256(e['he'].encode()).hexdigest(),'uniqueId':e['id'] not in ids}
        ids.add(e['id']);results.append(result)
        if not all(result[k] for k in ['exactPublicAnchor','correctOffset','primarySourceMatched','evidenceTextMatches','sourceHashMatches','uniqueId']):print('FAIL',result)
audit={'reviewedSections':list(range(226,241)),'entries':len(results),'countsBySection':dict(collections.Counter(x['section'] for x in results)),'allAnchorsPass':all(x['exactPublicAnchor'] and x['correctOffset'] for x in results),'allPrimarySelectionsPass':all(x['primarySourceMatched'] for x in results),'allEvidenceConsistent':all(x['evidenceTextMatches'] and x['sourceHashMatches'] for x in results),'entriesDetail':results}
(R/'final-structural-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print({k:v for k,v in audit.items() if k!='entriesDetail'})
