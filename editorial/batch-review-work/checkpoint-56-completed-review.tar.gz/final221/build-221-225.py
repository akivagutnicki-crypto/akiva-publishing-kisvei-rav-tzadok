import json,re,html,hashlib,urllib.parse
from pathlib import Path
HERE=Path(__file__).parent
ROOT=HERE.parent.parent
BASE=ROOT/'live-baseline/library/data/tzidkat-hatzadik'
TEXT=ROOT/'live-baseline/mcp-data/text'
CACHE=HERE/'source-cache'
NIK=r'[\u0591-\u05bd\u05bf-\u05c2\u05c4-\u05c5\u05c7]'
def plain(t):
    if isinstance(t,list):t=' '.join(plain(v)for v in t)
    t=re.sub(r'<sup class="footnote-marker">.*?</sup>\s*<i class="footnote">.*?</i>','',t,flags=re.S)
    return ' '.join(html.unescape(re.sub('<[^>]*>','',t)).replace('\u200e','').replace('\u200f','').split())
def bare(t):return re.sub(NIK,'',plain(t))
def external(key,lo=None,hi=None):
    x=json.loads((CACHE/(key.replace(' ','_').replace("'",'').replace('/','_')+'.json')).read_text())['he']
    if lo is not None:x=x[lo-1:hi]if hi is not None else x[lo-1]
    return bare(x)
def row(book,ref):return next(r for r in json.loads((TEXT/(book+'.json')).read_text())['paras']if r['r']==ref)
def local(book,ref,a=None,b=None):
    r=row(book,ref)
    if 'p'in r:
        ps=r['p']if a is None else r['p'][a:b]
        return plain([p[0]for p in ps])
    assert a is None
    return plain(r['t'])
def cut(t,a,b):
    pos=[i for i,c in enumerate(t)if not re.match(NIK,c)]
    z=''.join(t[i]for i in pos)
    i=z.index(a);j=z.index(b,i)+len(b)
    return t[pos[i]:pos[j]if j<len(pos)else len(t)]
pages={221:{'neimosB':list(range(197,204)),'integratedB':list(range(205,213))},222:{'neimosB':list(range(204,208)),'integratedB':list(range(212,216))},223:{'neimosB':list(range(208,214)),'integratedB':list(range(215,221))},224:{'neimosB':list(range(214,222)),'integratedB':list(range(220,228))},225:{'neimosB':list(range(222,228)),'integratedB':list(range(227,233))}}
entries=[]
def add(s,id,pi,ref,he,en,ctx,book=None,url=None):
    he=plain(he);en=plain(en).replace("[", "(").replace("]", ")")
    en=re.sub(r'(?<=[A-Za-z])(?=\d)', ' ',en)
    en=re.sub(r',(?=\d)', ', ',en)
    en=en.replace('the fear of the small interceding creature is upon the lion','the lion’s fear of the mafgi’a').replace('the white of an egg that is not unfertilized','the white of a fertile egg')
    r=next(r for r in json.loads((BASE/f'{s-1}.json').read_text())if r['n']==1)
    anchor=plain(r['p'][pi][0])
    if url is None:url=('#/read/'if book else'https://www.sefaria.org/')+ref.replace(' ','_')
    ev={'ref':ref,'url':url,'he':he,'en':en,'heSha256':hashlib.sha256(he.encode()).hexdigest(),'translation':'Original English translation prepared directly from the quoted Hebrew or Aramaic.','coverage':'Complete selected source unit, including the qualifications needed to its meaning.'}
    if book:
        assert he in local(book,ref),(id,'canonical containment')
        ev.update(canonicalReaderRef=ref,canonicalSourceFile=f'mcp-data/text/{book}.json')
    else:ev['retrievalCache']='review-work/final221/source-cache'
    entries.append({'section':s,'id':id,'rowN':1,'phraseIndex':pi,'heAnchorPrefix':anchor,'heCharOffset':len(anchor),'ref':ref,'url':url,'he':he,'en':en,'context':ctx,'sourceEvidence':[ev],'reviewEvidence':{'pdfPages':pages[s],'preserveExisting':True,'status':'verified','method':'Both supplied editions and the published author text read; selected primary sources checked directly; original translations and exact Hebrew anchors prepared.','dedup':'Whole-sefer native and connected source comparison is recorded in the accompanying review.'},**({'readerRef':ref}if book else{'openExternal':True})})

ref='Peri Tzadik, Nitzavim 5:1'
he=cut(local('peri-tzadik',ref),'ושמעת בקולו הוא','כמו"ש מהבעש"ט ז"ל.')
add(221,'peri-tzadik-the-continuing-voice-of-sinai',9,ref,he,
'''“And you shall listen to His voice” accords with what we said in the preceding portion: this is why it says everywhere, “If you shall surely listen to the voice of the Lord your God,” although the voices sounded only at the giving of the Torah. Rather, this refers to what is said in the sixth chapter of Avot: Every day a heavenly voice goes forth from Mount Chorev and proclaims, “Woe to the creatures because of the Torah’s humiliation.” This remains from the voices at the giving of the Torah, concerning which it says there, “All the people see the voices”—“see” in the present tense. The heavenly voice is the awakening that comes into the heart of every Jew, as is reported in the name of the Baal Shem Tov, of blessed memory.''',
'A direct parallel identifies the ongoing Sinai voice with the inward awakening described here.','peri-tzadik')

ref='Divrei Chalomot 23:1'
add(221,'divrei-chalomot-angelic-wisdom-and-human-understanding',19,ref,local('divrei-chalomot',ref,12,37),
'''As I heard concerning the wording of the Tikkunim, “You are wise, but not with a known wisdom; You understand, but not with a known understanding”: wisdom is the intellect’s knowledge in the brain, whereas understanding is the heart’s feeling. Angels possess knowledge through the wisdom God imparts to them, but they do not possess the heart’s feeling. [This is as I wrote: nothing can be felt in the heart unless its opposite also exists in the heart. Angels do not possess free choice, and therefore they are called “the enduring ones,” for they are fixed and enduring as God created them, without change. Their wisdom, too, is fixed and enduring, each according to what God imparted to it at its creation. This is called knowledge and wisdom, rather than understanding and feeling in the heart.] Israel possesses [only] understanding, which is the feeling in the heart. [All their wisdom is drawn from the feeling of their heart. Therefore the Talmud commonly says, “According to the heart of Rabbi so-and-so”; I heard that this is an expression of “heart,” for each sage stated every legal teaching only according to the feeling of his heart. Likewise, Sanhedrin 35b says, “People’s hearts forget.” This is the lower wisdom, the wisdom of King Solomon, of blessed memory: the wisdom of the Oral Torah flowing from the hearts of Israel’s sages. Concerning this, Bava Batra 12a says that a sage is superior to a prophet, from the verse, “And we shall bring a heart of wisdom.” Through the wisdom within their hearts, where feeling is found and from which their wisdom flows, it is superior to prophecy, which is through sight. Likewise, concerning wisdom in the heart it says, “My heart has seen much wisdom,” for what a person feels in the heart is as though he sees it with his eyes. At the giving of the Written Torah, too, although it was given from Heaven, it says, “All the people see the voices”: they saw what was heard. Hearing is the brain’s knowledge of what one hears, but seeing comes through the heart’s feeling. This is the essential purpose of giving the Torah to Israel: that it be absorbed into their hearts, as it says, “Write them upon the tablet of your heart,” and concerning the future, “Upon their heart I shall write it.” It says, “If only this heart of theirs would remain theirs,” for “the Merciful One desires the heart,” as Sanhedrin 106b says. The Torah was given principally to the hearts of Israel, as Devarim Rabbah, the portion Berakhah, says: Whoever has fear of Heaven has all the Torah and all wisdom placed within his heart. Fear of Heaven is principally the heart’s feeling, as Yoma 72b says concerning the verse, “But there is no heart.” Therefore it is called “the Torah of Moses,” for in relation to him fear is a small matter, as Berakhot 33b says. He embodies the mystery of knowledge, which, as is known, joins wisdom and understanding. Although the Torah is the wisdom of God, its giver, Israel nevertheless apprehends it only through the heart’s feeling, the understanding by which one understands on one’s own. This is what Rashi writes in the portion Ki Tissa: knowledge is the holy spirit. This is the prophecy of the sages, as Ramban writes in Bava Batra there: what one grasps truthfully through the wisdom of the heart is an influx of the holy spirit flowing from the supernal holiness and wisdom. Therefore Bereshit Rabbah, chapter 17, says, “The fallen fruit of the supernal wisdom is Torah.” This is not the place to elaborate further.] The Holy One, blessed be He, includes both. Yet His wisdom is not a known wisdom: unlike every wise person who knows through wisdom, for whom wisdom is something distinct from the person apprehending it, with God all is one, for He is the knower, and so forth, as Rambam writes in Laws of the Foundations of the Torah 2:10. This is “wise, but not through wisdom,” and likewise “understanding, but not through understanding.” He has feeling, as human beings do, but not through understanding in the manner of someone who understands: that person’s feeling comes from the prior concealment and opposite state, and now he understands, and from this comes feeling. This does not apply at all to the Holy One, blessed be He, but only to separate beings. With Him everything is in unity and essential being. Therefore His understanding is not through understanding, nor in the manner of human feeling through the understanding of the heart. Thus far is the substance of what I heard, with added explanation and elaboration as it appeared to me.''',
'The full contiguous explanation preserves the distinction between human deficiency and divine understanding, together with Rav Tzadok’s attribution and his own elaboration. A later overlapping proposal in section241 is omitted.','divrei-chalomot')

ref='Rashi on Exodus 31:3:1-2'
add(221,'rashi-wisdom-received-and-understanding-from-the-heart',24,ref,external(ref),
'''“Wisdom”: what a person hears from others and learns. “Understanding”: understanding something from his own heart, out of the things he has learned.''',
'The primary definitions supply the distinction between received wisdom and the heart’s own understanding.')

ref='Sichat Malakhei HaSharet 1:20'
he=cut(local('sichat-malakhei-hasharet',ref),'אבל אמתת הדברים','כח שלוח מה\'.')
add(221,'sichat-malakhei-hasharet-angels-as-spiritual-powers',25,ref,he,
'''The truth of the matter is that an angel is the power within each thing: the power that strikes is the angel appointed over striking, and the power that saves is the angel appointed over saving. Every spiritual power created at the creation of the world to serve in the world is what is called an angel—that is, a power sent by God.''',
'The exact canonical reader location is1:20; another edition numbers this discussion21. The quote gives the author’s definition of an angel as a particular spiritual power.','sichat-malakhei-hasharet')

ref='Dover Tzedek, Miscellany 4:72'
add(221,'dover-tzedek-the-heavenly-voice-as-an-echo',31,ref,local('dover-tzedek',ref,9,10),
'''The phenomenon of a reverberating sound is what our Sages call a “bat kol,” a daughter of a voice. The Midrash, at the end of Shemot Rabbah, chapter29, says: A person’s voice has an echo. See Tosafot in the first chapter of Sanhedrin,11a, concerning the statement that when the last prophets died, prophecy departed, yet they still made use of a heavenly voice. Tosafot explains that a bat kol is a reverberation of the voice of God; see there.''',
'This is the direct parallel to the author’s explicit cross-reference explaining a bat kol as the echo of a voice.','dover-tzedek')

ref='Resisei Layla 54:1'
add(221,'resisei-layla-forgetting-and-renewed-joy',35,ref,local('resisei-layla',ref,27,37),
'''For this purpose God created the evil inclination, as they said, “I created the evil inclination; I created Torah as its remedy”: so that there would be a power of concealment through which renewal would become recognizable. This is the sense of “And it shall be, if you indeed forget,” where “and it shall be” signifies joy everywhere, as our Sages said in Bereshit Rabbah, chapter42. For through this comes the intensity of joy when remembrance awakens out of forgetfulness. This is like the familiar parable of a king’s son returning to the king from the land of his captivity—even when he is not actually in a land of captivity, but merely lives in another city, or even in another house, or even in another room. For constant pleasure is no pleasure. Likewise, our Sages, Niddah31b, explain the reason for the days of menstrual separation: to make her beloved to her husband.''',
'The parallel supplies the renewal and reunion argument that explains the closing reference to future joy.','resisei-layla')

ref='Peri Tzadik, Lech Lecha 1:5'
add(222,'peri-tzadik-abraham-purifies-love-and-isaac-embodies-fear',8,ref,local('peri-tzadik',ref),
'''Afterward it is written, “Journeying onward toward the south.” Abraham our father’s level was love, and his attribute was kindness. All his work was to refine his love so that it would be pure, directed to God alone, with no worldly desire entering his heart. This is what “Journeying onward toward the south” means, in the manner of their exposition in Temurah16a: “‘For you have given me a dry land’—a house dried of all goodness.” This is Abraham’s level: he refined his attribute, kindness, so that it would be pure for God, with no worldly desire mixed into it. Concerning Isaac, whose attribute was “the fear of Isaac” and restraint, it is written, “He was dwelling in the land of the south.” He was at ease with this attribute, having become refined in the attribute of restraint, fear, and awe.''',
'This primary parallel explains the contrasting dispositions of Abraham and Isaac used in the account of the daily prayers.','peri-tzadik')

ref='Peri Tzadik, Vayetzei 5:1'
he=cut(local('peri-tzadik',ref),'והוא כי תפלות אבות תקנום','והיינו שיש ביכולת להסיר החשכות ולזכות לאור גדול:')
add(222,'peri-tzadik-the-patriarchal-prayers-through-night',13,ref,he,
'''The patriarchs established the prayers, as the Gemara and Midrash Rabbah say. Abraham established the morning prayer, as it is said, “To the place where he had stood,” and standing means prayer. His prayer is in the morning, in the light of day, alluding to the absence of any darkness before him in the light of God’s holiness; he was as one actually standing before the King. Likewise Isaac established the afternoon prayer, which is also still in daytime. They learned this from “Isaac went out to converse in the field,” and conversation means prayer. For him too, the light of God’s holiness was clear, and he poured out his conversation before Him, as one tells the King his situation and speaks before Him all that is in his heart. Jacob our father, however, saw that he was the purpose of creation in the world and the root of the entire divine chariot. This was when he heard the angels calling him “sun”: “The sun has come.” His name was like that of the Holy One, blessed be He, who is called sun, as it says, “For the Lord God is a sun and shield,” as Sotah10a says. Likewise, Megillah18a says that the Holy One, blessed be He, called Jacob “El”: “He called Jacob El.” Thus he too is called sun, illuminating the holy moon so that it will shine even in the darkness of night. Therefore he lodged there and established the evening prayer, as they expounded from “He encountered the place.” That is, even when a person is in darkness and cannot see the light of His holiness because of the great darkness surrounding him, repentance and prayer can still help him merit seeing light out of darkness. This is “He encountered the place,” for encounter signifies actual attachment, as the word itself indicates. Through attaching himself to the Holy One, blessed be He, he becomes, as it were, the very light of the Holy One. This is “He lodged there”: he established the evening prayer to illuminate the moon, “for the sun had come,” for the angels called him sun, saying, “The sun has come,” as the Midrash concludes, “Who revealed to him that my name is sun?” This is also what it says afterward, “They said: We are from Charan,” which Midrash Rabbah, chapter70, expounds: We are fleeing from the wrath of the Holy One, blessed be He. “He said to them: Do you know Laban?” Midrash Rabbah says: Do you know the One who will whiten your sins like snow? That is, it is possible to remove the darkness and merit a great light.''',
'The complete selected discussion preserves all three prayers and the concluding qualification that repentance and prayer can bring light from darkness.','peri-tzadik')

ref='Divrei Soferim 36:3'
add(222,'divrei-soferim-jacobs-forceful-prayer',14,ref,local('divrei-soferim',ref,8,14),
'''The prayer of Jacob our father, of blessed memory, is described as an encounter: it is forceful prayer, in the manner of the teaching in Taanit23a and Pesikta Rabbati, chapter3, that a righteous person decrees and the Holy One, blessed be He, fulfills. This is called “interceding”; see Taanit7b. It is alluded to in Shabbat77b: the fear of the small interceding creature is upon the lion. Concerning this we say, “For our strength is exhausted, and there is no intercessor on our behalf”—one who comes with the force and strength of our hand, as in “You shall decree a matter, and it shall be established for you.” This is called voice, as it is written, “The voice is the voice of Jacob,” and, “Hear, O Lord, the voice of Judah.” These are the voices at the giving of the Torah, heard from within the fire. Isaac is the fire that gives birth to the voice, and Jacob is the voice itself; his bed is complete, for he encompasses the congregation of Israel, who are the very substance of Torah: “Truth to Jacob,” attached to the living God. He lives forever, as Taanit5b says that he did not die, for he ate from the tree of life. The tree of life is none other than Torah, as Tanna Devei Eliyahu Rabbah, chapter1, says, from “It is a tree of life,” and he is the very substance of Torah.''',
'The relevant paragraph is36:3, distinct from the already quoted36:1. The source’s language of forceful intercession is preserved.','divrei-soferim')

ref='Mei HaShiloach, Volume I, Genesis, Vayigash 7'
add(223,'mei-hashiloach-holiness-accompanies-jacob',8,ref,local('mei-hashiloach',ref),
'''“Israel dwelt in the land of Egypt, in the land of Goshen.” Jacob our father was afraid to go outside the Land, as the Gemara, Ketubot110b, says: Anyone who dwells in the Land of Israel is like one who has a God, and so forth. God told him: Wherever you are is holy with the holiness of the Land of Israel. This explains “Israel dwelt in the land of Egypt, in the land of Goshen”: even in the land of Egypt he was close to God, and it was a sanctified place, for Goshen is an expression of drawing near.''',
'This is a primary parallel from the author’s teacher on the holiness of the Land accompanying a holy person beyond its geographical border.','mei-hashiloach')

ref='Sifra, Acharei Mot, Section 8:4'
add(223,'sifra-the-conduct-of-canaan',16,ref,external('Sifra, Acharei Mot, Section 8',4),
'''From where do we learn that no nation among the nations made its deeds more abominable than the Canaanites? Scripture says, “According to the conduct of the land of Canaan … you shall not act.” From where do we learn that the last generation made its deeds more abominable than all the others? Scripture says, “According to the conduct of the land of Canaan … you shall not act.” From where do we learn that the place where Israel came and conquered made its deeds more abominable than all the others? Scripture says, “To which I am bringing you.” From where do we learn that Israel’s coming occasioned all these deeds for them? Scripture says, “To which I am bringing you, you shall not act.”''',
'The complete original paragraph supplies the author’s explicit Torat Kohanim citation; the digital division isSection8:4.')

ref="Maasei Hashem, Maaseh Avot 10"
url=urllib.parse.quote('https://or-breslev.co.il/wp-content/uploads/מעשי-השם-חלק-א-הרב-אליעזר-אשכנזי-בן-רבי-אליה-הרופא.pdf#page=277',safe=':/#=')
he='''ובענין שהזכיר האמורי יתר על שאר האומות, כתב הרמב"ן שהוא התקיף שבהם, ואין הענין כן שהרי לעולם נקראת ארץ ישראל על שם כנען ארץ כנען חבל נחלתכם והעיקר היה הכנעני. אבל יתכן לדעתי שהאמורי היה הראשון שהתחיל באמונה הרעה ההיא וז׳ עממים נמשכו באמונה ההיא, ולכך נאמר עון האמורי שהוא היה המתחיל באותו עון, וכן נאמר ביהושע ואם רע בעיניכם לעבוד את ה׳ בחרו לכם היום את מי תעבדון אם את אלהים אשר עבדו אבותיכם אשר בעבר הנהר ואם את אלהי האמורי אשר אתם יושבים בארצם וגו׳ וכבר היו יושבים בארץ ז׳ עממים ולא הזכיר רק האמורי שנראה שעבודת כל הז׳ עממים נמשכה מן האמורי.'''
add(223,'maasei-hashem-the-amorite-belief-of-the-seven-nations',19,ref,he,
'''Concerning the mention of the Amorite rather than the other nations, Ramban wrote that it was the strongest among them. But this is not so, for the Land of Israel is always named after Canaan: “The land of Canaan, the portion of your inheritance,” and the Canaanite was the principal one. It seems possible to me, however, that the Amorite was the first to begin that evil belief, and the seven nations were drawn after that belief. Therefore it says “the iniquity of the Amorite,” for it began that iniquity. Likewise, Joshua says, “If it is evil in your eyes to serve the Lord, choose for yourselves today whom you will serve: whether the gods your fathers served beyond the river, or the gods of the Amorite in whose land you dwell,” and so forth. They were already dwelling in the land of the seven nations, yet he mentioned only the Amorite. This indicates that the worship of all seven nations was derived from the Amorite.''',
'The explicitly cited primary work was checked in its full text, PartI, Maaseh Avot chapter10, PDFpage277. The author presents this explanation as his own possibility, and that qualification is retained.',url=url)
entries[-1]['sourceEvidence'][0].update(webSource='https://or-breslev.co.il/books/מעשי-השם-חלק-א-הרב-אליעזר-אשכנזי-בן-רבי/',pdfPage=277,verification='Primary PDF text checked directly at lines9819–9826; punctuation regularized without altering the words.')

ref="Sha'ar HaKavanot, Sermons on the Night Ritual 5:2"
he=cut(external("Sha'ar HaKavanot, Sermons on the Night Ritual 5",2),'ויכוין שבפ\' שמע ישראל','ושהם מתלבשים בו כנז\'')
add(224,'shaar-hakavanot-the-two-shema-paragraphs',16,ref,he,
'''He should intend that in the paragraph “Hear, O Israel” there are forty-two words, corresponding to the forty-two-letter Name, Avgitatz, and so forth. He should intend that he makes his head a chariot for that forty-two-letter Name, and that his head clothes itself in it to ascend above through it, as stated. In the paragraph “And it shall be, if you surely listen,” which has seventy-two words until the word “You shall place,” he should direct his intention toward the seventy-two-letter Name emerging from the verses beginning “And he journeyed,” “And he came,” and “And he stretched out.” He should make his arms and his body down to his belly a chariot for this Name, and intend that they clothe themselves in it, as stated.''',
'The source specifies the counting limits for the two paragraphs and their respective mystical correspondences.')

ref="Sha'ar HaKavanot, Sermons on Kaddish 1:1:6"
he=cut(external("Sha'ar HaKavanot, Sermons on Kaddish 1",6),'וטעם הדבר הוא כי אין שום עליה','משום דאיהו סליק ולא נחית כנז\' פ\' תרומה קל"ב ע"ב.')
add(224,'shaar-hakavanot-ascent-through-the-forty-two-letter-name',17,ref,he,
'''The reason is that there is no ascent in the worlds except through the forty-two-letter Name. This forty-two-letter Name is what raises all the ascents in all the worlds, because it ascends and does not descend, as stated in the portion Terumah,132b.''',
'This direct Ari passage supplies the ascent principle assumed by the author.')

ref='Tikkunei Zohar 78a:3'
he=cut(external('Tikkunei Zohar 78a',3),'וכד איהי סתימא','פקודין דעשה ולא תעשה.')
add(224,'tikkunei-zohar-forty-two-gevurah-and-seventy-two-chesed',17,ref,he,
'''When she is closed, she is called fear: throughout the six weekdays she is closed and guarded by the ten utterances and the thirty-two occurrences of “Elohim,” which are the forty-two letters of Gevurah, where Binah is found. On Shabbat, “The heavens were completed”: “vayekhullu” has the numerical value of “chesed,” the kindness of the right, which encompasses seventy-two names, where Chokhmah is found, as we said: One who wishes to become wise should turn south. Fear applies on the six weekdays: “Each person shall fear his mother and father.” Love applies on Shabbat: “Honor your father and your mother.” When she opens toward her husband, she is called love. From fear and love were given the positive and negative commandments.''',
'The complete selected unit retains the weekdays–Shabbat and fear–love correspondences accompanying the two Names.')

ref='Zohar III 141a'
he='''תנא אמר ר׳ שמעון, כל הני תקונין וכל הני מלין בעינא לגלאה למאריהון דאתקלו במתקלא. ולא לאינון דעאלו ולא נפקו, אלא לאלין דעאלו ונפקו. דכל מאן דעייל ולא נפיק טב ליה דלא אברי.'''
url='https://he.wikisource.org/wiki/'+urllib.parse.quote('זהר_חלק_ג_קמא_א',safe='_')
add(224,'zohar-entering-and-emerging-from-the-mysteries',32,ref,he,
'''It was taught: Rabbi Shimon said, “All these configurations and all these matters I wish to reveal to their masters, who have been weighed in the balance—not to those who entered and did not emerge, but to those who entered and emerged. For anyone who enters and does not emerge would have been better off not being created.”''',
'The exact original passage cited atIII141a is supplied in full.',url=url)
entries[-1]['sourceEvidence'][0]['webSource']='https://he.wikisource.org/wiki/זהר_חלק_ג_קמא_א'

ref='Chidushei Agadot on Chagigah 14b:9'
add(224,'maharsha-rabbi-akiva-remained-within-the-boundary',33,ref,external('Chidushei Agadot on Chagigah 14b',9),
'''“Rabbi Akiva ascended in peace and descended in peace; of him Scripture says, ‘Draw me after You,’” and so forth: Rabbi Akiva was complete in every kind of perfection. When he reached the boundary beyond which human intellect cannot go, he stopped and did not break through to ascend to God. Therefore it says of him, “Draw me after You,” and so forth: he followed the One drawing him and did not enter beyond the boundary. Although he attained what Acher attained, he did not err as Acher erred, and so forth. Thus far the quoted text.''',
'Maharsha quotes an older work explaining Rabbi Akiva’s safe return through recognition of the limits of human apprehension. The closing attribution is retained.')

ref='Rashi on Leviticus 6:21:3'
add(225,'rashi-earthenware-and-absorbed-substance',4,ref,external('Rashi on Leviticus 6:21',3),
'''“It shall be scoured and rinsed”: to expel what it has absorbed. But concerning an earthenware vessel, Scripture teaches you here that it never rids itself of its absorbed taint.''',
'The source makes the earthenware qualification explicit in the analogy of absorption by cooking.')

ref='Jerusalem Talmud Chagigah 2:1:10'
he=cut(external('Jerusalem Talmud Chagigah 2:1',10),'ויש אומרים. אמו כשהיתה מעוברת בו','כאירסה שלחכינה.')
add(225,'yerushalmi-achers-mother-and-the-idolatrous-scent',10,ref,he,
'''Some say: When his mother was pregnant with him, she passed by houses of idolatry and smelled something of that kind. That smell permeated her body like the venom of a serpent.''',
'This distinct Yerushalmi account supplies the literal maternal background alongside the Bavli’s wool-and-dyer analogy. Its attribution as one reported explanation is preserved.')

ref='Mishneh Torah, Offerings for Those with Incomplete Atonement 2:1'
add(225,'rambam-the-character-of-zivah',12,ref,external(ref),
'''The discharge described in the Torah as zav is seminal fluid arising from an illness of the cavities in which it gathers. When the discharge emerges, it does not emerge with an erection as semen does; its emergence involves neither desire nor pleasure. Rather, it trails out like barley dough, dull in appearance like the white of an unfertilized egg. Semen, by contrast, is white and cohesive, like the white of an egg that is not unfertilized.''',
'The original halakhic description distinguishes this discharge from an emission involving desire and supplies the terminology used by the author’s analogy.')

ref='Mei HaShiloach, Volume I, Exodus, Beshalach 1'
add(225,'mei-hashiloach-josephs-bones-and-fear-before-wisdom',14,ref,local('mei-hashiloach',ref,14,40),
'''It is taught in Avot, chapter3, mishnah11: Anyone whose fear of sin precedes his wisdom, his wisdom endures. The meaning is that sometimes God conceals His acts and hides His intention from human beings, and a person does not know God’s will in the matter. This was the situation here: Moses wondered why God had not led them by the way of the land of the Philistines. The counsel for this is that when a person sees God dealing with him in concealment, he should not multiply clever explanations, but engage in the plain practice of the commandments and include himself in the attributes of fear. This is “Moses took the bones of Joseph,” and so forth. For the way of a righteous person is to attribute the deficiency to himself when a doubtful matter comes before him. This is the significance of his taking Joseph’s bones: because he attributed the deficiency to himself, he began to enter the attribute of fear, which Joseph’s bones signify. Joseph the righteous had the attribute of fear, as explained concerning the verse, “Lest He burst forth like fire in the house of Joseph.” This is “Anyone whose fear of sin precedes his wisdom,” and it is the attribute of Joseph the righteous, of blessed memory.''',
'The direct teaching from the author’s teacher supplies both the Joseph interpretation and its application when divine conduct is concealed. The source’s own mishnah numbering is retained.','mei-hashiloach')

entries=[e for e in entries if e['id']!='rashi-wisdom-received-and-understanding-from-the-heart']
out={'schemaVersion':1,'reviewedSections':list(range(221,226)),'reviewMode':'Missing original-source additions only; author text and all existing notes preserved.','entries':entries,'coverage':[],'observationsNotApplied':[{'section':221,'source':'Rashi on Exodus31:3:1–2','reason':'Complete definitions already in section206 note3695.'},{'section':221,'source':'Peri Tzadik, Miketz3:1','reason':'Relevant complete quotation already in section55 note2574.'},{'section':221,'source':'Tanya9:1–2','reason':'The full animal-heart/mind unit is already quoted in sections31 and204.'},{'section':222,'source':'Berakhot26b:5–7','reason':'Complete patriarchal-prayers source already in section200 note3644.'},{'section':224,'source':'Etz Chaim, Shaar HaKlalim2:2','reason':'Complete vessel-breakage quotation already in section171 note3472.'},{'section':225,'source':'Derekh Hashem4:2:5','reason':'Complete Torah-study requirements already in section115 note3188.'}],'sourceVerification':'Primary quotations checked directly; English translated from the selected original units. Context is internal and is not appended to the public notes.','reproducibleBuilder':'review-work/final221/build-221-225.py'}
for s in range(221,226):
    rows=json.loads((BASE/f'{s-1}.json').read_text())
    out['coverage'].append({'section':s,'status':'complete-add-only-review','bothSuppliedEditionsRead':True,'pdfPages':pages[s],'existingNativeNumbersPreserved':[n['number']for r in rows for n in r.get('footnotes',[])],'additions':[e['id']for e in entries if e['section']==s],'decisions':'Author text, supplied original-source pointers, and existing notes reviewed; complete existing quotations retained and missing selected primary units supplied.'})
(HERE/'ois-221-225.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'entries':len(entries),'counts':{s:sum(e['section']==s for e in entries)for s in range(221,226)}}))
