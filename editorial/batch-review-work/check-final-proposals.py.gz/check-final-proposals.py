"""Verify exact anchors and bilingual provenance against the recovered live reader."""
import glob, hashlib, html, json, pathlib, re, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
BASE = ROOT / 'live-baseline'
refs = {}
for filename in glob.glob(str(BASE / 'mcp-data/text/*.json')):
    for row in json.load(open(filename)).get('paras', []):
        refs.setdefault(row['r'], []).append(row)

def he(text):
    return re.sub('[^א-ת]', '', text)

def plain(text):
    return html.unescape(re.sub('<[^>]*>', '', text))

def hebrew(row):
    return ' '.join(pair[0] for pair in row['p']) if 'p' in row else row.get('t', '')

entries = []
for filename in sys.argv[1:]:
    entries.extend(json.load(open(filename))['entries'])
report, errors, identities = [], [], set()
for entry in entries:
    try:
        key = (entry['section'], entry['id'])
        assert key not in identities, 'Duplicate editorial identity'
        identities.add(key)
        chapter = json.load(open(BASE / f"library/data/tzidkat-hatzadik/{entry['section'] - 1}.json"))
        row = next(row for row in chapter if row['n'] == entry['rowN'])
        assert plain(row['p'][entry['phraseIndex']][0]).startswith(entry['heAnchorPrefix']), 'Inexact Hebrew anchor'
        evidence = next((value for value in entry['sourceEvidence'] if value['ref'] == entry['ref'] and value['he'] == entry['he'] and value['en'] == entry['en']), None)
        assert evidence, 'No identical bilingual evidence'
        if evidence.get('heSha256'):
            assert evidence['heSha256'] == hashlib.sha256(entry['he'].encode()).hexdigest(), 'Hebrew evidence hash changed'
        item = {'section': entry['section'], 'id': entry['id'], 'anchorVerified': True, 'identicalBilingualEvidence': True}
        if entry['url'].startswith('#/read/'):
            ref = entry.get('readerRef', entry['ref'])
            candidates = [hebrew(row) for row in refs.get(ref, [])]
            if not candidates:
                match = re.match(r'(.*:)(\d+)-(\d+)$', ref)
                if match:
                    rows = [refs[match[1] + str(i)] for i in range(int(match[2]), int(match[3]) + 1)]
                    # Prefer the reader's interlinear row where a Hebrew-only edition also shares its reference.
                    candidates = [' '.join(hebrew(next((row for row in variants if 'p' in row), variants[0])) for variants in rows)]
            assert candidates, 'Canonical reference not found: ' + ref
            assert any(he(entry['he']) in he(text) for text in candidates), 'Checked Hebrew not contained in canonical reference: ' + ref
            item['canonicalHebrewContained'] = True
        report.append(item)
    except Exception as error:
        errors.append({'section': entry['section'], 'id': entry['id'], 'error': str(error)})

output = {'ok': not errors, 'notes': len(entries), 'canonicalSources': sum('canonicalHebrewContained' in item for item in report), 'entries': report, 'errors': errors}
print(json.dumps(output, ensure_ascii=False, indent=2))
sys.exit(bool(errors))
