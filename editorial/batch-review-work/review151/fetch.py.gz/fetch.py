import json,urllib.request,urllib.parse,concurrent.futures,sys
from pathlib import Path
P=Path(__file__).with_name('primary.json');D=json.loads(P.read_text()) if P.exists() else {}
refs=sys.argv[1:]
def fetch(ref):
 try:
  u='https://www.sefaria.org/api/texts/'+urllib.parse.quote(ref.replace(' ','_'),safe=':,')+'?context=0&pad=0'
  with urllib.request.urlopen(u,timeout=18) as r:d=json.load(r)
  return ref,d
 except Exception as e:return ref,{'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
 for ref,d in pool.map(fetch,[r for r in refs if r not in D or 'error' in D[r]]):
  D[ref]=d;P.write_text(json.dumps(D,ensure_ascii=False,indent=2));print(ref,'ERROR '+str(d['error']) if 'error' in d else d.get('ref'),flush=True)
