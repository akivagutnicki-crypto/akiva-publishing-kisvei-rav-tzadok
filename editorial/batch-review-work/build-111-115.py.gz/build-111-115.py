import json, re, html, hashlib
from pathlib import Path

ROOT = Path('/workspace/scratch/f85ae98f1669')
WORK = ROOT / 'review-work'
BOOKS = ROOT / 'tmp/batch-engineering/current-site/mcp-data/text'
CACHE = json.loads((WORK / 'ois111-primary.json').read_text()) if (WORK / 'ois111-primary.json').exists() else {}
SNAPSHOT = json.loads((WORK / 'ois111-selected-primary.json').read_text()) if (WORK / 'ois111-selected-primary.json').exists() else {}
SELECTED = {}

def flatten(x):
    return ' '.join(flatten(v) for v in x) if isinstance(x, list) else x

def plain(x):
    return html.unescape(re.sub('<[^>]*>', '', x))

def clean(x):
    return ' '.join(re.sub('[\u0591-\u05bd\u05bf-\u05c2\u05c4-\u05c7\u200e\u200f]', '', plain(flatten(x))).split())

def primary(ref, *index):
    key = ref + (' [' + ','.join(map(str, index)) + ']' if index else '')
    if ref not in CACHE:
        SELECTED[key] = SNAPSHOT[key]
        return clean(SELECTED[key]['he'])
    d = CACHE[ref]
    h = d['he']
    for i in index:
        h = h[i]
    SELECTED[key] = {'requestedRef': ref, 'canonicalRef': d.get('ref'), 'zeroBasedIndex': list(index), 'he': h,
                     'heVersionTitle': d.get('heVersionTitle'),
                     'retrieval': 'Public Sefaria text API; checked against the original Hebrew/Aramaic and the supplied source pages.'}
    return clean(h)

def local(book, ref):
    p = next(p for p in json.loads((BOOKS / (book + '.json')).read_text())['paras'] if p['r'] == ref)
    h = p.get('t') or ' '.join(x[0] for x in p['p'])
    SELECTED[ref] = {'canonicalRef': ref, 'he': h, 'canonicalFile': str(BOOKS / (book + '.json')),
                     'retrieval': 'Restored canonical Akiva reader data; the quotation preserves this reader wording.'}
    return clean(h)

def excerpt(s, start, end=None):
    i = s.index(start)
    return s[i:] if end is None else s[i:s.index(end, i) + len(end)]

pages = {
    111: (list(range(311, 316)), list(range(338, 342))),
    112: (list(range(315, 318)), [341, 342]),
    113: (list(range(317, 321)), list(range(342, 345))),
    114: (list(range(320, 325)), list(range(344, 348))),
    115: (list(range(324, 329)), list(range(347, 351))),
}
entries = []

def add(section, ident, phrase, ref, he, en, context, reader=False, anchor_end=None, url=None):
    rows = json.loads((ROOT / f'live-baseline/{section-1}.json').read_text())
    row = next(r for r in rows if r.get('n') == 1 and r.get('p'))
    text = plain(row['p'][phrase][0])
    prefix = text if anchor_end is None else text[:text.index(anchor_end) + len(anchor_end)]
    assert prefix and text.startswith(prefix)
    if url is None:
        url = ('https://akivagutnicki-crypto.github.io/akiva-publishing-kisvei-rav-tzadok/library/#/read/' + ref.rsplit(':', 1)[0].replace(' ', '_')) if reader else ('https://www.sefaria.org/' + ref.replace(' ', '_'))
    evidence = {'ref': ref, 'url': url, 'he': he, 'en': en,
                'translation': 'Original English translation prepared from the cited Hebrew or Aramaic.',
                'coverage': 'excerpt', 'heSha256': hashlib.sha256(he.encode()).hexdigest()}
    e = {'section': section, 'id': ident, 'rowN': 1, 'phraseIndex': phrase,
         'heAnchorPrefix': prefix, 'heCharOffset': len(prefix),
         'ref': ref, 'url': url, 'he': he, 'en': en, 'context': context,
         'sourceEvidence': [evidence],
         'reviewEvidence': {'pdfPages': {'neimosA': pages[section][0], 'integratedA': pages[section][1]},
                            'preserveExisting': True, 'status': 'verified',
                            'dedup': 'Every native and connected quotation in the destination ois was read. This selected source passage is absent.',
                            'primaryTextFile': 'review-work/ois111-selected-primary.json'}}
    if reader:
        e['readerRef'] = ref
        whole = clean(SELECTED[ref]['he'])
        assert he in whole, (ref, 'canonical reader quotation must be contiguous', he)
    else:
        e['openExternal'] = True
    entries.append(e)

# 111. Repentance, the final souls, Lot's allegory, and return to the source.
peri_vayelech = local('peri-tzadik', 'Peri Tzadik, Vayeilech and Shabbat Shuvah 4:1')
add(111, 'peri-vayelech-from-there-through-repentance', 1,
    'Peri Tzadik, Vayeilech and Shabbat Shuvah 4:1',
    excerpt(peri_vayelech, 'אמנם כדי שיתוקן העון לגמרי', 'המרירות שלו בגודל תשובתו.'),
    'But for the sin to be completely repaired, so that it is reckoned as merits, the section Nitzavim says, “You shall return to the Lord your God and heed His voice,” and “Even if your outcasts are at the end of the heavens, from there He will gather you, and from there”—specifically—“He will take you.” Even from the greatest distance, from the end of the heavens, specifically from there He will gather and take you. This follows what the Gemara says about “through them he shall live”: the sins become merits, and he receives reward for them. Here too, the gathering and taking will occur specifically through the sins that become merits through his repentance. This is when the repentance reaches “to the Lord your God”: through the bitterness of his great repentance, he comes especially close to the blessed God.',
    'Rav Tzadok explicitly interprets “from there He will take you” through the transformation brought about by repentance. This supplies his fuller explanation of the precise words used here; the distance itself is repaired through returning to God.', reader=True)

gilgul15 = primary("Sha'ar HaGilgulim 15:2")
add(111, 'shaar-hagilgulim-souls-at-the-feet', 6, "Sha'ar HaGilgulim 15:2",
    excerpt(gilgul15, 'ומיום שנחרב בית המקדש,', 'להוציא כל הנשמות משם ברגע אחד.'),
    'Since the Temple was destroyed, this has been His work, until He completes the gathering of all the souls that fell among the shells of the man of wickedness and became mixed within him, from his head to his feet. Until He finishes gathering even those that fell as far as the feet, the Messiah is not revealed and Israel is not redeemed. This is explained in our discussion of the Zohar, Pekudei: “When feet reach feet, then it is written, ‘His feet shall stand on that day upon the Mount of Olives.’” Yet the Divine Presence gathers them only through the deeds and prayers of those below, in the mystery of “Give strength to God.” According to the quality of the deeds below is the quality of the extraction of those souls and sparks. If all Israel returned in complete repentance, His Divine Presence would have the power to bring all the souls out of there in a single moment.',
    'The Ari’s teaching, recorded by Rabbi Chaim Vital, identifies the final gathering with the souls at the feet. The passage expressly connects that gathering to human deeds, prayer, and complete repentance, which is the work Rav Tzadok specifies here.')

add(111, 'midrash-haneelam-lot-and-two-faculties', 10, 'Zohar, Vayera 21:314-316',
    primary('Zohar, Vayera 21:314-316'),
    'Midrash HaNe’elam: “Lot went up from Tzoar.” Rabbi Abbahu said: Come and see what is written about the evil inclination. Know that it is never abolished from human beings until the time of which it is written, “I will remove the heart of stone.” Although it sees people judged in Gehinnom, it returns to human beings. This is “Lot went up from Tzoar”: from the suffering of Gehinnom it rises to entice people. Rabbi Yehudah said: There are three governing faculties in a person: the governance of intellect and wisdom, which is the power of the holy soul; the governance of desire, which desires every kind of evil desire; and the governance that directs human beings and sustains the body, called the bodily soul. Rav Dimi said: This is the sustaining power. Rabbi Yehudah said: Come and see: the evil inclination rules only over the latter two powers. The desiring soul continually pursues the evil inclination, as implied by “The elder said to the younger: Our father is old.” The desiring soul stirs the other and entices it, together with the body, to cleave to the evil inclination. It says, “Come, let us give our father wine to drink and lie with him”: what do we have in the world to come? Let us pursue the evil inclination and the longing for this world’s pleasures. What do they do? Both agree to cleave to it. Thus it is written, “They gave their father wine to drink”: they fatten themselves with eating and drinking to stir the evil inclination.',
    'This is the actual Midrash HaNe’elam allegory cited here: Lot represents the inclination, and his two daughters represent desire and the bodily faculty. The passage’s opening also specifies the eventual removal of the heart of stone. The emergence of David’s line from Lot is supplied by the separate lineage sources.',
    anchor_end='שֶׁהֵם שׁוֹרֶשׁ כֹּחַ הַיֵּצֶר הָרָע,')

add(111, 'bava-kamma-ruth-and-naamah', 10, 'Bava Kamma 38b:2',
    primary('Bava Kamma 38b:2'),
    'The Holy One, blessed be He, said to him: “What arose in your mind did not arise in My mind. I have two good young birds to bring forth from them: Ruth the Moabite and Naamah the Ammonite.”',
    'God’s answer to Moses explains why Moab and Ammon were spared: Ruth and Naamah would emerge from them. This supplies the rabbinic source for the two lines of ancestry through which Rav Tzadok connects Lot’s descendants with the house of David.')

shimshon21 = local('likkutei-maamarim', 'Likkutei Maamarim, On Shimshon 21')
add(111, 'likkutei-david-hidden-in-sodom', 9, 'Likkutei Maamarim, On Shimshon 21',
    excerpt(shimshon21, 'ושם היתה טמונה נפש דוד המלך עליו השלום,', 'שאין יכול ליפרד כלל.'),
    'There the soul of King David, peace be upon him, was hidden, as stated in Bereishit Rabbah: “I found David My servant”—where did I find him? In Sodom. For “one opposite the other”: in one power’s rule over another, the strength of the surrounding shell corresponds to the strength of the holiness. Therefore, “Whoever is greater than his fellow has a greater inclination.” The holy spark of King David’s soul—he who is the principal victorious warrior, of whom “My heart is hollow within me” is interpreted to mean that he killed the evil inclination, and who will also slaughter it in the future—was submerged in the depths of evil, where the inclination was at its greatest strength. No person would have imagined that any holy spark or any holiness could be present there, amid the utmost defilement of bodily desire. It is therefore described as a “finding,” like a discovery that comes unexpectedly. Before Sodom was overturned through the side of might and the fire of Isaac that had begun to be revealed in the world, it was impossible for this to be revealed: that even in a place of such intense desire, holiness is present. Only after that strength of evil was overturned and weakened did a little holiness begin to appear in the intention of Lot’s daughters for the sake of Heaven. Even this was not yet without defilement; nevertheless, some intention to preserve the human species was revealed in her words, “There is no man in the land to come to us,” an intention for the sake of Heaven. This was the beginning of the revelation of King David’s holy light, which illuminates this truth: “Even darkness does not darken for You,” and “Even when I walk in the valley of the shadow of death, I fear no evil, for You are with me.” His sovereignty rules over all, holiness is present everywhere, and the soul of an Israelite is attached to that holy spark—“You who cleave to the Lord your God”—and cannot become separated from it.',
    'Rav Tzadok’s own extended parallel explains the hidden root of David’s soul in Sodom and its emergence through Lot’s daughters. He retains both sides of the episode: an intention directed toward Heaven had begun to appear, while the act was still not free of defilement.', reader=True,
    url='https://akivagutnicki-crypto.github.io/akiva-publishing-kisvei-rav-tzadok/library/#/read/Likkutei_Maamarim,_On_Shimshon')

res26 = local('resisei-layla', 'Resisei Layla 26:1')
add(111, 'resisei-return-makes-end-beginning', 16, 'Resisei Layla 26:1',
    excerpt(res26, 'פירוש, כידוע בסוד "רצוא ושוב כמראה הבזק"', 'עמק ראשית דהשתלשלות הנבראים.'),
    'The meaning is as known in the mystery of “running and returning like the appearance of lightning,” seen by those who behold the Chariot: where they go, there they return. At the place where the light ends, it returns, and the end becomes a beginning, turning back again, so that the last of all the levels attaches to the beginning and the deepest origin and is called the head of all the levels. For the beginning of everything is the blessed God, and complete cleaving to Him is the deepest origin of the unfolding of created beings.',
    'This is Rav Tzadok’s explicit explanation of the image of running and returning. It supplies the link here between the light reaching its endpoint and that endpoint becoming a new head or beginning.', reader=True)

# 112. Parental desire and the meaning of the covenantal sign.
vay14 = primary('Vayikra Rabbah 14:5')
add(112, 'vayikra-rabbah-david-conception', 1, 'Vayikra Rabbah 14:5',
    excerpt(vay14, 'רבי אחא אמר', 'ובחטא יחמתני אמי.'),
    'Rabbi Acha said: Even if he were the most pious of the pious, it is impossible that he should not have some aspect of sin. David said before the Holy One, blessed be He: “Master of the worlds, did my father Jesse intend to bring me into being? Did he not intend his own pleasure? Know that this is so: after they have fulfilled their needs, this one turns his face one way and that one turns her face the other way, while You gather every drop that is there.” This is what David said, “For my father and mother abandoned me, but the Lord gathered me in,” and “In sin my mother conceived me.”',
    'The Midrash reads David’s verse through the parents’ bodily intention and God’s care in forming the child, even when the parent is pious. Rav Tzadok develops the passage into his account of transmitted desire and the shared work of repair; the existing Beit Yaakov note retains the distinction between an inherited condition and a deliberate present action.')

add(112, 'ramban-circumcision-reminder-of-restraint', 7, 'Ramban on Genesis 17:9',
    excerpt(primary('Ramban on Genesis 17:9', 0), 'ואמרו (הרד"ק) בטעם המילה,', 'לבל ישתמשו בו רק במצוה ובמתר.'),
    'They explained the reason for circumcision: it places a reminder upon the organ of desire, which is the source of much turmoil and sin, so that it will be used only for a commandment and for what is permitted.',
    'Ramban records the covenantal sign as a reminder directing desire toward its permitted purpose. This supplies an original explanation for Rav Tzadok’s description of circumcision here as a repair of the covenant and of desire.',
    anchor_end='שֶׁהוּא תִּיקּוּן הַבְּרִית וְהַתַּאֲוָה,')

# 113. The narrative, the Ari's account, refinement, and the words of the blessing.
add(113, 'proverbs-torah-tree-of-life', 3, 'Proverbs 3:18',
    primary('Proverbs 3:18'),
    'She is a tree of life to those who hold fast to her, and those who support her are fortunate.',
    'The verse describes wisdom as a tree of life. Rav Tzadok applies that scriptural description to Torah and then connects Torah’s root with the souls he is discussing.')

add(113, 'ari-adams-souls-refined-in-egypt', 4, "Sha'ar HaPesukim, Parashat Shemot 6",
    primary("Sha'ar HaPesukim, Parashat Shemot 6"),
    'It follows that all those demons and spirits created during the 130 years when Adam separated from Eve, as is known, were all exalted holy souls from the aspect of daat. They became mixed among the shells and required many reincarnations to refine and purify them until their impurity was removed. Therefore you find that the nation of Israel did not come into being until Jacob and afterward: most of the souls were mixed among the shells and were progressively refined, reincarnating from generation to generation. Their repair did not begin until Jacob, the chosen of the patriarchs, who repaired Adam. Then the repair of his children—the aforementioned souls—also began, and they continued to be refined in the Egyptian exile until Israel left Egypt.',
    'This is the Ari’s teaching in Sha’ar HaPesukim, recorded by Rabbi Chaim Vital. It gives the precise connection named here between the spirits associated with Adam’s separation and the souls undergoing refinement in Egypt.')

add(113, 'sotah-joseph-and-ten-unrealized-tribes', 5, 'Sotah 36b:16',
    primary('Sotah 36b:16'),
    'It was taught: Joseph was fit to have twelve tribes issue from him, just as they issued from his father Jacob, as it is said, “These are the generations of Jacob: Joseph.” But his seed issued from between his fingernails. Nevertheless, they issued from his brother Benjamin, and all were named in reference to him, as it is said, “The sons of Benjamin: Bela, Becher, and Ashbel,” and so forth.',
    'The Gemara supplies the account of Joseph’s lost potential for twelve tribes and its continuation through Benjamin. The identification with the ten martyrs belongs to the separate teaching in Tikkunei Zohar, rather than to this Talmudic passage itself.',
    anchor_end='שֶׁיָּצְאוּ מִיּוֹסֵף')

add(113, 'tikkunei-zohar-joseph-ten-martyrs', 5, 'Tikkunei Zohar 110a:5',
    primary('Tikkunei Zohar 110a:5'),
    'With this yod Joseph sinned, as it is written, “His bow remained firm, and the arms of his hands were made supple.” What does “were made supple” mean? A drop, which is yod, was cast among the ten fingers and divided into ten sparks cast from the bow, which is the covenant. Where were they cast? Into the ten martyrs of the kingdom. He said to him: “But I heard that the ten martyrs were Jacob’s sons.” He replied: “Heaven forbid! Rather, they were in their likeness.”',
    'Tikkunei Zohar, in Tikkun 69, gives the specific identification of Joseph’s ten sparks with the ten martyrs. The quotation also retains its own distinction between this account and the statement that they were Jacob’s sons.')

tanya28 = primary('Tanya, Part IV; Iggeret HaKodesh 28:5')
add(113, 'tanya-wisdom-refines-darkness', 6, 'Tanya, Part IV; Iggeret HaKodesh 28:5',
    excerpt(tanya28, 'שהיא בחינת ״חכמה עילאה״', 'מעולם התהו ושבירת הכלים, שנפלו בבריאה־יצירה־עשיה וכו׳, כנודע.'),
    'This is the aspect of “higher wisdom” and the “concealed mind” of Arich Anpin. Concerning it, the holy Zohar says in many places, “Through wisdom they are refined,” and “darkness is transformed into light.” This means the world of repair, which was refined and repaired through the concealed mind of Arich Anpin from the world of chaos and the breaking of the vessels that fell into Beriah, Yetzirah, and Asiyah, and so forth, as is known.',
    'In explaining the purifying power of the red heifer, Iggeret HaKodesh identifies the formula “through wisdom they are refined” with the transformation of darkness into light. This supplies the background of the formula Rav Tzadok applies here to recovering souls from evil.',
    anchor_end='דִּבְחָכְמָה אִתְבְּרִירוּ')

sa379 = primary('Shulchan Arukh, Yoreh Deah 379:1')
add(113, 'rema-mourner-blessing-takes-souls', 8, "Shulchan Arukh, Yoreh De'ah 379:1",
    excerpt(sa379, 'לוקח נפשות במשפט', 'לחיים ולשלום (טור):'),
    'He takes souls in judgment, rules His world, and acts within it as He wills, for all His ways are just. We are His people and servants, and in everything we are obliged to thank Him and bless Him. He who repairs the breaches of Israel—may He repair this breach for us and for this mourner, for life and peace.',
    'This wording appears in the Rema’s gloss to the fourth blessing of Grace after Meals in a mourner’s home. It is the liturgical phrase Rav Tzadok interprets here when he connects God’s taking a soul in judgment with the repair of other souls.')

add(113, 'bava-metzia-rabbi-title-and-return', 12, 'Bava Metzia 85a:9-10',
    primary('Bava Metzia 85a:9-10'),
    'Rabbi came to the place of Rabbi Elazar son of Rabbi Shimon and asked: “Does that righteous man have a son?” They answered: “He has a son, and every prostitute who is hired for two hires him for eight.” He brought him, ordained him with the title Rabbi, and entrusted him to Rabbi Shimon son of Isi son of Lakonya, his mother’s brother. Every day he would say: “I am going back to my town.” His teacher said to him: “They have made you a sage, spread a golden cloak over you, and call you Rabbi, and you say, ‘I am going back to my town’?” He answered: “I swear, I have abandoned that.” When he grew in stature, he came and sat in Rabbi’s academy. Rabbi heard his voice and said: “This voice resembles the voice of Rabbi Elazar son of Rabbi Shimon.” They told him: “He is his son.”',
    'The existing note gives the Gemara’s interpretation of the verse “the fruit of the righteous.” This is the preceding narrative that explains how the title Rabbi and his uncle’s teaching helped bring the son back to Torah.')

seder25 = primary('Seder Olam Rabbah 25', 0)
add(113, 'seder-olam-cub-proverb', 16, 'Seder Olam Rabbah 25',
    excerpt(seder25, 'ועליו אמר נבוכדנצר', 'מכלבא בישא גורא טבא לא נפיק,'),
    'Concerning him, Nebuchadnezzar said: “From a bad dog a good pup does not come forth.”',
    'Seder Olam records the proverb in Nebuchadnezzar’s account of Jehoiachin. Its animal is a dog; Rav Tzadok uses the corresponding lion-and-cub wording here in his argument that the son’s eventual greatness reveals a good root. The author’s wording is preserved.')

add(113, 'bava-metzia-cave-and-equal-greatness', 17, 'Bava Metzia 85a:12-13',
    primary('Bava Metzia 85a:12-13'),
    'When he died, they brought him to his father’s cave. A snake was coiled around the cave. They said to it: “Snake, snake, open your mouth, and let a son enter beside his father.” It did not open for them. The people thought that this meant one was greater than the other. A heavenly voice came forth and said: “It is not because one is greater than the other, but because this one experienced the suffering of the cave and this one did not experience the suffering of the cave.”',
    'The heavenly voice explicitly rejects a difference in greatness and gives the father’s suffering in the cave as the reason for the distinction in burial. Rav Tzadok relies on that rejection of unequal greatness in his reading of the son’s eventual stature.')

# 114. Torah's recovery of souls, its conditions, and the full rescue narrative.
or7 = primary('Or HaChaim on Leviticus 7:37:2')
add(114, 'or-hachaim-torah-recovers-sparks-and-souls', 1, 'Or HaChaim on Leviticus 7:37:2',
    excerpt(or7, 'אשר אמרו כי תכלית עסק התורה'),
    'They said that the purpose of engaging in Torah is to refine the sparks of holiness that fell or were forcibly taken from holiness, and to restore them in complete unity to their former state. These are of two kinds. The first consists of the sparks of holiness that descended in the world of chaos, for a reason known to Him; what is understood by those who possess knowledge suffices as a sound explanation. The second consists of the oppressed souls that the man of wickedness seized from Adam through his sin, when he took great spoil, as is known concerning the vast number of souls he seized. Nothing commands him to disgorge what he swallowed except engagement in Torah. Through it one accomplishes the essential work: raising the holy sparks that fell before the world of repair, making Samael disgorge what he swallowed, and shattering and dissolving his power until he vomits out the wealth he swallowed. This is what the Sages said: “If [the evil inclination] encounters you”—if it is stone, it dissolves, and if it is iron, it shatters.',
    'Or HaChaim explicitly distinguishes the fallen sparks of the world of chaos from the souls seized through Adam’s sin, and identifies Torah study as the means of recovering both. This supplies the fuller original account behind Rav Tzadok’s description of each Torah utterance bringing out the souls associated with its speaker.')

eikhah2 = primary('Eikhah Rabbah, Petichta 2')
add(114, 'eikhah-torah-light-restores', 4, 'Eikhah Rabbah, Petichta 2',
    excerpt(eikhah2, 'רבי הונא ורבי ירמיה בשם רבי חיא בר אבא אמרי,', 'רב הונא אמר למד תורה אף על פי שלא לשמה שמתוך שלא לשמה בא לשמה.'),
    'Rabbi Huna and Rabbi Yirmeyah said in the name of Rabbi Chiyya bar Abba: It is written, “They abandoned Me and did not keep My Torah.” If only they had abandoned Me but kept My Torah! Through occupying themselves with it, the light within it would have brought them back to the good. Rav Huna said: Study Torah even when it is not for its own sake, for from studying it not for its own sake one comes to study it for its own sake.',
    'This is the Midrash Rav Tzadok cites for Torah’s power to restore its own student. His following sentences distinguish the states in which that restorative power becomes immediately effective from those in which a person is still held captive by evil.')

derekh6 = primary('Derekh Hashem, Part Four, On Torah Study 6')
add(114, 'derekh-hashem-gradual-restoration-and-conditions', 5, 'Derekh Hashem, Part Four, On Torah Study 6',
    excerpt(derekh6, 'והתנאי הב׳ הוא תיקון המעשה'),
    'The second condition is the correction of one’s conduct, for someone who wishes to draw down an influence ought to be worthy and prepared to draw it down. But if he defiles himself with guilt and transgressions, distances himself from his Creator, and strays after the forces of impurity and evil, it certainly applies to him: “To the wicked God said: What right have you to recount My statutes?” The Sages likewise said: “Whoever teaches an unworthy student is as though he throws a stone to Markulis.” Such a person’s Torah certainly draws down none of the influence we have described. Nevertheless, the Sages revealed a great secret: if the wicked did not abandon Torah study, they would eventually return to the good. Although they lack the power to draw down any influence from Him, as explained, the words of Torah are themselves intrinsically holy. Through persistent engagement with them, a little awakening, like the faintest glimmer of light, reaches the student again and again, until it eventually overcomes him and brings him back to the good. This is what the Sages said: “If only they had abandoned Me but kept My Torah, for its light brings them back to the good.” It is, however, clear that this does not refer to someone who studies in a manner of mockery and derision, or to expound the Torah contrary to its proper meaning, but to someone who engages with it at least as one engages with other disciplines.',
    'Ramchal distinguishes the immediate divine influence that requires worthy conduct from Torah’s intrinsic holiness, which can gradually awaken repentance even in a sinner. He expressly limits this latter claim to serious study, excluding mockery and deliberate distortion. This clarifies the distinction between Torah’s restorative power and the impediments Rav Tzadok describes here.')

add(114, 'tanya-torah-returns-with-the-penitent', 10, 'Tanya, Part I; Likkutei Amarim 39:19-20',
    primary('Tanya, Part I; Likkutei Amarim 39:19-20'),
    'When one studies truly not for its own sake, with some ulterior motive for one’s own honor—for example, to become a Torah scholar and the like—that motive, which comes from kelipat nogah, clothes itself in one’s Torah. The Torah is then temporarily in exile within the shell, until one repents, bringing healing to the world. When one returns to the Lord, one’s Torah returns together with oneself. Therefore our Sages said, “A person should always occupy himself [with Torah and commandments], for from doing so not for its own sake he comes to do so for its own sake”—certainly so, for he will certainly eventually repent, whether in this incarnation or another, since “no banished one shall remain banished from Him.”',
    'Tanya describes the Torah studied with an explicit motive of personal honor as temporarily sharing its student’s exile, then returning together with the penitent. The qualification “until one repents” supplies the sequence Rav Tzadok states here: the person is repaired, and the Torah and the souls associated with it rise with him.')

tanna22 = '''מעשה בתלמיד אחד מתלמידי ר׳ עקיבא שהיה יושב בראש עשרים וארבעה אלפים תלמידים. פעם אחת יצא לשוק של זונות וראה שם אשה זונה ואהב אותה, והיה משלח שליח בינו לבינה עד עת הערב. לעת הערב עלתה על הגג וראתה אותו התלמיד כשהוא יושב בראש התלמידים כמו שר הצבא והיה גבריאל עומד על ימינו. מיד אמרה בלבה: אוי לה לאותה אשה שכל מיני הפורעניות של גיהנום צואת לה (יתחברו אליה). וכי אדם גדול כמו זה שהוא דומה למלאך תעננו אשה זאת? וכשמתה ובטלה מן העולם הזה יורשת גיהנום. אבל אם לא תקבלנה אותו הרי היא מצלת אותו ואת עצמה מדינה של גיהנום. וכיון שבא אצלה, אמרה לו: בני, מפני מה אתה מאבד חיי העולם הבא בשביל הנאת שעה אחת בעולם הזה? ולא נתקררה דעתו, עד שאמרה לו: בני, מקום שאתה אוהב מלוכלך ומטונף מכל האיברים ואין כל בריה יכולה להריח ריחו. ולא נתקררה דעתו עד שתפשה אותו בחוטמו והניחה אותו על אותו מקום. כיון שהריח ריחו נמאס בפניו ולא נשא אשה מעולם. יצתה בת קול ואמרה: אשה פלונית ואיש פלוני מזומנים לחיי העולם הבא.'''
SELECTED['Tanna DeBei Eliyahu Zuta 22'] = {
    'canonicalRef': 'Tanna DeBei Eliyahu Zuta 22', 'he': tanna22,
    'url': 'https://he.wikisource.org/wiki/אליהו_זוטא_כב',
    'sourceRevision': '940896', 'retrievalFile': 'review-work/ois111-tanna-zuta22-web.json',
    'retrieval': 'Exact original Wikisource chapter opened through web retrieval; source lines 149–157 checked in full. Sefaria has no text for chapter 22, so the actual verified original URL is used.'}
add(114, 'tanna-debei-eliyahu-student-and-woman-rescue', 14, 'Tanna DeBei Eliyahu Zuta 22',
    clean(tanna22),
    'There was a student of Rabbi Akiva who sat at the head of twenty-four thousand students. Once he went to the prostitutes’ market, saw a prostitute, and loved her. He kept sending a messenger between himself and her until evening. At evening she went up to the roof and saw that student sitting at the head of the students like an army commander, with Gabriel standing at his right. She immediately said to herself: “Woe to that woman, against whom all the punishments of Gehinnom will gather! Will this woman afflict a great man like this, who resembles an angel? When she dies and departs from this world, she will inherit Gehinnom. But if she does not receive him, she saves both him and herself from the judgment of Gehinnom.” When he came to her, she said: “My son, why are you losing the life of the world to come for an hour’s pleasure in this world?” His desire did not cool. She said: “My son, the place you desire is more filthy and unclean than all the other parts of the body, and no creature can bear its smell.” His desire still did not cool until she took hold of his nose and placed it at that place. When he smelled it, it became repulsive to him, and he never married. A heavenly voice went forth and said: “That woman and that man are destined for life in the world to come.”',
    'This is the complete rescue episode cited here. The woman’s recognition of the student’s spiritual stature turns her toward saving them both; her subsequent intervention then saves him from the intended sin. The narrative includes Gabriel’s presence, her repeated efforts, and the final heavenly declaration, preserving the sequence on which Rav Tzadok’s interpretation rests.',
    anchor_end='(סוֹף פֶּרֶק כב)', url='https://he.wikisource.org/wiki/אליהו_זוטא_כב')

# 115. Truthful innovation, self-interest, and the union of mind and heart.
add(115, 'eruvin-living-words-and-hillel-humility', 2, 'Eruvin 13b:10-11',
    primary('Eruvin 13b:10-11'),
    'Rabbi Abba said in the name of Shmuel: For three years the house of Shammai and the house of Hillel disputed. These said, “The law follows us,” and those said, “The law follows us.” A heavenly voice went forth and said: “These and those are the words of the living God, and the law follows the house of Hillel.” Since these and those are the words of the living God, why did the house of Hillel merit that the law be established according to them? Because they were gentle and forbearing, and studied both their own words and those of the house of Shammai. Moreover, they placed the words of the house of Shammai before their own.',
    'The Gemara recognizes both schools’ words as Torah while still deciding the practical law. Its explanation emphasizes Hillel’s humility and willingness to study the other view first—the qualities opposed to the self-interest and desire to defeat others that Rav Tzadok excludes here.')

derekh5 = primary('Derekh Hashem, Part Four, On Torah Study 5')
add(115, 'derekh-hashem-reverence-and-divine-influence', 5, 'Derekh Hashem, Part Four, On Torah Study 5',
    excerpt(derekh5, 'אך התנאים הצריכים להתלוות לתלמוד הנה הם:'),
    'The conditions that must accompany study are reverence during the study itself and the correction of conduct at all times. For all the power of Torah lies in His having attached His precious influence to it, so that speaking its words and understanding them draw down that great influence. Without this, speaking of it would be like speaking of other matters or books of learning, and understanding it would be like understanding other subjects of the natural world. These provide only knowledge of the particular subject; they impart no intrinsic excellence or elevation to the soul of the reader, speaker, or thinker, and no repair to creation as a whole. This influence, however, is divine, and is the highest and most exalted of the influences that reach created beings from Him. A person should therefore fear and tremble when engaged in such a matter: he approaches his God and occupies himself with drawing that great light from Him. He must be humbled by his human lowliness and tremble before His exaltedness. He should rejoice greatly in the good portion he has merited, but with trembling. This includes not sitting frivolously or treating either its words or its books disrespectfully, and knowing before Whom one stands and works. When one does this, one’s study truly becomes what it should be: the influence described is drawn down through it, divine excellence becomes rooted within oneself, and repair and illumination extend to all creation. But if this condition is absent, the illumination is not drawn down through one’s study. One’s words are merely like other human speech, one’s reading like reading a letter, and one’s thoughts like thoughts about worldly affairs. Indeed, one incurs guilt for approaching the holy without reverence and behaving frivolously before one’s Creator while speaking before Him and engaging with His holiness. The excellence of the study and the degree of influence it draws down correspond to the degree of reverence, honor, and care invested in it.',
    'Ramchal distinguishes the divine effect of Torah study from the acquisition of information alone, and connects that effect with reverence and worthy conduct. This supplies an original parallel for Rav Tzadok’s distinction between words that function as Torah and words governed by the speaker’s own agenda.')

add(115, 'rashi-jeroboam-ingathering-argument', 7, 'Rashi on I Kings 12:33:1',
    primary('Rashi on I Kings 12:33:1'),
    '“In the eighth month”: He expounded to them that this was the month of ingathering and that it was fitting for the festival to be held in it.',
    'Rashi supplies the specific interpretive argument behind Jeroboam’s choice of month. The existing verse note gives the statement that he devised it from his heart; this original explanation shows how his decision was presented as a Torah interpretation.')

add(115, 'rashi-doeg-head-of-court', 9, 'Rashi on I Samuel 21:8:2',
    primary('Rashi on I Samuel 21:8:2'),
    '“Chief of the herdsmen”: Head of the court.',
    'Rashi identifies Doeg’s position as judicial leadership. This is the original explanation for Rav Tzadok’s reference to him as head of the Sanhedrin; the position itself does not validate the decisions that Rav Tzadok goes on to criticize.')

ber32 = primary('Bereshit Rabbah 32:1')
add(115, 'bereshit-rabbah-doeg-legal-pretext', 11, 'Bereshit Rabbah 32:1',
    excerpt(ber32, 'נחמן בריה דרבי שמואל בר נחמני,', "ויסב דואג האדמי ויפגע בכהני ה'."),
    'Nachman son of Rabbi Shmuel bar Nachmani [said]: He [Doeg] said to Saul, “Does David still have a marriage? Is he not a rebel against the monarchy and regarded as dead? Now release his wife and make him a condemned man, as though he were dead, so that his blood is permitted and his wife is permitted.” Saul then gave Michal, David’s wife, to Palti son of Laish on Doeg’s word. As for bloodshed: it is written, “The king’s servants would not stretch out their hands against the priests of the Lord.” But Doeg killed them, as it is said, “Doeg the Edomite turned and struck the priests of the Lord.”',
    'The Midrash presents Doeg’s legal reasoning as a pretext for forbidden relations and bloodshed. It directly supplies Rav Tzadok’s account of treating David as a rebel and attacking the priests who assisted him; the reasoning is reported as Doeg’s wrongdoing, not endorsed as a valid ruling.')

ber12 = primary('Berakhot 12b', 12)
add(115, 'berakhot-saul-chosen-and-forgiven', 12, 'Berakhot 12b:13',
    ber12,
    'The Sages said: The proof is from here: “We shall hang them before the Lord in Gibeah of Saul, the chosen of the Lord.” A heavenly voice went forth and said, “The chosen of the Lord.”',
    'In the surrounding discussion the Gemara seeks evidence that Saul had been forgiven from Heaven. It identifies “the chosen of the Lord” as a heavenly declaration. This supplies the rabbinic basis for Rav Tzadok’s description of Saul while preserving the distinction between forgiveness and approval of every action.')

add(115, 'zohar-other-god-bears-no-fruit', 16, 'Zohar, Mishpatim 3:166',
    primary('Zohar, Mishpatim 3:166'),
    'Come and see: It is written, “A river goes out from Eden to water the garden.” This river never ceases to increase, multiply, and bear fruit. But the other god is castrated: it never has desire, does not multiply, and does not bear fruit. If it bore fruit, it would devastate the entire world.',
    'This is the Zohar’s contrast between the ever-fruitful river of holiness and the barren “other god” (Zohar II, 103a). Rav Tzadok applies its image here to teachings driven by self-interest, which lack the power to bring souls out of captivity.')

dover2 = local('dover-tzedek', 'Dover Tzedek, Mishlei Commentary 2:2')
add(115, 'dover-wisdom-understanding-and-heart', 18, 'Dover Tzedek, Mishlei Commentary 2:2',
    excerpt(dover2, 'חכמה היא במחשבה שבמח,', 'כשהחכמה שבמח נובעת מן הלב'),
    'Wisdom is in the thought of the mind, and understanding is the will and feeling of the heart, as is known from “Patach Eliyahu.” This is what lies within a person’s power, as it is written, “What does the Lord your God ask of you, except to fear”—which is in the heart, as stated in Yoma 72b. Likewise, in chapter Chelek, Sanhedrin 106b: “The Merciful One desires the heart”; and in Chronicles: “The Lord searches all hearts,” as I have explained at length elsewhere. Therefore, “understanding” denotes what a person originates, “wisdom” what one receives from others, and “knowledge” their union—that is, when the wisdom of the mind wells up from the heart.',
    'Rav Tzadok’s own explanation supplies the meanings of the terms in this sentence: wisdom in the mind, understanding as the heart’s will and feeling, and knowledge as their union. The connection is therefore a matter of the person’s inward will as well as intellectual understanding.', reader=True)

res32 = local('resisei-layla', 'Resisei Layla 32:1')
add(115, 'resisei-knowledge-unites-mind-and-heart', 19, 'Resisei Layla 32:1',
    excerpt(res32, 'כי דעת נקרא חבור מוחא ולבא,', 'וזה נקרא שאין לו דעת.'),
    'Knowledge is the joining of mind and heart: one desires only what one understands intellectually to be good and proper to do, and thinks only of what one wills. This is a person whose heart is under his control. With the wicked, by contrast, “they are under their hearts’ control.” That is, even though one knows that something is not good, one’s heart desires it and one cannot turn away from that desire. This is called lacking knowledge.',
    'This parallel gives the practical meaning of the union Rav Tzadok describes: the heart’s desire and the mind’s judgment are brought into agreement under the person’s control. Merely knowing that something is wrong, while remaining governed by the desire for it, is the opposite condition.', reader=True)

assert len(entries) == 31
assert {s: sum(e['section'] == s for e in entries) for s in range(111, 116)} == {111: 6, 112: 2, 113: 9, 114: 5, 115: 9}
catalog = json.loads((ROOT / 'tmp/batch-engineering/current-site/library/connected-ideas/catalog.json').read_text())
decisions = {
    111: ['Read both supplied editions in full and every native and connected note. Added the missing original parallels for repentance, the final souls at the feet, Lot’s faculties, the two Davidic lines, David hidden in Sodom, and the endpoint becoming a beginning.', 'Preserved the existing Sanhedrin, Moed Katan, Bereishit Rabbah, Sukkah, Ezekiel, Pesachim, and Sichat Shedim quotations without duplication or replacement.'],
    112: ['Added Vayikra Rabbah’s account of David’s conception and Ramban’s explanation of the covenantal sign as a reminder directing desire.', 'Preserved the existing corrected Zohar passage, Resisei Layla 21, and Beit Yaakov’s distinction between inherited condition and deliberate action.'],
    113: ['Added the actual Bava Metzia narratives before and after the already quoted verse interpretation, retaining the heavenly voice’s explicit denial of unequal greatness.', 'Verified the Ari’s Adam/Egypt source, Tikkunei Zohar’s distinction about the martyrs, the wisdom/refinement formula, the mourning blessing, and the original proverb. Native verse interpretation remains unchanged.'],
    114: ['Added the original accounts of recovering souls, Torah’s light, Ramchal’s conditions, and Torah returning with the penitent.', 'The complete Tanna DeBei Eliyahu Zuta 22 narrative was verified on its actual original Wikisource page. It is not present in Sefaria’s available chapters; no invented Sefaria link is used.', 'Preserved the existing Yoma, Berakhot, Eruvin, and Acher notes. The latter already distinguishes Rabbi Meir’s initiating judgment from Rabbi Yochanan’s ending punishment.'],
    115: ['Added the missing original Rashi and Midrash explanations of Jeroboam and Doeg, the heavenly declaration about Saul, the Zohar’s fruitfulness contrast, and precise parallels for mind and heart.', 'The Eruvin quotation retains the practical ruling for Hillel and its explanation through humility. Ramchal’s quotation retains both required reverence and worthy conduct.', 'Preserved the existing Yevamot, Chagigah, Sanhedrin, Vayikra Rabbah, and Sod Yesharim quotations without duplication.'],
}
coverage = []
for section in range(111, 116):
    file = ROOT / f'live-baseline/{section-1}.json'
    rows = json.loads(file.read_text())
    notes = [n for row in rows for n in row.get('footnotes', [])]
    connected = [r['targetRef'] for r in catalog['records'] if r.get('originRef', '').startswith(f'Tzidkat HaTzadik {section}:')]
    coverage.append({'section': section, 'status': 'complete-add-only-review', 'bothSuppliedEditionsRead': True,
                     'pdfPages': {'neimosA': pages[section][0], 'integratedA': pages[section][1]},
                     'existingNativeNumbersPreserved': [n['number'] for n in notes],
                     'existingConnectedSourcesPreserved': connected,
                     'baselineSha256': hashlib.sha256(file.read_bytes()).hexdigest(),
                     'additions': sum(e['section'] == section for e in entries), 'decisions': decisions[section]})
result = {
    'schemaVersion': 1, 'reviewedSections': list(range(111, 116)),
    'reviewMode': 'Add only missing original-source quotations; preserve every existing note and all body text.',
    'entries': entries, 'coverage': coverage,
    'observationsNotApplied': [
        {'section': 111, 'type': 'primary-locator-resolved', 'detail': 'The running-and-returning parallel is Resisei Layla 26:1, confirmed in the canonical original text; the OCR of a supplied source pointer resembled 29.'},
        {'section': 113, 'type': 'body-preserved', 'detail': 'The author’s lion-and-cub wording is preserved. Seder Olam 25 uses the dog-and-pup form; the new note explicitly identifies that difference.'},
        {'section': 114, 'type': 'verified-external-primary-url', 'detail': 'Tanna DeBei Eliyahu Zuta 22 is linked to https://he.wikisource.org/wiki/אליהו_זוטא_כב, verified against revision 940896. Sefaria’s chapter 22 response contains no text.'},
        {'section': 115, 'type': 'source-editorial-citation', 'detail': 'The Hebrew edition of Bereshit Rabbah 32:1 contains a mistaken parenthetical biblical locator before Doeg’s slaughter of the priests. The primary Hebrew is retained; the translated narrative does not repeat that mistaken locator. The actual verse is I Samuel 22:18.'},
    ],
    'sourceVerification': 'All external quotations were checked in original Hebrew/Aramaic. Internal quotations preserve contiguous canonical reader wording and expanded abbreviations. Public footnotes credit only the original sources and never link either supplied commentary PDF.',
    'reproducibleBuilder': 'review-work/build-111-115.py',
}
(WORK / 'ois-111-115.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(WORK / 'ois111-selected-primary.json').write_text(json.dumps(SELECTED, ensure_ascii=False, indent=2) + '\n')
verification = {'sections': list(range(111, 116)), 'entries': len(entries), 'checks': []}
for e in entries:
    rows = json.loads((ROOT / f"live-baseline/{e['section']-1}.json").read_text())
    row = next(r for r in rows if r['n'] == e['rowN'])
    anchor = plain(row['p'][e['phraseIndex']][0])
    assert anchor.startswith(e['heAnchorPrefix']) and e['heCharOffset'] == len(e['heAnchorPrefix'])
    hits = [k for k, v in SELECTED.items() if e['he'] in clean(v['he'])]
    assert hits, (e['id'], 'unmatched contiguous Hebrew evidence')
    assert e['sourceEvidence'][0]['heSha256'] == hashlib.sha256(e['he'].encode()).hexdigest()
    public = ' '.join(e[k] for k in ['ref', 'url', 'en', 'he', 'context'])
    assert not re.search('biur|mishulav|meshulav|neimos|neimot|נעימות הצדק|ביאור משולב', public, re.I)
    assert '.pdf' not in e['url'].lower()
    verification['checks'].append({'section': e['section'], 'id': e['id'], 'exactAnchor': True,
                                  'contiguousOriginalHebrewMatched': True, 'primarySnapshotKeys': hits,
                                  'canonicalReader': bool(e.get('readerRef')), 'heSha256': e['sourceEvidence'][0]['heSha256']})
(WORK / 'ois-111-115-verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'entries': len(entries), 'counts': {s: sum(e['section'] == s for e in entries) for s in range(111, 116)},
                  'proposal': str(WORK / 'ois-111-115.json'), 'primaryEvidence': str(WORK / 'ois111-selected-primary.json')}, ensure_ascii=False))

