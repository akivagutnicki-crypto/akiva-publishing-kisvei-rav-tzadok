"""Prepare explicit, deterministic GitHub checkpoint blobs for reviewed work."""
import argparse, base64, gzip, hashlib, json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('files', nargs='+')
parser.add_argument('--output', required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parent
payload = []
for name in args.files:
    source = (root / name).resolve()
    if not source.is_relative_to(root):
        raise ValueError('Checkpoint input must be inside review-work')
    raw = source.read_bytes()
    if source.suffix == '.json':
        json.loads(raw)
    data = gzip.compress(raw, compresslevel=9, mtime=0)
    payload.append({
        'path': 'editorial/batch-review-work/' + source.relative_to(root).as_posix() + '.gz',
        'encoding': 'base64',
        'content': base64.b64encode(data).decode(),
        'sha256': hashlib.sha256(data).hexdigest(),
    })
Path(args.output).write_text(json.dumps(payload))
print(json.dumps({'files': len(payload), 'compressedBytes': sum(len(base64.b64decode(p['content'])) for p in payload)}))
