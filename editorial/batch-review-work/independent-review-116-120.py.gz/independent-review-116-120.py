import hashlib
import html
import json
import re
from collections import Counter
from pathlib import Path
from urllib.parse import unquote

ROOT = Path('/workspace/scratch/f85ae98f1669')
WORK = ROOT / 'review-work'
SITE = ROOT / 'tmp/batch-engineering/current-site'


def flatten(value):
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return ' '.join(flatten(v) for v in value)
    return ''


def plain(value):
    return html.unescape(re.sub(r'<[^>]*>', '', value))


def norm(value):
    return re.sub(r'[^\u05d0-\u05ea]', '', plain(value))


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


def ordered_parts(quotation, whole):
    cursor = 0
    normalized_whole = norm(whole)
    for part in re.split(r'\s*…\s*', quotation):
        needle = norm(part)
        if not needle:
            continue
        found = normalized_whole.find(needle, cursor)
        if found < 0:
            return False
        cursor = found + len(needle)
    return True


def primary_he(value):
    if not isinstance(value, dict): return ''
    if 'result' in value: return primary_he(value['result'])
    if 'data' in value: return primary_he(value['data'])
    if 'he' in value: return flatten(value['he'])
    return ' '.join(flatten(v.get('text','')) for v in value.get('versions', []) if v.get('languageFamilyName') == 'hebrew')

web_sources = {
    'shaar-maamarei-razal-giving-the-hand': {'url': 'https://he.wikisource.org/wiki/שער_מאמרי_רז"ל/ש"ס', 'retrievalRef': 'turn130view0', 'line': 129},
    'zohar-eliezer-under-the-shade-of-faith': {'url': 'https://he.wikisource.org/wiki/זהר_חלק_ג_קג_א', 'retrievalRef': 'turn131view0', 'lines': [142,144]},
}

proposals = {
    group: json.loads((WORK / f'ois-{group}.json').read_text())
    for group in ('116-120',)
}
caches = {
    name: json.loads((WORK / name).read_text())
    for name in ('primary-116-120.json', 'extra-primary-116-120.json', 'more-primary-116-120.json', 'primary-101-105.json', 'primary-86-90.json')
}
selected = {}
connected = json.loads((SITE / 'library/connected-ideas/catalog.json').read_text())['records']
books = {}
checks = []
issues = []
for proposal in proposals.values():
    for entry in proposal['entries']:
        rows = json.loads((ROOT / f"live-baseline/{entry['section']-1}.json").read_text())
        row = next(r for r in rows if r['n'] == entry['rowN'])
        text = plain(row['p'][entry['phraseIndex']][0])
        assert text.startswith(entry['heAnchorPrefix']), entry['id']
        assert len(entry['heAnchorPrefix']) == entry['heCharOffset'], entry['id']
        evidence = entry['sourceEvidence'][0]
        assert evidence['he'] == entry['he'] and evidence['en'] == entry['en'], entry['id']
        assert evidence['heSha256'] == digest(entry['he']), entry['id']
        source = None
        if entry.get('readerRef'):
            relative = evidence.get('canonicalSourceFile')
            file = SITE / relative if relative else Path(selected[entry['readerRef']]['canonicalFile'])
            if file not in books:
                books[file] = json.loads(file.read_text())['paras']
            paragraph = next(p for p in books[file] if p['r'] == entry['readerRef'])
            original = paragraph.get('t') or ' '.join(pair[0] for pair in paragraph['p'])
            assert norm(entry['he']) in norm(original), (entry['id'], 'internal exact contiguous quote')
            source = {'kind': 'canonical-reader', 'file': str(file.relative_to(SITE)), 'ref': paragraph['r']}
        else:
            for name, cache in caches.items():
                for ref, value in cache.items():
                    if isinstance(value, dict) and ordered_parts(entry['he'], primary_he(value)):
                        source = {'kind': 'cached-primary-Hebrew', 'file': name, 'ref': ref}
                        break
                if source:
                    break
        if entry['id'] == 'yevamot-resolution-of-manassehs-charges':
            combined = primary_he(caches['primary-116-120.json']['Yevamot 49b']) + ' ' + primary_he(caches['extra-primary-116-120.json']['Yevamot 50a'])
            assert ordered_parts(entry['he'], combined), 'Yevamot two-folio contiguous primary unit'
            source = {'kind': 'cached-primary-Hebrew', 'files': ['primary-116-120.json', 'extra-primary-116-120.json'], 'refs': ['Yevamot 49b', 'Yevamot 50a']}
        if entry['id'] in web_sources:
            assert unquote(entry['url']).split('#')[0] == web_sources[entry['id']]['url']
            source = {'kind': 'independently-opened-primary-text', **web_sources[entry['id']]}
        if not source:
            issues.append({'id': entry['id'], 'issue': 'No independent primary match'})
        duplicates = []
        for record in connected:
            if record.get('originRef', '').split(':')[0] == f"Tzidkat HaTzadik {entry['section']}":
                if norm(entry['he']) in norm(record.get('targetHebrew', '')):
                    duplicates.append({'kind': 'connected', 'number': record['footnoteNumber']})
        for r in rows:
            for note in r.get('footnotes', []):
                for old_evidence in note.get('sourceExcerptReview', {}).get('evidence', []):
                    old_he = old_evidence.get('he', '')
                    if norm(entry['he']) in norm(old_he):
                        duplicates.append({'kind': 'native-evidence-candidate', 'number': note['number']})
        if entry['id'] == 'devarim-rabbah-torah-heals-the-tongue':
            assert duplicates == [{'kind': 'native-evidence-candidate', 'number': 616}], duplicates
            old_note = next(n for r in rows for n in r.get('footnotes', []) if n['number'] == 616)
            old_visible = '\n'.join(p['text'] for p in old_note['paragraphs'])
            assert digest(old_visible) == '170eece6e56ccba1f73c71bab253088003b18429e391ca47ad9001b452d9d04a', 'Existing note 616 changed; reread required'
            assert 'Rabbi Levi said' in old_visible and 'רבילוי' not in norm(entry['he'])
            # Note 616 displays only Rabbi Levi's concluding Moses example. Its hidden
            # evidence stores the full chapter. The new preceding tree/leaf unit was
            # independently read and has no displayed overlap with that conclusion.
            duplicates = []
        if duplicates:
            issues.append({'id': entry['id'], 'issue': 'Possible existing quotation', 'matches': duplicates})
        visible = ' '.join(entry[k] for k in ('ref', 'url', 'he', 'en', 'context'))
        assert not re.search(r'Biur|Meshulav|Mishulav|Neimos|Ne.imot|\.pdf(?:$|[?#])', visible, re.I), entry['id']
        checks.append({
            'section': entry['section'], 'id': entry['id'], 'ref': entry['ref'],
            'source': source, 'exactAnchor': True, 'bilingualEvidenceHash': True,
            'existingNativeOrConnectedDuplicate': False if not duplicates else duplicates,
            'translationAndContextIndependentlyRead': True,
        })

report = {
    'status': 'passed' if not issues else 'needs-review',
    'reviewedAt': '2026-10-23',
    'reviewedSections': list(range(116, 121)),
    'entries': len(checks),
    'counts': dict(Counter(c['section'] for c in checks)),
    'internalCanonicalQuotations': sum(bool(c['source'] and c['source']['kind'] == 'canonical-reader') for c in checks),
    'proposalSha256': {group: hashlib.sha256((WORK / f'ois-{group}.json').read_bytes()).hexdigest() for group in proposals},
    'independentEditorialFindings': [
        'Read all 42 Hebrew/Aramaic quotations, original English translations, explanatory contexts, source references, and exact anchors, together with every existing native quotation and the four connected quotations.',
        'Ois 116 retains the differing legal opinions about stumbling, the practical limit on Rabbi Meir’s view, both opinions in Arakhin about remedy or prevention, Isaiah’s intention requiring atonement, and all three Yevamot resolutions including the dispute over years.',
        'Ois 117 retains the distinction between scholarly indignation and personal deficiency, Yeravam’s subsequent sin and Achiyah’s correction, the full Reish Lakish narrative and final grief, both opinions about the shared water, and Rashi’s precise explanation of Rabbi Chanina’s fear of succession.',
        'Ois 118 preserves the ownership exception in Pesachim, Rabbi Yehudah’s differing report in Sukkah, the source’s received-tradition wording, Eliezer’s escape from the curse through service, and the Torah-oriented conditions underlying faith and healed speech.',
        'Ois 119 preserves the original Baal Shem Tov attribution, the Ari’s complete initials explanation, Shaarei Orah’s knowledge and reverence conditions, and Nedarim’s final limitation to analytical understanding.',
        'Ois 120 retains the danger of contamination despite good initial intention and the need for vigilance, Shlomo’s mistaken reasoning and failure to protest, alternative accounts of Elisha’s holiness, and both dangers of distancing or drawing desire too close.',
        'Existing misnumbering in ois 116 and the Rav Huna/Rabbi Chanina discrepancy in ois 117 remain untouched; the current primary-source footnote already explains the latter.',
    ],
    'checks': checks,
    'issues': issues,
}
(WORK / 'independent-review-116-120.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key in ('status', 'entries', 'counts', 'internalCanonicalQuotations', 'proposalSha256', 'issues')}, ensure_ascii=False))
assert not issues, issues
