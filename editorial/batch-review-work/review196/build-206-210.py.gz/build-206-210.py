from common import *

D=json.loads((HERE/'primary.json').read_text())
def ext(ref,*indices):
    t=D[ref]['he']
    for i in indices:t=t[i-1]
    return bare(t)
def span(ref,a,b):return bare(D[ref]['he'][a-1:b])
def ex(s,id,pi,ref,he,en,ctx,**kw):
    b.add(s,id,pi,ref,he,en,ctx,sourceFile='review-work/review196/primary.json',**kw)
def end(s,pi,needle):
    row=next(r for r in json.loads((BASE/f'{s-1}.json').read_text()) if r.get('n')==1)
    t=plain(row['p'][pi][0]);return cut_bare(t,bare(t)[:12],needle)
def inside(s,id,pi,book,ref,he,en,ctx,**kw):
    b.add(s,id,pi,ref,he,en,ctx,book=book,**kw)

pages={
206:{'integratedB':list(range(133,138)),'neimosB':list(range(120,126))},
207:{'integratedB':list(range(137,142)),'neimosB':list(range(125,130))},
208:{'integratedB':list(range(141,148)),'neimosB':list(range(130,136))},
209:{'integratedB':list(range(147,153)),'neimosB':list(range(136,141))},
210:{'integratedB':list(range(152,157)),'neimosB':list(range(141,147))}}
b=Batch(206,pages)

ex(206,'avot-envy-desire-and-honor',0,'Pirkei Avot 4:21',ext('Pirkei Avot 4:21'),
   'Rabbi Elazar HaKappar says: Envy, desire, and honor remove a person from the world.',
   'This is the Mishnah’s triad that Rav Tzadok identifies as the roots of the harmful traits and thoughts discussed here.')

ex(206,'shaarei-kedusha-pride-as-a-root',1,"Sha'arei Kedusha, Part 2 4:3",
   cut(ext('Shaarei Kedusha, Part 2 4',3),'הגאוה היא שורש','ורם לבבך ושכחת את ה\' אלהיך'),
   'Pride is the root of many transgressions, whether between a person and God or between one person and another. It causes a person to harm his fellow, hate him, speak slander about him, and do many similar things. As for relations with God, Scripture says: “Your heart will become haughty, and you will forget the Lord your God.”',
   'Rabbi Ḥayyim Vital explains the two directions in which pride generates wrongdoing: injury to other people and forgetfulness of God.',
   anchorEnd='וְשׁוֹרֶשׁ הַשָּׁרָשִׁים הוּא הַגַּאֲוָה')

ex(206,'radak-yetzer-as-the-hearts-forming-thought',2,'Radak on I Chronicles 28:9:2',ext('Radak on I Chronicles 28:9',2),
   '“And understands every formation of thoughts”: The activity of the heart is called yetzer, because the heart acts and forms matters in thought, whether for good or for evil.',
   'Radak supplies the lexical explanation of yetzer as the heart’s forming activity. His wording includes both good and evil thoughts.',
   anchorEnd='דְּפֵירוּשׁ "יֵצֶר" – מַחֲשָׁבָה וְהִרְהוּר בַּלֵּב')

ex(206,'avot-de-rabbi-natan-eight-thoughts',3,'Avot DeRabbi Natan 20:1',
   cut(ext('Avot DeRabbi Natan 20:1'),'רבי חנניה סגן הכהנים אומר','ועבדת את אויביך אשר ישלחנו יי׳ בך ברעב ובצמא ובעירום ובחוסר כל.'),
   'Rabbi Ḥananya, deputy High Priest, says: Whoever places words of Torah upon his heart has removed from him thoughts of the sword, famine, folly, sexual immorality, the evil inclination, another man’s wife, idle matters, and the yoke of flesh and blood. So it is written in Psalms through David, king of Israel: “The precepts of the Lord are upright, gladdening the heart; the commandment of the Lord is clear, enlightening the eyes.” Whoever does not place words of Torah upon his heart is given thoughts of the sword, famine, folly, sexual immorality, the evil inclination, another man’s wife, idle matters, and the yoke of flesh and blood. So it is written in Deuteronomy through Moses our teacher: “They shall be upon you as a sign and a wonder, and upon your descendants forever, because you did not serve the Lord your God with joy and a glad heart amid an abundance of everything; you shall serve your enemies whom the Lord sends against you, in hunger, thirst, nakedness, and lack of everything.”',
   'The complete paired statement identifies all eight kinds of thought and connects their removal with placing Torah upon the heart. Rav Tzadok subsequently explains how two closely related kinds can be counted together.',
   anchorEnd='וְלָכֵן נִזְכַּר בְּאָבוֹת דְּרַבִּי נָתָן ח\' מִינֵי הִרְהוּרִים כַּנִּזְכָּר לְעֵיל אוֹת ר"ד')

ex(206,'etz-chaim-eight-powers-and-seven-kings',4,'Sefer Etz Chaim 8:4:1',
   cut(ext('Sefer Etz Chaim 8:4',1),'ולכן נבאר תחלה סדר ז\' מלכים אלו','ובין שניהם הם אחד לבד'),
   'We shall therefore first explain the order of these seven kings. They are from Daat downward: Daat is one; Ḥesed, two; Gevurah, three; Tiferet, four; Netzaḥ and Hod are two halves of one body and are five; Yesod, six; and Malkhut, seven. For Netzaḥ and Hod are each regarded as half a body, and together they are only one.',
   'Etz Ḥayyim explicitly begins with Daat and explains why the eight named powers are counted as seven kings: Netzaḥ and Hod are counted together.')

ex(206,'rashi-wisdom-understanding-and-holy-spirit',5,'Rashi on Exodus 31:3',ext('Rashi on Exodus 31:3'),
   '“Wisdom”: What a person hears from others and learns. “Understanding”: He understands something from his own heart out of the things he has learned. “Knowledge”: The holy spirit.',
   'Rashi distinguishes the three terms in the description of Bezalel. The last gloss is the precise source for Rav Tzadok’s identification of daat with ruaḥ ha-kodesh.',
   anchorEnd='כִּי רַשִּׁ"י פָּרָשַׁת תִּשָּׂא פֵּירֵשׁ: דַּעַת הַיְינוּ רוּחַ הַקֹּדֶשׁ')

ref='Takanat HaShavin 6:16'
inside(206,'takanat-holy-spirit-and-the-heart',5,'takanat-hashavin',ref,
   cut_bare(local('takanat-hashavin',ref),'וכנודע ברמב״ן','דבלב הוא כח ההרגשה'),
   'As is known from Ramban on Bava Batra 12a, the holy spirit is an apprehension of wisdom that enters a person’s heart beyond what his intellect can attain. Higher wisdom lies beyond the human intellect’s apprehension in this world. This apprehension does not come to a person through the wisdom in his brain at all, but through the understanding in the heart—that is, through feeling, for the power of feeling is in the heart.',
   'This parallel explains Rav Tzadok’s distinction between ordinary intellectual attainment and the heart’s reception of an apprehension beyond it.')

ex(206,'etz-chaim-rear-aspects-and-lower-vessels',7,'Sefer Etz Chaim 9:2:1',
   cut(ext('Etz Chaim 9:2',1),'ואמנם הענין הוא כי ודאי','אבל לא יקרא מיתה.'),
   'The matter is that aspects certainly fell from all ten points, and all experienced some annulment. Yet Zeir Anpin and the feminine aspect fell entirely, both in their back-to-back and their face-to-face states. This is called death, because everything descended completely. But Abba and Imma, of which only the rear aspects descended, are described as undergoing annulment, not death. From Keter, only its Netzaḥ, Hod, and Yesod fell, which had entered as the intellectual powers of Abba and Imma, as explained above. Since this aspect is not even classed as rear aspects, Keter is not described as undergoing annulment, but only a blemish. There is another reason: only one who passes from one world to another and is separated from his world is called dead. Therefore the seven kings, which were in Atzilut and descended to Beriah, are called truly dead. As the Idra says: Do not say that they died; rather, whoever descends from the former level at which he stood is described as dead, as in “The king of Egypt died.” But although the rear aspects of Abba and Imma fell, they did not descend into Beriah; they remained in the world of Atzilut itself. Because they were displaced from their proper place, this is called annulment, but not death.',
   'The original passage distinguishes the limited fall of the rear aspects of Abba and Imma from the complete descent of the lower vessels. That distinction is essential to Rav Tzadok’s qualification that the truth of mature wisdom itself is beyond the rule of imagination.')

ex(206,'etz-chaim-new-mah-and-repair',9,'Sefer Etz Chaim 10:1:2',
   cut(ext('Etz Chaim 10:1',2),'והנה כאשר עלה ברצון המאציל','והוציא שם מ"ה החדש ונתקנו המלכים'),
   'When it arose in the Emanator’s will to revive the dead and repair these kings that had broken and fallen into the world of Beriah, He decreed and raised the feminine waters from below upward. Through this there was a supernal union of the inner Ḥokhmah and Binah of Adam Kadmon; it brought forth the new Name MaH, and the kings were repaired.',
   'This is Etz Ḥayyim’s explicit account of repair through the new Name MaH. Rav Tzadok applies that account to humility and the restoration of the person’s capacity to receive.',
   anchorEnd='וְכִידוּעַ דְּעוֹלַם הַתִּיקּוּן נִבְנֶה עַל יְדֵי שֵׁם מַ"ה הֶחָדָשׁ')

ex(206,'maharal-humility-and-unbounded-reception',13,'Netivot Olam, Netiv Hatorah 2:4',ext('Netivot Olam, Netiv Hatorah 2',4),
   'This is what was said: “Just as water leaves a high place and goes to a low place.” The explanation is that water continually spreads in every direction and has no fixed boundary or limit. It is unlike a solid body that extends only according to its size; water continues spreading without a boundary. Water therefore leaves a high place and goes to a low place: the high place has a boundary, being limited by its surface, and water leaves that bounded place for the low place, where it will not be confined. Likewise, Torah is intellectual and has no limit. It therefore leaves the high place—the proud person who bounds himself by saying how great he is—and goes to the low place: the lowly of spirit, those who are humble, who do not delimit themselves or consider themselves anything, as though they were not a bounded thing. Torah is therefore found with them. See our explanation of “Not everyone who engages extensively in commerce becomes wise.” We have already explained in the Path of Humility that humility has the quality of simplicity, for a person does not regard himself as something; this is the essence of humility. One who considers himself something and is important in his own eyes does not possess that simplicity. Therefore Torah, which is a simple intellect, is fit to dwell only in one who is simple and does not consider himself something. This is the definition of the simplicity that is fit for intellect.',
   'Maharal explains how humility enlarges receptivity: the proud person imposes a fixed measure upon himself, whereas humility leaves room for Torah beyond that measure. “Simple” here means free of the self-imposed boundedness described in the passage.')

ex(206,'proverbs-humility-before-honor',14,'Proverbs 15:33',ext('Proverbs 15:33'),
   'Fear of the Lord is the discipline of wisdom, and before honor comes humility.',
   'This supplies the second half of Rav Tzadok’s paired citation. The existing note quotes Proverbs 16:18, about pride before ruin; this verse supplies humility before honor.')

ref='Peri Tzadik, Rosh Chodesh Sivan 4:1'
inside(206,'peri-tzadik-initial-vision-and-earned-attainment',16,'peri-tzadik',ref,
   cut_bare(local('peri-tzadik',ref),'ובז\' דפסח בקי"ס','כדי שיעמול אחר כך להשיגו בקנין.'),
   'On the seventh day of Passover, at the splitting of the sea, a maidservant saw what Ezekiel did not see, as stated in the Mekhilta and elsewhere. Our holy master of Ishbitz said that this was the kind of vision shown to a person at his beginning. This accords with what is said in the Baal Shem Tov’s name: that he envied the strength of the awakening of youth when entering the gates of piety. As the Rokeaḥ writes, there is no strength like piety at its beginning. Our teacher Rabbi Bunim said that this is the meaning of “Do not say that the former days were better than these,” when the awakening was very strong: “For it is not from wisdom that you have asked this”—it was not from your own wisdom, but was lent to you by the blessed God. The principal thing is what a person afterward acquires through his own effort. Our holy master of Ishbitz said that everything a person has the capacity afterward to attain as his own acquisition is shown to him by the blessed God at the beginning as a vision. It is only a loan; afterward it departs so that he will labor to attain it as his own acquisition.',
   'This fuller parallel explains the initial illumination, its departure, and the task of acquiring it through effort. It supplies the background for Rav Tzadok’s comparison with the vision at the sea without treating the initial experience as a permanent achievement.')

ref='Ohr Zarua LaTzadik, The Egyptian Exile 1:3'
inside(207,'ohr-zarua-anochi-as-a-gift',3,'ohr-zarua-latzadik',ref,
   cut_bare(local('ohr-zarua-latzadik',ref),'ודבור "אנכי" הראשון','רק עצם שרשם הוא כך.'),
   'The first utterance, “I am,” does not begin in the form of a command, “Know that I am,” or “Believe,” and the like. A command is altogether inapplicable here. Rather, for one who belongs from the outset to Israel’s holy root, this becomes established and confirmed in his heart of itself: “I am,” and so forth. For one who does not believe this, all commands and warnings will be of no help; this is a root bearing poison, and his essential being is not of Israel’s holiness at all, whose principal source and root of life is the utterance “I am,” and so forth. Therefore this is not a command that depends on an awakening from below. It is a gift from above without any awakening from below, as explained earlier; this is simply the nature of their root.',
   'Rav Tzadok’s parallel explains why the first utterance is expressed as a declaration. Within his account of Israel’s spiritual root, the capacity for recognizing the divine Commander precedes the response to a command.')

ex(207,'maharal-command-presupposes-kingship',3,'Tiferet Yisrael 37:3',ext('Tiferet Yisrael 37',3),
   'Moreover, the utterance “I am the Lord your God,” which is their acceptance of His divinity and kingship, cannot take the form of a command or decree. If He is not their King and God, a decree upon them is inapplicable, for one issues a decree over them only after already being king. But if He is already King over them, there is no need to say, “Accept My kingship,” since He is already King. A king therefore cannot say, “I decree upon the people that you accept me as king”: if he is not their king, a decree that he issues is inapplicable; and if he is already king, there is no need to decree that they accept his kingship. Rather, he says, “You know that I am your king; therefore act accordingly, accepting my kingship.” Thus the first utterance takes this form: “I am the Lord your God, who brought you out of the land of Egypt”; since I brought you out of Egypt, accept My kingship.',
   'Maharal explains the same logical difficulty: a command presupposes the authority of the one commanding. His explanation retains the positive demand to accept divine kingship, rather than removing the first utterance from the Decalogue.')

ex(207,'chagigah-exemptions-and-the-defined-deaf-category',8,'Chagigah 2b:3-7',span('Chagigah 2b',3,7),
   '“Except a deaf person, a person without legal mental competence, and a minor,” and so forth. It teaches “deaf person” alongside the person without legal mental competence and the minor: just as those two lack legal understanding, so the deaf person meant here lacks legal understanding. It teaches what we learned: The deaf person of whom the Sages speak everywhere is one who neither hears nor speaks. Thus one who speaks but does not hear, or hears but does not speak, is obligated. We learned support for this, as the Sages taught: One who speaks but does not hear is deaf; one who hears but does not speak is mute; both are regarded as legally competent in all respects. From where is it known that one who speaks but does not hear is deaf and one who hears but does not speak is mute? For it is written, “I am like a deaf person who does not hear, and like a mute person who does not open his mouth.” Alternatively, as people say, his speech has been removed. But it was taught that one who speaks but does not hear, or hears but does not speak, is exempt! Ravina—or, some say, Rava—said: The text is incomplete and should read: Everyone is obligated in appearance at the Temple and festival rejoicing, except one who speaks but does not hear or hears but does not speak, who is exempt from appearance. Although exempt from appearance, he is obligated in rejoicing. One who neither hears nor speaks, a person without legal mental competence, and a minor are exempt even from rejoicing, since they are exempt from all the commandments stated in the Torah.',
   'The Gemara defines the classical legal category used in this exemption and expressly distinguishes people who can either hear or speak. It also distinguishes the particular obligation of appearance at the Temple from festival rejoicing; those qualifications are retained.')

ex(207,'avot-torah-and-work',14,'Pirkei Avot 2:2',
   cut(ext('Pirkei Avot 2:2'),'רבן גמליאל בנו','סופה בטלה וגוררת עון.'),
   'Rabban Gamliel, son of Rabbi Yehudah HaNasi, says: Torah study is good together with worldly occupation, for the exertion of both makes sin forgotten. Any Torah study unaccompanied by work will ultimately cease and lead to sin.',
   'This is the Mishnah behind the phrase that exertion in derekh eretz makes sin forgotten. Its statement concerns the combination of Torah and work; Rav Tzadok applies the role of necessary work to Israel’s situation before receiving the Torah.')

ex(207,'bartenura-work-and-the-inclination',14,'Bartenura on Pirkei Avot 2:2:1-3',span('Bartenura on Pirkei Avot 2:2',1,3),
   '“Worldly occupation”: A craft or commerce. “For the exertion of both makes sin forgotten”: Torah weakens a person’s strength, and work strains and wears down the body; through this the evil inclination becomes inactive within him. “Any Torah study unaccompanied by work”: If you ask, let him labor continually in Torah and let its exertion make sin forgotten—why is work needed? It was therefore necessary to say that Torah unaccompanied by work will ultimately cease, for a person cannot do without sustenance; he will rob others and forget his learning.',
   'Bartenura explains both the effect of exertion and the practical need for a livelihood. His complete explanation prevents the first sentence from being read as a recommendation simply to increase exhaustion.')

ex(207,'ketubot-idleness-and-its-consequences',15,'Ketubot 59b:7',ext('Ketubot 59b',7),
   'Rabbi Eliezer says: Even if she brought him a hundred maidservants, he may require her to work in wool, because idleness leads to sexual immorality. Rabban Shimon ben Gamliel says: Even one who vows that his wife may do no work must divorce her and give her the marriage settlement, because idleness leads to mental disturbance.',
   'The Mishnah discusses work within marriage and gives these two formulations of the harmful effects of idleness. Rav Tzadok invokes that underlying concern in his account of distracting thoughts.')

ex(207,'zohar-seven-decrees-and-seven-blessings',17,'Zohar, Shemot 40:314',ext('Zohar, Shemot 40:314'),
   'It was taught: When the Holy One, blessed be He, handed Israel over to the prince of Egypt, He decreed seven decrees upon them by which the Egyptians would enslave them. This is what is written: “They embittered their lives with hard labor, with mortar and bricks,” and so forth. Corresponding to them were seven for good: “The children of Israel were fruitful,” “swarmed,” “multiplied,” “grew strong,” “very,” “very,” and “the land was filled with them.”',
   'The Zohar explicitly counts seven aspects of the Egyptian oppression and places seven expressions of blessing opposite them. Rav Tzadok connects the sevenfold labor with the sevenfold repair of thought.')

ex(207,'tosefta-hillels-seven-methods',18,'Tosefta Sanhedrin 7:5',
   cut(ext('Tosefta Sanhedrin 7',5),'שבע מדות דרש הלל לפני זקני בתירה'),
   'Hillel expounded seven methods before the elders of Beteira: inference from the lighter to the more stringent; verbal analogy; establishing a general principle from one passage; establishing a general principle from two passages; general, particular, and general; a corresponding case elsewhere; and a matter learned from its context. These are the seven methods that Hillel the Elder expounded before the elders of Beteira.',
   'This is the Tosefta’s parallel to the seven-method tradition cited at the beginning of Sifra. Its list distinguishes a general principle drawn from one passage from one drawn from two passages.',
   anchorEnd='וְעַל יְדֵי זֶה זָכוּ נֶגְדָּם לְשֶׁבַע מִדּוֹת שֶׁהַתּוֹרָה נִדְרֶשֶׁת לְדִבְרֵי הִלֵּל (רֵישׁ תּוֹרַת כֹּהֲנִים)')

ref='Takanat HaShavin 8:1'
inside(207,'takanat-three-principles-and-sevenfold-expression',18,'takanat-hashavin',ref,
   cut_bare(local('takanat-hashavin',ref),'וכל דבר היוצא לפעל','והשבע הוא כללות השטח כידוע]'),
   'Everything that comes into actuality has three initial powers that generate it potentially, from which proceed seven lower powers—the attributes that build its actual expression. Every bounded thing must be divided into three parts and boundaries: beginning, middle, and end; these are the first three. [From them actual expression is built through extension in space: three dimensions—length, breadth, and height or depth—within which are the six extremities of every thing, while the seventh is the whole extent, as is known.]',
   'This parallel explains Rav Tzadok’s general sevenfold scheme through three dimensions, six extremities, and their whole. It is his account of the structure of manifestation.')

ref='Resisei Layla 11:1'
inside(207,'resisei-layla-prayer-awakened-from-above',22,'resisei-layla',ref,
   cut_bare(local('resisei-layla',ref),'אבל באמת אמרו זכרונם לברכה','ולא יצטרך לצרה שתעוררנו חס ושלום.'),
   'In truth, the Sages said, “There are appointed times for prayer,” as it is written, “As for me, my prayer is to You at a time of favor.” A “time of favor” means a time when the blessed God wants people to pray before Him, in the sense of “If my prayer is fluent in my mouth.” Without the blessed God, a person cannot pray before Him at all. As was established at the beginning, “My Lord, open my lips”—then I can open my mouth in prayer. When the blessed God wishes people to pray before Him and opens the mouth in prayer, the prayer is certainly shegurah: sent from above, for the blessed God has sent it into his mouth. Then he is accepted; this is a time of favor. The essence of prayer is the feeling of distress and lack, as in “A prayer of the poor, which enfolds all prayers and breaks through the firmaments,” because he prays from the depth of the heart, feeling the lack. This itself comes from the blessed God. Thus, when Rabbi Ḥanina ben Dosa’s prayer was fluent, another person’s illness and suffering distressed him greatly, and his mouth opened to plead for him from the depth of the heart. Likewise, every distress that the blessed God sends upon a person in this world, God forbid, is to awaken him to prayer. As the Sages said concerning “Pharaoh drew near”: it is like the noblewoman whose voice the king wished to hear. They also said: “Why were the patriarchs infertile? Because the Holy One, blessed be He, desires the prayers of the righteous.” Of this they said, “A person should always anticipate,” as in “Will your cry avail?”—that he should awaken to prayer beforehand and not need distress to awaken him, God forbid.',
   'The existing Peri Tzadik note explains shegurah as “sent.” This fuller parallel adds compassion for another’s suffering and expressly urges prayer before distress is needed to awaken it.')

ex(207,'rashi-fluent-prayer-from-heart-to-mouth',23,'Rashi on Berakhot 34b:12',ext('Rashi on Berakhot 34b',12),
   '“If it is fluent”: If my prayer is ordered swiftly in my mouth, without my stumbling, and my supplication flows from my heart to my mouth for as long as I wish to continue pleading. “That he is rejected”: The sick person. Another interpretation: It is an expression of casting his prayer back in his face; that is, the prayer offered for him is cast away and driven from him, and is not accepted.',
   'Rashi explains the fluency described in the Mishnah as the unimpeded flow of supplication from the heart. Both interpretations of the contrasting term metoraf are retained.',
   anchorEnd='וְזֶה טַעַם (בְּרָכוֹת לד:): אִם שְׁגוּרָה תְּפִלָּתִי בְּפִי וְכוּלֵי')

ex(207,'vayikra-rabbah-derekh-eretz-before-torah',25,'Vayikra Rabbah 9:3',
   cut(ext('Vayikra Rabbah 9:3'),'דאמר רבי ישמעאל בר רב נחמן','ואחר כך עץ החיים, זו תורה.'),
   'For Rabbi Yishmael bar Rav Naḥman said: Derekh eretz preceded Torah by twenty-six generations. This is what is written: “To guard the way to the tree of life.” “The way” is derekh eretz; afterward, “the tree of life” is Torah.',
   'In its original setting, the teaching follows an account of a guest who avoids slander and makes peace between people; derekh eretz there includes proper conduct. Rav Tzadok applies the precedence of derekh eretz here to necessary worldly occupation.',
   anchorEnd='הֲגַם שֶׁדֶּרֶךְ אֶרֶץ קוֹדֵם לַתּוֹרָה בְּהֶכְרֵחַ')

ex(207,'arakhin-the-smallest-measure-of-distress',25,'Arakhin 16b:21-23',span('Arakhin 16b',21,23),
   'What is the smallest measure of suffering? Rabbi Elazar said: When a garment is woven for a person to wear and it does not please him. Rava Zeira—or, some say, Rabbi Shmuel bar Naḥmani—objected: They said something still less: even when people intended to mix a drink with hot water and mixed it with cold, or with cold and mixed it with hot; and you require so much? Mar son of Ravina said: Even if his garment turns inside out. Rava—or, some say, Rav Ḥisda; some say Rabbi Yitzḥak; and some say it was taught in a baraita—said: Even if he puts his hand into his purse to take out three coins and two come up in his hand. Specifically, when he wanted three and two came up; but if he wanted two and three came up, that does not count, since there is no trouble in throwing the extra one back.',
   'The Gemara is identifying how small an inconvenience can count as suffering. Its final distinction is retained: retrieving an additional missing coin entails trouble, while simply returning an extra one does not.')

ex(208,'rashi-prayer-as-standing-before-the-king',2,'Rashi on Berakhot 25a:1:1',ext('Rashi on Berakhot 25a',1,1),
   '“But for prayer”: He must present himself as standing before the King and stand in awe. But in the recitation of Shema he is not speaking before the King.',
   'Rashi explains the Gemara’s distinction between the dress required for Shema and for prayer. His explanation supplies the specific meaning of prayer as an address before the King.')

ref='Et HaOchel 14:1'
inside(208,'et-haochel-redemption-of-speech-for-prayer',6,'et-haochel',ref,
   cut_bare(local('et-haochel',ref),'ובזהר וארא','שיוכל לדבר דבורין דתפלה בכל לבו.'),
   'In the Zohar, Vaera, it says that in Egypt speech was in exile. This means that they were good in their hearts, but not so in bringing this into actual deeds. It is like what I heard concerning “a foolish speaker will stumble”: he cannot bring potential into actuality, as the Sages said in Sotah concerning “a people without understanding will stumble,” referring to the loss of the sotah waters’ power to produce their effect. Speech is the explicit disclosure of what is in the heart. For this reason they established the joining of redemption to prayer: a person may cry to God in his heart but be unable to express this with his mouth so purely, without any alien thought, and truly from the heart. This is the redemption from Egypt: their redemption was the redemption of that faculty. Through recalling it, the same is brought about within him, so that he can speak words of prayer with all his heart.',
   'This parallel explains the relation between redemption from Egypt and prayer through the restoration of speech’s ability to express the heart.')

ex(208,'berakhot-redemption-and-evening-prayer',7,'Berakhot 4b:6',ext('Berakhot 4b',6),
   'The master said: He recites Shema and prays. This supports Rabbi Yoḥanan, for Rabbi Yoḥanan said: Who belongs to the World to Come? One who joins redemption to the evening prayer. Rabbi Yehoshua ben Levi says: The prayers were instituted in the middle.',
   'Rabbi Yoḥanan’s formulation is the first statement in Rav Tzadok’s comparison. Rabbi Yehoshua ben Levi’s differing order places the prayers between the morning and evening recitations of Shema; that disagreement is retained. The existing notes supply the separate promise concerning Ashrei.',
   anchorEnd=end(208,7,'איזהו בן עולם הבא וכולי'))

ex(208,'berakhot-ashrei-alphabet-and-sustenance',9,'Berakhot 4b:17-20',span('Berakhot 4b',17,20),
   'What is the reason? If it is because the psalm follows the alphabet, let him say “Happy are those whose way is blameless,” which follows it eightfold. If it is because it contains “You open Your hand,” let him say the Great Hallel, in which it is written, “Who gives bread to all flesh.” Rather, it is because it contains both.',
   'This is the Gemara’s explanation of the distinctiveness of Psalm 145: its alphabetical structure together with its praise of God’s provision of sustenance. It supplements the existing quotation about the reward for reciting it.')

ex(208,'zohar-truth-and-faith',11,'Zohar, Pinchas 53:332',ext('Zohar, Pinchas 53:332'),
   'For this reason the masters of the Mishnah established: Study is not the principal thing, but action. For the Holy One, blessed be He, is concealed in the secrets of Torah. Through what is He known? Through the commandments, which are His Shekhinah, His likeness. Just as He is humble, His Shekhinah is humility. He is pious, and she is pious. He is mighty, and she rules over all the nations of the world. He is truth, and she is faith. He is a prophet, and she is a prophetess. He is righteous, and she is righteous. He is king, and she is kingship. He is wise, and she is wisdom. He understands, and she is His understanding. He is a crown, and she is His diadem, a diadem of splendor. For this reason the Sages established: Whoever is not inwardly as he is outwardly should not enter the house of study. This follows the likeness of the Holy One, blessed be He: He is its inner aspect and the Shekhinah its outer aspect; He is inward within, and she outward without. That which is outward does not differ from that which is inward, so that it may be known that she is His emanation and that there is no separation there at all: “Within and without you shall overlay it.”',
   'The original passage explicitly pairs truth with the Holy One and faith with the Shekhinah. Its conclusion that there is no separation is retained, along with the passage’s connection between inward reality and outward action.')

ex(208,'tosafot-faith-in-the-life-of-the-worlds',13,'Tosafot on Shabbat 31a:10:1',ext('Tosafot on Shabbat 31a',10,1),
   '“Faithfulness”—this is the Order of Seeds: The Jerusalem Talmud explains that he trusts in the Life of the Worlds and sows.',
   'Tosafot’s gloss is the source for the expression “trusts in the Life of the Worlds.” Its concrete example is the trust involved in sowing.')

ex(208,'yerushalmi-david-and-the-slain-inclination',18,'Jerusalem Talmud Berakhot 9:5:8',
   cut(ext('Jerusalem Talmud Berakhot 9:5',8),'אבל דוד לא היה יכול לעמוד בו'),
   'But David could not withstand it and killed it in his heart. What is the scriptural basis? “My heart is hollow within me.”',
   'The preceding sentence distinguishes Abraham, who transformed his evil inclination into good. David’s different path is described here through the verse about the hollow heart. This adds the Yerushalmi’s distinction to the existing Avodah Zarah quotation.')

ex(208,'eruvin-solomons-sea-and-one-hundred-fifty-mikvaot',21,'Eruvin 14a:23',
   cut(ext('Eruvin 14a',23),'תניא רבי חייא','מאה וחמשים מקוה טהרה.'),
   'Rabbi Ḥiyya taught: The sea that Solomon made could hold one hundred and fifty ritual baths for purification.',
   'This is the Gemara’s explicit capacity statement concerning Solomon’s sea. Rav Tzadok then connects that number with the psalms and the purification of thought.',
   anchorEnd=end(208,21,'דק"נ מקוה טהרה דים של שלמה'))

ref='Mei HaShiloach, Volume I, Prophets, I Samuel 20:1'
inside(208,'mei-hashiloach-the-number-of-purification',21,'mei-hashiloach',ref,
   cut_bare(local('mei-hashiloach',ref),'והנה אבן של יהודה'),
   'The stone of Judah set in the breastplate was called nofekh, whose numerical value is one hundred and fifty. King David, peace be upon him, composed one hundred and fifty sections in Psalms, for fifty signifies purification, and three times fifty signifies the completeness of true purification. King Solomon, peace be upon him, made the bronze sea, which held one hundred and fifty ritual baths for purification. He also composed Proverbs, Song of Songs, and Ecclesiastes, which comprise fifty chapters, apart from the final chapter of Proverbs, the section “A woman of valor.”',
   'This is the Ishbitz parallel to the teaching Rav Tzadok says he heard: the shared number of David’s psalms and the purification capacity of Solomon’s sea. It develops the association with Judah and three times fifty.',
   anchorEnd=end(208,21,'הם נגד ק"נ מזמורי תהלים'))

ex(208,'zohar-chadash-egypt-and-the-gates-of-purity',22,'Zohar Chadash, Yitro 3-6',span('Zohar Chadash, Yitro',3,6),
   'He said to him: Come and see, my son. The Holy One, blessed be He, covenanted with Abraham only to bring Israel out of the exile of Egypt, not from under the bondage of another object of worship. For when Israel were in Egypt, they certainly defiled and sullied themselves with every kind of impurity, until they were under forty-nine powers of impurity. The Holy One, blessed be He, brought them out from the service of all those other powers. Moreover, He brought them into forty-nine gates of understanding corresponding to them. He had covenanted with Abraham only to bring them out of Egypt, but He acted toward them with His goodness and kindness. Therefore you will find the exodus from Egypt fifty times in the Torah, to show everyone the kindness that the Holy One, blessed be He, did for Israel: He brought them out of those powers of impurity and into the powers of purity, which are the fifty gates of understanding. These are what we count from the festival day of Passover. We count days and weeks, as the companions have explained: It is a commandment to count days, and a commandment to count weeks. For each day He brought us out of a power of impurity and into a power of purity.',
   'The Zohar Chadash gives the forty-nine powers of impurity in Egypt, their corresponding gates of understanding, and the larger fiftyfold account of the exodus. It connects that movement with counting the Omer.',
   anchorEnd=end(208,22,'שהיו משוקעים במצרים במ"ט מהם כנודע'))

ref='Peri Tzadik, Vayigash 10:1'
inside(208,'peri-tzadik-psalms-as-cutting-away',23,'peri-tzadik',ref,
   cut_bare(local('peri-tzadik',ref),'וכמו כן נבחר דהמע"ה','ומתקנים כל הקלקולים.'),
   'Likewise King David, peace be upon him, was chosen; it is written of him, “He was ruddy, with beautiful eyes,” and he is called “the sweet singer of Israel.” For it says in Shir HaShirim Rabbah: Ten people uttered the Book of Psalms; the Holy One, blessed be He, said, “You are all pleasing,” but let David, whose voice is sweet, say it. Zemirot means cutting, from “You shall not prune,” as we say in the prayer before Psalms: to cut down the violent and cut away all the thorns and briars surrounding the supernal rose. He therefore established the yoke of repentance, which removes the evil in the fool’s heart on the left and brings all the souls of Israel near to the Holy One, blessed be He, because he is the aspect of the heart of all Israel. As we have said many times, the king is Israel’s heart and introduces the power of repentance into all the hearts of the children of Israel. Through Torah and prayer they uproot the evil inclination from their hearts, purify their hearts from every abomination and defilement, and repair all the damage.',
   'This parallel explains the wordplay between zemirot, songs, and pruning. It connects David’s psalms with repentance and the removal of harmful forces from the heart.')

ref='Peri Tzadik, Parshat Parah 7:1'
inside(208,'peri-tzadik-three-impurities-and-three-traits',26,'peri-tzadik',ref,
   cut_bare(local('peri-tzadik',ref),'והנה יש ג\' טומאות','וג"ע ושפיכת דמים תאוה וקנאה.'),
   'There are three impurities corresponding to the three kelipot of envy, desire, and honor. The impurity of tzaraat comes through slander, which arises from hatred of other people and the kelipah of anger and envy; this is the kelipah of Esau. The impurity of a bodily discharge comes through desire, the kelipah of Ishmael, which is alien cravings and loves. The impurity of the dead corresponds to the kelipah of pride and honor, which is the root of the serpent’s enticement, “You shall be like God.” This was explained in teaching 6. From these three kelipot branch the three grave transgressions: idolatry, forbidden sexual relations, and bloodshed. The culmination of pride reaches the declaration, “I shall ascend above the heights of the clouds; I shall resemble the Most High.” Forbidden sexual relations and bloodshed correspond to desire and envy.',
   'This parallel makes explicit Rav Tzadok’s symbolic association of tzaraat with envy and corpse impurity with honor, placing them alongside the third member, desire. These are his spiritual correspondences, distinct from the legal definitions of ritual impurity.')


ex(209,'ran-distinguishes-meanings-of-iyun-tefillah',1,'Ran on Rosh Hashanah 3b:4',ext('Ran on Rosh Hashanah 3b',4),
   '“Examination of prayer”: He relies on his prayer and is confident that it will be heard. As for what we say in the chapter Get Pashut, that there are three transgressions from which no person is free each day, one of which is examination of prayer—the examination of prayer there is not the same as here. Were it the same, how could it say that no one is free of it each day? There are many people who do not rely on their prayer every day. Rather, examination of prayer there means that he does not attend to his prayer. It therefore says that no one is free of it, for no one directs his attention as he should. As we read in the Jerusalem Talmud, Berakhot: Rabbi Ḥiyya said, “All my days I have not concentrated. Once I came to concentrate, and I thought in my heart: Who enters before the king first, the chief official or the exilarch?” Shmuel said, “I counted chicks.” Rabbi Bun, son of Rabbi Ḥiyya, said, “I counted rows of masonry.” Rabbi Matanya said, “I am grateful to my head, for when it reached Modim it bowed of itself.” This is what is meant in the chapter Kol Kitvei HaKodesh: “May I be rewarded for having fulfilled examination of prayer.” It is also what is meant in the chapter Mefannin: There are six things whose fruits a person enjoys in this world, one of which is examination of prayer—that is, he attends to it and directs his intention in it.',
   'Ran distinguishes presumptuous reliance on an answer from insufficient attention in prayer, and then explains positive uses of the same expression. His complete discussion includes all four statements from the Yerushalmi. Rav Tzadok offers a further interpretation of those statements here.')

ref='Peri Tzadik, Vayeshev 3:1'
inside(209,'peri-tzadik-two-ways-of-preparing-the-heart',3,'peri-tzadik',ref,
   cut_bare(local('peri-tzadik',ref),'וי"ל שז"ש ר\' חייא רבה מן יומא לא כוונית'),
   'One may explain that this is what Rabbi Ḥiyya the Great meant by “All my days I have not concentrated”: he did not need to straighten his heart and direct it to his Father in Heaven through preparation in Torah or fear, by waiting before prayer. Rather, he would rise and find his heart hoping toward love and fear, as in Rabbi Elazar’s prayer, “May we rise,” and so forth. “Once I wished to concentrate”: on that occasion he needed to prepare for prayer and wait an hour beforehand, and he was unsure which preparation to make—according to the Mishnah or according to the baraita. This is what he meant by “I thought in my heart: Who enters before the king first, the chief official or the exilarch?” The chief official signifies a Torah scholar, as we find in Zevaḥim: “The chief official took my hand, and his scent reached my hand”—because you went before Rav Sheshet, have you become like Rav Sheshet? Rav Sheshet was a Sinai, as it says in Eruvin: “Rav Ḥisda’s lips trembled before the teachings of Rav Sheshet.” This is the meaning of the chief official. The expression concerning the grasp and the scent follows what is said in the Zohar: They caused Issachar to come into the world, because the scent of Torah rose before the Holy One, blessed be He; this is “the mandrakes gave forth their scent.” It also follows the teaching that with each utterance the whole world filled with fragrance. The exilarch, however, is a ruling scepter, as it says in Sanhedrin: “The scepter shall not depart from Judah”—these are the exilarchs in Babylonia, who rule Israel with a rod. We also find in Ḥullin: “For you have striven with divine beings and men”—He alluded to the exilarchs in Babylonia and the patriarch in the Land of Israel. The patriarch’s role is in Torah, as Rashi explains that those ordained are called elohim; the exilarchs are the “men,” the ruling scepter. We find in Berakhot that once a king bows, he does not straighten up, for he is full of fear, submission, and dread. Rabbi Ḥiyya was therefore unsure which preparation to make in order to direct and straighten his heart to his Father in Heaven: through gravity, submission, and fear, signified by the exilarch’s level and corresponding to the Mishnah; or through a conclusive halakhah, corresponding to the baraita and signified by the chief official. This is what he meant: Who enters before the King first—the chief official, signifying Torah, or the exilarch, signifying fear? In truth, both are one, as it says in Avot: “If there is no wisdom, there is no fear; if there is no fear, there is no wisdom.” Rabbi Ḥiyya was unsure only where the awakening should begin: with Torah, or with fear and submission. “Who enters before the King first” means which should come first.',
   'This parallel supplies a further reading of the particular thought about precedence before a king: it becomes a question about preparing for prayer through Torah or through fear. The conclusion preserves the unity of both approaches; the question concerns their order.')

ex(209,'rambam-the-practice-of-concentration',4,'Mishneh Torah, Prayer and the Priestly Blessing 4:16',ext('Mishneh Torah, Prayer and the Priestly Blessing 4:16'),
   'What is concentration? One clears his heart of all thoughts and sees himself as though he were standing before the Shekhinah. Therefore he should sit for a little while before prayer in order to direct his heart, and afterward pray calmly and pleadingly. He should not make his prayer like someone carrying a burden who casts it off and goes away. Therefore he should sit for a little while after prayer and then depart. The early pious ones would wait one hour before prayer and one hour after prayer, and extend the prayer itself for one hour.',
   'Maimonides describes the ordinary practice of directing the heart: preparation, awareness of standing before the Shekhinah, and unhurried supplication. This provides the practical meaning of the concentration whose necessity Rav Tzadok discusses.')

ref='Tzidkat HaTzadik 233:1'
inside(209,'tzidkat-hatzadik-an-alternative-reading-of-distraction',10,'tzidkat-hatzadik',ref,
   cut_bare(local('tzidkat-hatzadik',ref),'להנצל ממחשבות זרות','לכך אין אדם ניצול ממחשבות זרות.'),
   'To be saved all day from alien thoughts and thoughts outside the will of the blessed God is possible only for one entirely free of personal self-interest. This is when he has already killed the evil inclination, as did King David, peace be upon him; “whoever wins the battle is given” prayer, as stated at the end of Tikkun 13. Whoever is not free of alien thoughts all day will not escape alien thoughts in prayer either. Thus Bava Batra says that no one is free of examination of prayer, apparently speaking of every person. The words of the Yerushalmi cited by Tosafot, “All my days I have not concentrated,” then retain their plain meaning: he could not escape every flash of an alien thought throughout the entire prayer. The thought “Who enters before the king?” concerns honor. Because of an attachment to honor, this thought entered on the day he wished to concentrate, when he prepared himself like the early pious ones who waited in order to direct their hearts—that is, to straighten the heart so that it would contain no self-interest or desire apart from the will of the blessed God. Perhaps at that moment the blessed God would help him win the battle and remove the inclination from within him. The thoughts “I counted chicks” and “rows of masonry,” concerning possessions, arise from an attachment to the desire for money. “I am grateful to my head” means that envy brings an alien thought at Modim, the thanksgiving for God’s kindnesses: the envious person feels deprived and does not thank the blessed God for His benefits, but instead complains that He gives benefit to another. This is the meaning of Bava Kamma’s teaching about a person’s spine, applying it to one who did not bow at Modim, for “envy rots the bones.” The serpent’s root is envy, as the Sages said: he saw and became envious. Eve likewise fed Adam because of envy. It is known that almost no one is entirely free of these three—envy, desire, and honor. As I wrote above, “Who can stand before envy?” Concerning desire, the Sages said, “Even the most pious of the pious,” and so forth. All the more so honor, which includes both, as is known. Therefore no one escapes alien thoughts.',
   'Later in the same work, Rav Tzadok explicitly develops the Yerushalmi’s plain reading as an alternative to the interpretation offered here. This passage preserves that difference and traces the distracting thoughts to the three traits, rather than presenting one interpretation as his only explanation.')

ref='Tzidkat HaTzadik 223:1'
inside(209,'tzidkat-hatzadik-four-cubits-and-the-work-of-prayer',20,'tzidkat-hatzadik',ref,
   cut_bare(local('tzidkat-hatzadik',ref),'וכמו ששמעתי, דארבע אמות של הלכה','דזריק ביה גירא בתר גירא.'),
   'As I heard, the four cubits of halakhah are holy with the holiness of the Land of Israel. The air of the lands of the nations is expelled from them entirely on every side by the double-edged sword, and the holy air of words of Torah enters. This is the air of the Land of Israel, which therefore imparts wisdom, like Torah’s quality of making the simple wise. But the synagogue and prayer do not help when a person has already encountered and become entangled in alien thoughts, for his entire prayer will likewise be full of alien thoughts. Rather, he must direct his heart to distance himself from alien thoughts; then through prayer he can bring holy thoughts into the depth of the heart and kill the evil from afar, as in “their tongue is a sharpened arrow.” The tongue is like an arrow that kills from a distance, and this is through prayer, as stated in the Tikkunim, at the end of Tikkun 13 and elsewhere: he shoots arrow after arrow at it.',
   'This parallel repeats the teaching about the four cubits of halakhah and then preserves the complementary power of prayer. Torah clears the immediate surrounding thoughts; properly directed prayer works upon the heart’s deeper interior.')

ex(209,'tosafot-interrupting-study-for-prayer',21,'Tosafot on Shabbat 11a:8:2',ext('Tosafot on Shabbat 11a',8,2),
   '“People like us interrupt both for Shema and for prayer”: As for Rabbi Zeira’s saying to Rabbi Yirmeya, “One who turns his ear from hearing Torah,” and so forth, one may answer that Torah was his occupation, or that the time for prayer was not yet about to pass.',
   'Tosafot explains the episode cited in the existing Shabbat note with two alternatives. Its distinction concerning a prayer time that is not yet passing is retained, so the verse is not presented as an unrestricted refusal to interrupt study.',
   anchorEnd=end(209,21,'(משלי כח, ט; שבת י.)'))

ex(209,'berakhot-two-preparations-and-joy-of-a-commandment',24,'Berakhot 31a:10-11',span('Berakhot 31a',10,11),
   'The Sages acted according to the Mishnah; Rav Ashi acted according to the baraita. The Sages taught: One should not stand to pray from sadness, idleness, laughter, conversation, levity, or idle matters, but from the joy of a commandment.',
   'The preceding Mishnah requires gravity, while the preceding baraita requires a conclusive halakhah. The Gemara names the practices followed by the Sages and Rav Ashi, then adds the requirement of the joy of a commandment. This completes the discussion cited in the existing note.')

ex(209,'rambam-gravity-and-settled-thought',25,'Rambam on Mishnah Berakhot 5:1:1',
   cut(ext('Rambam on Mishnah Berakhot 5:1',1),'אין עומדין להתפלל','ואז יתחילו בתפלה'),
   '“One does not stand to pray except with gravity,” and so forth: Gravity means standing with intention and fear, as it says, “Serve the Lord with fear.” “They would wait” means that they delayed for one hour before prayer in order to settle their minds and quiet their thoughts, and only then would they begin prayer.',
   'Maimonides explains the Mishnah’s gravity as intention and fear, and its waiting as the settling of the mind. This directly supplies the meaning of the alternative preparation at the close of Rav Tzadok’s discussion.')


G=json.loads((HERE/'guide-2-36-ibn-tibbon.json').read_text())
b.add(210,'guide-three-conditions-of-prophetic-attainment',2,'Guide for the Perplexed, Part 2 36:4',bare(G['he'][3]),
   'It is known that in the three matters we have included—the perfection of the rational faculty through learning, the perfection of the imaginative faculty in its original constitution, and the perfection of character through withdrawing thought from all bodily pleasures and removing the desire for the foolish and harmful kinds of self-aggrandizement—those who are perfected differ greatly from one another. According to the degree of difference in each of these three matters, the ranks of all the prophets differ from one another.',
   'Maimonides summarizes the intellectual, natural, and ethical conditions in his account of prophecy. The withdrawal from bodily desire belongs to this larger set of conditions; the passage does not describe it as a sufficient condition by itself.',
   sourceFile='review-work/review196/guide-2-36-ibn-tibbon.json',
   anchorEnd=end(210,2,'כמו שכתוב במורה נבוכים'))
b.entries[-1]['sourceEvidence'][0]['heVersionTitle']=G.get('heVersionTitle')
b.entries[-1]['sourceEvidence'][0]['edition']='Samuel ibn Tibbon Hebrew translation; original historical text.'

ex(210,'radak-prophecy-and-the-cessation-of-ordinary-senses',2,'Radak on I Samuel 19:24:1',ext('Radak on I Samuel 19:24',1),
   '“He too stripped off his clothes”: This teaches that the other prophets stripped off their clothes, for “he too” includes them. The matter is that when prophecy comes upon a person, his senses cease to function and he falls, as it says of Balaam, “fallen, with eyes uncovered,” and as Daniel says, “I was in a deep sleep on my face, with my face to the ground.” Sometimes he strips off his clothes because of the great cessation of his sensory and psychic activities, and he remains with the intellectual faculty alone.',
   'Radak explains the bodily behavior described in the narrative through the suspension of ordinary sensory activity. Rav Tzadok uses the narrative to explain the spiritual meaning of divestment.',
   anchorEnd=end(210,2,'(שמואל א יט, כד)'))

ex(210,'shaarei-kedusha-the-body-as-a-garment',2,"Sha'arei Kedusha, Part 1 1:4",ext('Shaarei Kedusha, Part 1 1',4),
   'It is known to those of understanding that the human body is not the person himself as regards the body, for it is called “the flesh of a person,” as it is written, “You clothed me with skin and flesh, and covered me with bones and sinews”; and it is also written, “It shall not be poured upon the flesh of a person.” Thus the person is the inward being, while the body is a garment in which the rational soul—the person himself—is clothed while in this world. After death, that garment is stripped away and the soul is clothed in a pure, clean, spiritual garment, as it is written, “Remove the filthy clothes,” and “I shall clothe you in robes.” This is called the garment of the sages.',
   'Rabbi Ḥayyim Vital states the soul-and-garment analogy invoked here. His description includes both life in the body and the different garment after death.',
   anchorEnd=end(210,2,'שהגוף הוא לבוש לנפש כנודע'))

ex(210,'rashi-the-aramaic-word-barshan',3,'Rashi on I Samuel 19:24:2',ext('Rashi on I Samuel 19:24',2),
   '“And he fell naked”: “And he fell barshan.” Jonathan rendered it, “And he fell naked.” In the name of Rabbi Menaḥem, who heard it from an Arab: barshan in Arabic means mad.',
   'Rashi records both the rendering as naked and the explanation of barshan as mad. The latter is the lexical interpretation Rav Tzadok adopts in explaining the prophet’s lack of attention to bodily activity.',
   anchorEnd=end(210,3,'פירוש משגע'))

ex(210,'radak-the-prophet-called-mad',4,'Radak on II Kings 9:11:2',ext('Radak on II Kings 9:11',2),
   '“This madman”: They called the prophet mad because at times during prophecy his behavior was like that of a madman who had lost his reason, as it says, “He too stripped off his clothes,” because their senses and psychic faculties cease their ordinary activity. The wicked Israelites, whose minds and hearts followed Baal, called the prophet of the Lord mad as an expression of contempt.',
   'Radak distinguishes the prophet’s unusual behavior from the contemptuous way the followers of Baal spoke of him. Both parts of his explanation are retained.')

ex(210,'rambam-god-knower-and-knowledge',9,'Mishneh Torah, Foundations of the Torah 2:10',plain(D['Mishneh Torah, Foundations of the Torah 2:10']['he']),
   'The Holy One, blessed be He, recognizes His own reality and knows it as it is. He does not know through knowledge outside Himself, as we know. For we and our knowledge are not one, but the Creator, blessed be He, His knowledge, and His life are one in every respect, from every aspect, and in every manner of unity. Were He alive through life and knowing through knowledge outside Himself, there would be many divinities: He, His life, and His knowledge. It is not so; rather, He is one in every respect, from every aspect, and in every manner of unity. Thus you say: He is the knower, He is the known, and He is knowledge itself—all one. This is something the mouth cannot express, the ear cannot hear, nor the human heart comprehend fully. Therefore one says ḥei Pharaoh and ḥei your soul, “by the life of Pharaoh” and “by the life of your soul”; one does not say ḥei the Lord, but ḥai the Lord, “the Lord lives.” For the Creator and His life are not two, as are living bodies and their lives, or angels and their lives. Therefore He does not recognize and know created beings through the created beings, as we know them, but knows them through Himself. Because He knows Himself, He knows everything, for everything depends upon Him for its existence.',
   'Maimonides’ statement of divine unity includes its essential qualification: human language and understanding cannot fully comprehend this identity. His conclusion explains that God’s knowledge of creation is through His own reality.',
   anchorEnd=end(210,9,'(פרק ב הלכה י)'))

ex(210,'tanya-torah-understanding-and-union',9,'Tanya, Part I; Likkutei Amarim 5:2-6',span('Tanya, Part I; Likkutei Amarim 5',2,6),
   'When any intellect understands and apprehends an intelligible matter, the intellect grasps and encompasses it in the mind, and the intelligible matter is grasped, encompassed, and clothed within the intellect that has apprehended and understood it. The intellect is also clothed in that intelligible matter while apprehending and grasping it. For example, when a person correctly and thoroughly understands a halakhah in the Mishnah or Gemara, his intellect grasps and encompasses it, while his intellect is also clothed in it at that time. This halakhah is the wisdom and will of the Holy One, blessed be He: it arose in His will that if, for example, Reuven makes one claim and Shimon another, the ruling between them shall be such and such. Even if such a case never has and never will come to judgment with these claims and demands, nevertheless, since it arose in the will and wisdom of the Holy One, blessed be He, that if one makes this claim and the other that claim, the ruling shall be so, when a person knows and intellectually apprehends that ruling as set out in the Mishnah, Gemara, or legal authorities, he thereby apprehends, grasps, and encompasses in his intellect the will and wisdom of the Holy One, blessed be He. No thought can grasp Him, His will, or His wisdom except as they are clothed in the halakhot set before us; his intellect is also clothed in them. This is a wondrous union, with no comparable union or equivalent anywhere in physical existence: they become actually one and united in every respect.',
   'Tanya explains how understanding Torah is described as attachment to divine wisdom and will. The qualification that this apprehension is through their clothing in the laws of Torah is retained.')

ex(210,'zohar-sages-and-continuing-holy-spirit',10,'Zohar, Shemot 11:84',ext('Zohar, Shemot 11:84'),
   'The sages are greater than prophets at all times, for the holy spirit rests upon prophets at some times and at other times does not; but the holy spirit does not leave the sages even for a single moment. They know what is above and below, but do not wish to reveal it. Rabbi Yose—another reading has Rabbi Yehudah—said: It is all wisdom, and Rabbi Elazar’s wisdom exceeds them all. Rabbi Abba said: Were it not for the sages, people would not know what Torah is or what the commandments of the Master of the world are, and the human spirit would not be distinguished from the spirit of an animal.',
   'This is the Zohar’s explicit contrast between the occasional prophetic experience and the sage’s continuing attainment. Its account also ties the sages’ wisdom to understanding Torah and the commandments.')

ex(210,'rashi-running-and-returning-before-the-shekhinah',11,'Rashi on Ezekiel 1:14:1',ext('Rashi on Ezekiel 1:14',1),
   '“Running and returning, like the appearance of a flash”: Our Sages explained: Running and returning like the flame of a furnace, which continually comes out of the furnace’s opening and quickly returns inside. So, when they put their heads out from beneath the firmament stretched above them, as the passage explains, they recoil before the Shekhinah above the firmament and hasten to draw their heads back.',
   'Rashi explains the living creatures’ movement in Ezekiel’s vision through their immediate recoil before the Shekhinah. This supplies the image behind Rav Tzadok’s description of a momentary illumination.')

ex(210,'tanya-torah-as-food-for-the-soul',13,'Tanya, Part I; Likkutei Amarim 5:9-13',span('Tanya, Part I; Likkutei Amarim 5',9,13),
   'Because, through knowing Torah, Torah is clothed in the person’s soul and intellect and encompassed within them, it is called “bread” and “food for the soul.” Just as physical bread nourishes the body when brought inside it and becomes blood and flesh like its own flesh, enabling it to live and endure, so through knowing and apprehending Torah in the soul—learning it thoroughly through intellectual examination until it is grasped by the intellect and united with it—it becomes food for the soul and life within it, from the Life of life, the blessed Infinite, clothed in His wisdom and Torah within it. This is the meaning of “Your Torah is within my inward parts.” As Etz Ḥayyim, Gate 44, chapter 3, explains, the soul’s garments in the Garden of Eden are the commandments, while Torah is the food of the souls that engaged in Torah for its own sake in this world, as also stated in Zohar, Vayakhel 210. “For its own sake” means in order to bind one’s soul to God through understanding Torah, each according to his intellect, as explained in Peri Etz Ḥayyim. [The food is inward light, while the garments are surrounding lights. Therefore our Sages said that Torah study is equivalent to all the commandments, for the commandments are garments alone, while Torah is both food and a garment for the understanding soul, which clothes itself in Torah through its examination and study. All the more so when one expresses it aloud, for the breath of speech becomes surrounding light, as explained in Peri Etz Ḥayyim.]',
   'Tanya explains the nourishment metaphor through Torah being understood and inwardly absorbed. The discussion retains both the requirement of thorough understanding and its definition of study for its own sake.')

ex(210,'rashi-servant-and-minister-before-the-king',15,'Rashi on Berakhot 34b:28',ext('Rashi on Berakhot 34b',28),
   '“Like a servant”: A member of the household who enters and leaves without permission. “Like a minister before the king”: One who is not accustomed to come before him.',
   'This is the interpretation from which Rav Tzadok expressly distinguishes his own. Rashi associates the servant with familiar access and the minister with less frequent access; Rav Tzadok then develops a different account through prayer and Torah.',
   anchorEnd=end(210,15,'לולי פירוש רש"י'))


decisions={
206:[
 'Preserved every native and connected note. Added the original three-trait and eight-thought texts, the defined seven-king count, wisdom/understanding/knowledge distinctions, and the original humility parallels.',
 'Etz Chaim preserves the difference between the rear aspects’ limited fall and the lower vessels’ death; the new MaH passage retains the role of the prior union.',
 'The initial-illumination parallel is quoted through its withdrawal and the need for acquisition through effort. The existing pride and discouragement notes remain intact.'
],
207:[
 'Preserved all native and connected quotations. Added the declaration-before-command sources and the complete legal distinctions in the Chagigah exemption, including competence and rejoicing.',
 'The work passages retain Torah together with work and Bartenura’s livelihood qualification. Arakhin retains its final exclusion of an extra coin that is easily returned.',
 'The seven-decrees passage was verified at Zohar, Shemot40:314; the exact seven-method list is cited as the original Tosefta parallel rather than silently conflating differing Sifra wording.',
 'The prayer-awakening parallel adds compassion and prayer before distress; Rashi’s alternate meanings of metoraf and the original proper-conduct context of derekh eretz are retained.'
],
208:[
 'Preserved both existing Ashrei notes, both Midrash Tehillim notes, and all other native and connected quotations. Added the exact redemption-to-prayer statement and the Gemara’s separate explanation of the alphabet and sustenance.',
 'Verified the truth-and-faith passage at Zohar, Pinchas53:332; its no-separation conclusion remains included. The Zohar Chadash unit retains both forty-nine and fifty and the counting-of-the-Omer application.',
 'Verified Solomon’s sea at Eruvin14a:23 and the matching Ishbitz teaching at Mei HaShiloach, VolumeI, Prophets, ISamuel20:1. Preserved its full selected numerical correspondence.',
 'Added the original speech-redemption, psalm-pruning, and three-impurity parallels without repeating the existing quotation that Torah is available before victory over the inclination.'
],
209:[
 'Preserved the existing Tosafot, Shabbat, Resisei Layla, Kometz HaMinchah, and Tiferet Yosef material. Read the complete original Yerushalmi2:4:16; Ran’s full commentary quotes its four sages and distinguishes all three uses of iyun tefillah.',
 'Peri Tzadik supplies the further reading of precedence before the king as the choice of preparation. The allusion to the chief official was checked against Zevachim96b:2 and Rashi’s explanation as a duke, not a perfume vessel.',
 'Tzidkat HaTzadik233 explicitly records a different plain reading of the same Yerushalmi. Its distinction from209 is made clear rather than harmonized away.',
 'The four-cubits parallel retains the complementary inward work of properly directed prayer. Tosafot retains both alternatives concerning interruption of study; the closing sources preserve gravity, settled thought, and joy of a commandment.'
],
210:[
 'Preserved all native and connected notes, including the divestment discussion and the existing Gemara servant/minister note. Added original lexical and conceptual sources only.',
 'The Guide excerpt uses the original Ibn Tibbon translation and retains the full threefold conditions of prophecy. Radak retains the distinction between prophetic behavior and the contempt of Baal’s followers.',
 'Maimonides’ divine-knowledge passage retains the limit on human comprehension and the distinction in the vocalization of the life expressions. Tanya retains apprehension through Torah’s clothing in halakhah.',
 'The Zohar’s continuing-sage passage and Rashi’s running-and-returning explanation were read in their original contexts. Tanya’s food passage retains thorough understanding, study for its own sake, and the enclosing-garment qualification.',
 'Rashi’s actual servant/minister explanation is quoted separately and explicitly distinguished from Rav Tzadok’s interpretation.'
]}
observations=[
 {'section':207,'kind':'citation-pagination-distinction','detail':'The seven Egyptian decrees and seven blessings are Zohar, Shemot40:314, in the index mapping of printed18a. A supplied-edition footnote cites18b. The canonical reader body and existing notes are unchanged; the addition uses the verified canonical paragraph.'},
 {'section':207,'kind':'textual-variant-not-applied','detail':'The supplied seven-method list and the fetched Sifra Baraita DeRabbi Yishmael17 list have wording/counting differences. The new note cites the verified original Tosefta Sanhedrin7:5 parallel explicitly. It does not claim that the Tosefta wording is a transcription of Sifra, and no body correction is applied.'},
 {'section':208,'kind':'citation-pagination-distinction','detail':'The truth/faith and Holy One/Shekhinah pairing is Zohar, Pinchas53:332, mapped to printed230b. The230a reference appearing in one supplied edition maps to another passage; the new note uses the exact original paragraph.'}
]
b.entries.sort(key=lambda e:(e['section'],e['phraseIndex'],e['heCharOffset']))
if __name__=='__main__':b.save(decisions,observations)
