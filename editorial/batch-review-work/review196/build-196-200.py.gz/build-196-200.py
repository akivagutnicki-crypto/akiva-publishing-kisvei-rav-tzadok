from common import *

D=json.loads((HERE/'primary.json').read_text())
def ext(ref,*indices):
    t=D[ref]['he']
    for i in indices:t=t[i-1]
    return bare(t)
def span(ref,a,b):return bare(D[ref]['he'][a-1:b])
def ex(b,s,id,pi,ref,he,en,ctx,**kw):
    b.add(s,id,pi,ref,he,en,ctx,sourceFile='review-work/review196/primary.json',**kw)
def inside(b,s,id,pi,book,ref,he,en,ctx,**kw):
    b.add(s,id,pi,ref,he,en,ctx,book=book,**kw)

pages={
196:{'integratedB':[75,76,77,78,79,80,81],'neimosB':[64,65,66,67,68,69]},
197:{'integratedB':[81,82,83,84,85,86],'neimosB':[69,70,71,72,73,74]},
198:{'integratedB':[86,87,88,89,90,91,92,93],'neimosB':[73,74,75,76,77,78,79,80]},
199:{'integratedB':[93,94,95,96,97],'neimosB':[81,82,83,84,85]},
200:{'integratedB':[97,98,99,100,101,102],'neimosB':[85,86,87,88,89,90]}}
b=Batch(196,pages)

# 196: three loves, companionship, and the concealed root of the soul.
old=json.loads((OUT/'ois-161-165.json').read_text())
z=next(e for e in old['entries'] if e['ref']=='Zohar, Achrei Mot 50:299')
ex(b,196,'zohar-god-torah-israel-bound-together',0,z['ref'],z['he'],z['en'],
   'The Zohar explicitly joins God, Torah, and Israel, and distinguishes the hidden and revealed aspect of each. This is the source behind the opening statement that the three loves belong together.')

ref='Mei HaShiloach, Volume I, Talmud, Berakhot 54a:1'
he=cut_bare(local('mei-hashiloach',ref),'והנה זה הענין היה בבועז:')
inside(b,196,'mei-hashiloach-boaz-greeting-in-gods-name',3,'mei-hashiloach',ref,he,
   'This was the matter with Boaz: by nature Boaz loved companionship, and he feared for himself that this might not be clarified as being for the sake of Heaven. He therefore instituted a restraint for himself: immediately upon seeing his fellow, his first words would be to inquire in God’s name—that they should mention and ask whether he had now, God forbid, departed from God’s name through any forgetfulness. This was to clarify his character, so that his companionship would be clearly intended for the sake of Heaven. After he devised this counsel, “they instituted” it: the Holy One, blessed be He, bestowed it and engraved it in the hearts of the children of Israel. This is why “they instituted” is plural.',
   'The Ishbitzer explains both Boaz’s personal concern and the Mishnah’s plural wording. Rav Tzadok’s report of what he heard has this direct parallel in Mei HaShiloach.')

ex(b,196,'mishnah-boaz-greeting-in-gods-name',2,'Mishnah Berakhot 9:5',
   cut(ext('Mishnah Berakhot 9:5'),'והתקינו, שיהא אדם שואל','רבי נתן אומר, הפרו תורתך עת לעשות ליי:'),
   'They instituted that a person should greet his fellow using God’s name, as it says: “Boaz came from Bethlehem and said to the reapers, ‘The Lord be with you’; and they said to him, ‘The Lord bless you.’” It also says: “The Lord is with you, mighty man of valor”; and: “Do not despise your mother when she is old”; and: “It is time to act for the Lord; they have violated Your Torah.” Rabbi Natan says: “They have violated Your Torah”—because it is time to act for the Lord.',
   'This is the original enactment cited here. The following Mei HaShiloach passage explains the spiritual purpose Rav Tzadok finds in Boaz’s greeting.',
   anchorEnd='שְׁאִילַת שָׁלוֹם בַּשֵּׁם')

ex(b,196,'zohar-purified-inclination-and-torah-delight',6,'Zohar, Toldot 6:57',ext('Zohar, Toldot 6:57'),
   'Rabbi Yitzḥak son of Rabbi Yosei was traveling from Cappadocia to Lod and encountered Rabbi Yehuda. Rabbi Yitzḥak said to him: Do you say that our companions, the sages of the teaching, have explained this matter—that the evil inclination will be removed from the world except at the time of union? He replied: By your life, the evil inclination is as necessary to the world as rain. Without the evil inclination there would be no delight in a teaching; but it will not be defiled as formerly, so that one sins through it. This is what is written: “They shall neither harm nor destroy throughout My holy mountain.” Rabbi Shimon said: This is the heart, in which the evil inclination dwells. Rabbi Eliezer says: A good heart is the building of the body and soul; therefore it is written, “You shall love the Lord your God with all your heart,” for it is the root of everything.',
   'This passage in Midrash HaNe’elam, traditionally cited at Zohar I 138a, connects the power of desire to the delight of Torah. Its description of the future expressly preserves the removal of the inclination’s former power to cause sin.')

ref='Resisei Layla 17:1'
he=cut_bare(local('resisei-layla',ref),'וזה ענין שאמרו','דהעונג נמשך רק מן ההיפך.')
inside(b,196,'resisei-layla-angels-knowledge-and-human-delight',6,'resisei-layla',ref,he,
   'This is the meaning of the statement that the righteous are greater than the ministering angels. We also find the reverse stated many times, as Rabbi Abraham ibn Ezra wrote: the angels’ apprehension is certainly greater, as Rabbi Moses ben Maimon wrote. Yet they have no delight, as it was said, “Is there an evil inclination among you?” For delight proceeds only from its opposite.',
   'Rav Tzadok distinguishes the measure of intellectual apprehension from the delight born of overcoming concealment. This explains how he can grant the angels wisdom while locating the human contribution in desire.')

ex(b,196,'tanya-soul-as-divine-portion',13,'Tanya, Part I; Likkutei Amarim 2:1',ext('Tanya, Part I; Likkutei Amarim 2:1'),
   'The second soul in Israel is truly a portion of God above, as it is written, “He breathed into his nostrils the breath of life,” and, “You breathed it into me.” As it is written in the Zohar, one who breathes blows from within himself: that is, from his inwardness and interior, for in forceful breathing a person brings forth the inward and interior vitality within him.',
   'Tanya reads the soul’s origin through the image of divine breathing. Rav Tzadok invokes the same origin when explaining the soul’s purity at its root.')

ex(b,196,'eikhah-torah-light-returns-to-good',14,'Eikhah Rabbah, Petichta 2',
   cut(ext('Eikhah Rabbah, Petichta 2'),'רבי הונא ורבי ירמיה בשם רבי חיא','שמתוך שלא לשמה בא לשמה.'),
   'Rabbi Huna and Rabbi Yirmeya said in the name of Rabbi Ḥiyya bar Abba: It is written, “They have forsaken Me and have not kept My Torah.” If only they had forsaken Me but kept My Torah! Through occupying themselves with it, the light within it would have returned them to the good. Rav Huna said: Study Torah even when it is not for its own sake, for from doing so not for its own sake one comes to do so for its own sake.',
   'The Midrash supplies both the striking formulation “If only they had forsaken Me” and the explanation that Torah’s light brings a person back. Rav Tzadok develops this as the revelation of an underlying love that has not been severed.',
   anchorEnd='"הַלְוַאי אוֹתִי עָזָבוּ וְאֶת תּוֹרָתִי וְכוּלֵי"')

ex(b,196,'derekh-hashem-gradual-torah-light-and-conditions',16,'Derekh Hashem, Part Four, On Torah Study 6',
   cut(ext('Derekh Hashem, Part Four, On Torah Study',6),'ואעפ״י כן'),
   'Nevertheless, the Sages of blessed memory revealed to us a great secret: if the wicked had not abandoned Torah study, they would eventually have returned to the good. Although they lack the power to draw any influence from before Him, blessed be He, as we have said, the words of Torah themselves remain intrinsically holy. Through persistent engagement with them, a little awakening and something like the faintest illumination reaches the student time after time, until eventually it prevails over him and returns him to the good. This is what the Sages wrote: “If only they had forsaken Me but kept My Torah, for its light returns them to the good.” It is, however, evident that this does not refer to someone who engages in it mockingly or derisively, or interprets it contrary to the accepted law. He must at least engage in it as one engages in other branches of wisdom.',
   'Ramḥal explains the gradual action of Torah’s light even where the ordinary conditions for drawing its spiritual influence are lacking. The closing restrictions on mockery and distorted interpretation are essential to that explanation.')

ref='Tzidkat HaTzadik 90:1'
he=cut_bare(local('tzidkat-hatzadik',ref),'התורה הוא מפת העולם','על מצב התורה שבפיות תלמידי חכמים האמתיים שבאותו דור')
inside(b,196,'tzidkat-ninety-torah-souls-and-the-world',23,'tzidkat-hatzadik',ref,he,
   'The Torah is the map of the world, as stated at the beginning of Bereshit Rabbah in the parable of the plans and notebooks. Likewise, Israel in every generation [for Israel and the Torah are one, as is known: the light of Israel’s souls is itself the light of Torah, and it is stated that the Torah has six hundred thousand letters] is the map of the world in that generation. As the souls of Israel are renewed in each generation, so is the world renewed at that time, as stated in Yevamot: even ships and so forth exist for Israel. As souls change from generation to generation, so does Torah—that is, the Oral Torah, in which the sages of Israel produce new insights in every generation. Through every new insight in the Oral Torah, new souls of Israel come to light, and in accordance with them matters in the world are also renewed. From the condition of the world in any generation, we can reflect on the condition of Israel’s souls in that generation and on the Torah in the mouths of that generation’s true scholars.',
   'Section 90 gives the fuller relationship between Torah, the souls of a generation, and the world they inhabit. It explains why the Torah can function here as an exposition of what is hidden within the souls. The six hundred thousand letters express a spiritual correspondence between Torah and souls.')

ref='Peri Tzadik, Parshat Shekalim 1:2'
he=cut(local('peri-tzadik',ref),'וחכמת כל חכמי ישראל','נעלם מכל ישראל.')
inside(b,196,'peri-tzadik-hidden-wisdom-of-each-soul',25,'peri-tzadik',ref,he,
   'The wisdom of all the sages of Israel is a portion of His wisdom, blessed be He, as the blessing over the sages of Israel says: “Who has apportioned of His wisdom to those who fear Him.” These are the sages of Israel, in whom wisdom is revealed. Every other individual of Israel has some secret of His wisdom hidden at the root of his soul, of which he himself is unaware; this is the root of his vitality, as it is written, “Wisdom gives life to its possessors.” Through this, each person has an elevation above all Israel on account of the divine portion above at the root of his soul, containing a mystery and a secret concealed from all Israel.',
   'The contrast is between wisdom already revealed in scholars and wisdom still concealed in every other soul. This directly explains the final statement about Torah disclosing the depths hidden within each individual.')

# 197: all the heart, soul, and possessions; keep the legal qualifications.
ref='Kometz HaMinchah 2:16:1'
he=cut_bare(local('kometz-haminchah',ref),'ידוע דתיקון המדות','משתמש בכחותיו לטוב.')
inside(b,197,'kometz-two-inclinations-after-victory',1,'kometz-haminchah',ref,he,
   'It is known that the correction of the character traits is to raise them to their source. Then the correction of the severity of the husk is through holy severity, being zealous against those who transgress His will; and the correction of the husk’s desire is through holy desire, longing for God. Victory, however, comes through the opposite; this transformation is for someone who has already won. Tanya, chapter 27, likewise says that this is only for a completely righteous person, whose alien thoughts come to him from others; see there. One engaged in battle opposes his adversary: if the adversary sets fire against him, he applies water and extinguishes it. But one who has already won and taken possession repairs everything the enemy prepared against him for battle, so that it serves the same function for his own use. Thus it was said: those bedclothes she prepared for him in prohibition she prepared for him in permission and for the sake of a commandment. And this is “with all your heart”—with both your inclinations: with the good inclination in subjugation and battle, and with the evil inclination after defeating it, when one uses its powers for good.',
   'Rav Tzadok distinguishes resisting an inclination while the struggle continues from redirecting its powers after victory. This qualification governs his reading of “with both your inclinations.”')

ref='Et HaOchel 14:1'
he=cut_bare(local('et-haochel',ref),'ועל זה הוא אכילת לחם עני','ולא יוכל לכלכל בלב עד כי ידבר בפה וירעיש בקול.')
inside(b,197,'et-haochel-poor-prayer-pours-out-the-soul',6,'et-haochel',ref,he,
   'For this there is the eating of the bread of affliction, in the sense of “A prayer of the poor when he is overwhelmed,” which envelops all prayers and breaks through the heavens. Because of the magnitude of his want, the poor person pours out his plea with an outpouring of his soul, like Hannah’s pouring out her soul. He cannot contain it in his heart until he speaks with his mouth and cries aloud.',
   'Et HaOchel describes prayer arising from a need felt with one’s whole life. It connects the poor person’s prayer directly to Hannah, as Rav Tzadok does here.')

ex(b,197,'maharal-tefillin-attachment-and-awe',9,'Gevurot Hashem 39:2',ext('Gevurot Hashem 39',2),
   'This is what is written: “All the peoples of the earth shall see that the name of the Lord is called upon you, and they shall fear you.” Rabbi Eliezer said: these are the tefillin on the head. The explanation is that tefillin show that Israel is set apart for the unique Name, since the tefillin mention the exodus from Egypt, when He brought them out through miracles; the unique Name specifically performs wonders. Therefore “they shall fear you,” because of His mighty and awesome deeds. Rabbi Eliezer specified the tefillin on the head because the tefillin on the arm express Israel’s attachment to the Holy One, blessed be He; therefore it says of them, “You shall bind them.” This is the difference between the tefillin of the hand and the head. Those of the hand express the connection and attachment Israel has to the Holy One, blessed be He. From this aspect there is no fear, but connection and attachment to Him, for where there is connection there is no fear. With those of the head, however, there is no binding of that kind; rather, His name is called upon them. In having His name called upon them He is distinct from them, being called “the God of Israel.” As their God He is distinct from them, and from this aspect there is fear, for it is fitting to fear the God of Israel, to whom might belongs. Understand this.',
   'Maharal distinguishes the attachment symbolized by the arm-tefillin from the awe associated with the divine name on the head-tefillin. His explanation gives a precise source for the link between tefillin and attachment.',
   anchorEnd='שֶׁפֵּירוּשׁ דְּבֵקוּת')

ref='Tzidkat HaTzadik 91:1'
he=cut_bare(local('tzidkat-hatzadik',ref),'וזה סוד מה שכתוב בבראשית רבה','ואין כאן מקומו להאריך:')
inside(b,197,'tzidkat-ninety-one-jacobs-flocks-and-souls',21,'tzidkat-hatzadik',ref,he,
   'This is the secret of what is stated in Bereshit Rabbah, section 73, that Jacob had six hundred thousand flocks of sheep. His soul comprised the six hundred thousand souls of Israel, each comprising its particular generations. Portions of the light of his soul then spread into the sheep, a pure animal, for at that time he was still called Jacob, the level of an unlearned person, as stated at the end of the chapter “Elu Metziot.” Israel is also compared to sheep. They were his possession, from which he earned his livelihood, for a person’s principal vitality is hidden in that which sustains him: livelihood is the principal support of his life. This is why it was said, “Do not throw a clod into the well from which you drank”—one must not treat it contemptuously. This is not the place to elaborate.',
   'This earlier section explains the correspondence between Jacob’s flocks and Israel’s souls, and why a person’s means of livelihood bears a particular connection to his vitality.')

ex(b,197,'shabbat-utensil-rest-beit-shammai-qualification',20,'Shabbat 18a:8',
   cut(ext('Shabbat 18a',8),'והשתא דאמר רב אושעיא','אף על גב דקעביד מעשה — שרי.'),
   'Now that Rav Oshaya said in Rav Asi’s name: Who is the tanna who holds that the Sabbath rest of utensils is required by Torah law? It is Beit Shammai, and not Beit Hillel. According to Beit Shammai, whether the utensil performs an action or performs no action, it is forbidden. According to Beit Hillel, even if it performs an action, it is permitted.',
   'The discussion concerns work set in motion before Shabbat. The legal doctrine of utensil-rest is identified here as Beit Shammai’s position. Rav Tzadok uses its spiritual meaning in describing the extension of Sabbath holiness into possessions; the source must not be read as an undisputed practical prohibition.')

ref='Tzidkat HaTzadik 254:1'
he=cut_bare(local('tzidkat-hatzadik',ref),'וכן "בכל מאדך"','והוא משעבדו לאהבת השם יתברך ועבודתו.')
inside(b,197,'tzidkat-jacob-gives-what-he-values',24,'tzidkat-hatzadik',ref,he,
   'Likewise, “with all your might” is our father Jacob, of whom they said that he remained behind for small vessels, because his money was dearer to him than his body. In him there was the generosity of “all your might,” and in him this trait was clarified—not in someone who is naturally lavish and to whom money has no importance at all. Nevertheless, they said, “I praise the lazy,” for it is certainly still good, and such a person is called “idle and rewarded”; but he is not on the level of “with all.” “All” denotes that to which one’s soul is naturally bound, and which one subordinates to the love and service of the blessed God.',
   'The later section explains why Jacob’s valuing his possessions matters: devotion is tested in precisely what a person naturally holds dear. It retains the qualification that an easier good action is still good and rewarded.')

ex(b,197,'sotah-moses-tabernacle-not-captured',27,'Sotah 9a:13-14',span('Sotah 9a',13,14),
   'Rav Ḥinena bar Pappa expounded: What is the meaning of “Sing joyfully, righteous ones, in the Lord; praise is fitting for the upright”? Read not “praise is fitting,” but “a dwelling of praise.” This refers to Moses and David, whose enemies did not gain control of their handiwork. Of David it is written, “Her gates have sunk into the earth.” Of Moses, the Master said: When the First Temple was built, the Tent of Meeting was hidden away—its boards, clasps, bars, pillars, and sockets. Where? Rav Ḥisda said in Avimi’s name: in the subterranean passages of the Sanctuary.',
   'The Gemara supplies the concrete example behind the claim: Moses’ Tabernacle and its components were hidden rather than captured. Rav Tzadok reads their preservation as holiness enduring in a person’s work.',
   anchorEnd='שֶׁלֹּא שָׁלְטוּ שׂוֹנְאִים בְּמַעֲשֵׂה יָדָיו')

# 198: Torah's response, discerning individual souls, and the limits of legal inference.
ex(b,198,'rashi-torah-petitions-for-its-student',1,'Rashi on Sanhedrin 99b:1:4',ext('Rashi on Sanhedrin 99b:1:4'),
   '“His Torah labors for him”—it goes about on his behalf and asks its Maker to entrust him with the reasons and ordered principles of Torah. Why all this? Because he pressed and bent his mouth to the words of Torah.',
   'The Gemara says that while a person labors in one place, his Torah labors for him elsewhere. Rashi explains that reciprocity as Torah’s petition that its student receive its reasons and principles.')

ex(b,198,'rashi-breastplate-letters-protrude-in-place',6,'Rashi on Yoma 73b:7:1',ext('Rashi on Yoma 73b:7:1'),
   '“Protrude”—the letters protrude; for example, the ayin from Shimon, the lamed from Levi, and the heh from Yehuda, to say “Go up.” Each letter does not move from its place; rather, it protrudes in its place, and he combines them.',
   'Rashi explains Rabbi Yoḥanan’s account of the Urim and Tummim. The letters become prominent in their own locations, and the priest combines them; Rav Tzadok develops that prominence as something recognized within the loving heart.')

ref='Tzidkat HaTzadik 174:1'
he=cut_bare(local('tzidkat-hatzadik',ref),'והוא בחדש שבט','דהפוגם נקרא רע כדאיתא בזהר].')
inside(b,198,'tzidkat-tet-and-tzadi-letter-connection',11,'tzidkat-hatzadik',ref,he,
   'It is in the month of Shevat, which was formed with the letter tzadi, as stated in Sefer Yetzirah [and tet frequently interchanges with tzadi in Aramaic, as stated in the glosses to the Arukh. This accords with “Say of the righteous that he is good,” for one who damages the covenant is called evil, as stated in the Zohar].',
   'In its discussion of repairing the covenant, section 174 explicitly links tet with tzadi and with “the righteous is good.” This is the author’s own parallel for the letter symbolism used here.')

ref='Sichat Malakhei HaSharet 1:11'
he=cut_bare(local('sichat-malakhei-hasharet',ref),'ובזה נתפארו בני יששכר','שהוא הנשמר מן המכשול למעשה ומכון אל האמת.')
inside(b,198,'sichat-issachar-and-levi-discern-the-needed-action',13,'sichat-malakhei-hasharet',ref,he,
   'In this the children of Issachar were praised: “Those who understood the times, to know what Israel should do.” They know at each time what is suitable for that time and the remedy beneficial to the dispositions of that generation; therefore they are fit to instruct Israel what to do. The tribe of Levi is likewise suited and chosen to know the action appropriate to each particular soul and generation. This comes through complete attachment to the blessed God, as stated in Sanhedrin: “The Lord was with him”—the law followed him everywhere. Reaching the practical legal conclusion, as stated there in Yoma, comes through God’s being with him continually, as it is written, “I have set the Lord before me always.” His heart’s entire purpose is only to be an agent of the Merciful One in His service, drawn after no worldly concern. Of this it is said, “He guards the feet of His faithful ones.” A ḥasid is one separated from every kind of worldly craving, as the Sages explained in Berakhot: the term denotes separation from the three principal worldly desires—envy, appetite, and honor—as the discerning reader will see there. Therefore the holy Zohar says that a ḥasid is called an angel of the Lord, and Torah is to be sought from his mouth: he is guarded from stumbling in practice and directed toward the truth.',
   'The parallel states both the need to discern the person and generation and the conditions of selfless attachment under which that discernment becomes trustworthy. It concerns practical Torah instruction, not private preference.')

ex(b,198,'tanya-compassion-awakens-love-with-qualifications',14,'Tanya, Part I; Likkutei Amarim 32:5-7',span('Tanya, Part I; Likkutei Amarim 32',5,7),
   'But regarding one who is not his companion and is not close to him, Hillel the Elder said: “Be among the disciples of Aaron, loving peace … loving creatures and bringing them close to Torah.” That is, even those distant from God’s Torah and service, and therefore described simply as “creatures,” must be drawn with thick cords of love. With all this, perhaps one may bring them close to Torah and God’s service; if not, one has still not lost the reward of the commandment to love one’s fellows. Even those close to him whom he rebuked and who did not return from their sins, whom it is a commandment to hate, must also be loved. Both are true: hatred on account of the evil within them, and love on account of the hidden good within them—the divine spark within them that gives life to their divine soul. One must also awaken compassion in one’s heart for that soul, for it is in exile within the evil of the other side that overpowers it in the wicked. Compassion cancels hatred and awakens love, as is known from “Jacob, who redeemed Abraham.” [King David’s statement “I hate them with utmost hatred” referred only to the sectarians and heretics who have no portion in the God of Israel, as stated at the beginning of chapter 16 of Shabbat.]',
   'Tanya explicitly connects compassion with awakened love, distinguishing the soul’s hidden good from wrongdoing and explaining the scope of its cited rebuke and hatred passages. The complete qualifications belong with the statement about compassion.')

ref='Likkutei Maamarim, Compositions on the Festivals 16:12'
he=cut_bare(local('likkutei-maamarim',ref),'וכן שמעתי: כי שורש שם "ישראל"','כך שמעתי, ואין כאן מקומו מזה.')
inside(b,198,'likkutei-maamarim-distinct-tribal-names',23,'likkutei-maamarim',ref,he,
   'I also heard that the root of the name “Israel” is in the tribe of Levi. One who hates the chosen righteous person of Levi is called “one who hates Israel”; of Judah, “one who hates the Lord”; of Joseph, “one who hates the righteous”; and of Gad, “one who hates the blameless,” as it is written, “Bloodthirsty men hate the blameless.” Thus I heard; this is not the place to discuss it.',
   'Rav Tzadok records the same received teaching in Likkutei Maamarim, preserving the distinct designation for each tribe. This is a direct authorial parallel to the report “thus I heard” here.')

he=cut(span('Bava Metzia 86a',6,9),'קא מיפלגי במתיבתא דרקיעא:','ויצאתה נשמתך בטהור.')
ex(b,198,'bava-metzia-heavenly-academy-and-rabbah',30,'Bava Metzia 86a:6-9',he,
   'They were debating in the heavenly academy: If a bright skin lesion preceded the white hair, it is impure; if the white hair preceded the lesion, it is pure. In a doubtful case, the Holy One, blessed be He, says: Pure; and the entire heavenly academy says: Impure. They said: Who will decide? Rabbah bar Naḥmani will decide, for Rabbah bar Naḥmani said: I am singular in the laws of skin lesions and singular in the laws of tent-impurity. They sent a messenger after him. The angel of death could not approach him because his mouth did not cease from study. Meanwhile a wind blew and rustled among the reeds. He thought it was a troop of horsemen, and said: Let that man’s soul rest, rather than be delivered into the hands of the government. As his soul departed, he said: Pure, pure. A heavenly voice proclaimed: Fortunate are you, Rabbah bar Naḥmani, for your body is pure and your soul departed with “pure.”',
   'This is the heavenly dispute Rav Tzadok mentions. The narrative identifies the exact uncertainty, the opposing opinions, and Rabbah’s concluding declaration; it belongs beside the preceding discussion of heavenly knowledge and legal decision.')

ref='Resisei Layla 17:1'
he=cut_bare(local('resisei-layla',ref),'וכן בכל דור ודור, אין לך מי שטעם','עד שמשיג שאין חשך ו"כל חשך לא יחשיך וגומר לילה כיום יאיר וגומר".')
inside(b,198,'resisei-solomon-song-of-songs-and-consecrated-love',42,'resisei-layla',ref,he,
   'In every generation, no one tasted all the attractions of this world as King Solomon did, as stated in Ecclesiastes: “I made for myself … and whatever my eyes asked for,” as is known. Nor is there a heart clean of all kinds of desire like his, as the Sages said of the Song of Songs: it is the Holy of Holies. Wherever you find a boundary against forbidden sexuality and desire, there you find holiness. For holiness means separation from desires, being devoted only to the blessed God; these are opposites. Of one immersed in desires it is said, “One who separates himself seeks desire”—he is separated from the blessed God. In holiness, however, one is consecrated to Heaven, as the Sages explain betrothal as a term of consecration, whereby a woman belongs to her husband. Song comes from longing, hence the name “songs of love.” When his soul yearns for the blessed God and is lovesick for Him, his mouth opens to sing before Him. No songs awaken Israel’s love for their Father in Heaven and their union with Him as does the Song of Songs. This love is the opposite of love of this world. Therefore it is the Holy of Holies: wholly belonging to the blessed God, entirely separated from all worldly desires and having no connection with them at all. Such is the measure: the very heart that tastes darkness to its furthest limit and seeks God from there tastes light to its furthest limit, until it apprehends that there is no darkness, and “darkness does not darken … night shines as day.”',
   'Rav Tzadok explains Solomon’s Song of Songs through consecrated longing and separation from worldly desire. The final condition—seeking God from within the darkness—is retained in the account of how darkness leads to light.')

# 199: the three tests of character, with the limitations of trial and anger preserved.
ref='Machshavot Charutz 7:3'
he=cut_bare(local('machshavot-charutz',ref),'אבל רבותינו זכרונם לברכה אמרו','כי שם החשק יותר')
inside(b,199,'machshavot-wealth-as-the-bodys-garment',3,'machshavot-charutz',ref,he,
   'But our Sages of blessed memory said that they rise in their garments. Those garments, which will be created anew after decay, will certainly endure forever like the bodies. They surpass even the garments in the wilderness, of which the Sages said that they grew with the wearers, and of which it is written, “Your garment did not wear out upon you.” Thus some of one’s possessions also endure forever, as they become clothing for the body. This is through the Torah and its commandments, for many commandments—almost most of them—depend on a person’s money and possessions; through this, eternal life and permanence extend into them too. The body is the garment of the soul, and possessions are the garment of the body. The righteous, whose bodies have already been refined, cherish the garment, namely money: the coarser and more outward the garment, the more effort it needs. This is therefore more precious and beautiful to them, for there the effort is greater, and therefore the longing is greater.',
   'Machshavot Charutz explains why care for possessions need not express materialism: property can bear the lasting effect of the commandments performed with it. The argument concerns possessions sanctified through Torah and mitzvot.')

ref='Kometz HaMinchah 2:57:1'
he=cut_bare(local('kometz-haminchah',ref),'וכן ישראל נמשלו בפרק גיד הנשה','כמו שכתבתי במקום אחר;')
inside(b,199,'kometz-jacobs-small-vessels-and-small-souls',4,'kometz-haminchah',ref,he,
   'Israel is likewise compared, in the chapter “Gid HaNasheh” in Ḥullin, to silver: “Silver—these are Israel.” They said of Jacob that his money was dearer to him than his body, for he remained behind for small vessels. These are the small souls of Israel, as I wrote elsewhere.',
   'The “small vessels” receive a symbolic reading as souls that might otherwise be overlooked. This directly connects Jacob’s care for property with his love of Israel.')

ex(b,199,'eruvin-composure-in-wine-and-the-hidden-secret',7,'Eruvin 65a:19',ext('Eruvin 65a',19),
   'Rabbi Ḥiyya said: One who remains composed in his wine has the understanding of seventy elders. “Wine” has the numerical value seventy, and “secret” has the numerical value seventy. Wine enters; the secret comes out.',
   'The source praises remaining composed while drinking. Rav Tzadok applies its image of the emerging secret to a heart already filled with love of God.')

ref='Mei HaShiloach, Volume I, Leviticus, Vayikra 6'
he=cut_bare(local('mei-hashiloach',ref),'ולענין הזה מתיחס גם ענין אמציה','וחטאו לא היה רק לפי ערך גבול תפיסת אדם;')
inside(b,199,'mei-hashiloach-amaziah-trial-and-punishment',8,'mei-hashiloach',ref,he,
   'To this matter also belongs the case of Amaziah king of Judah. He struck ten thousand of Edom and hurled ten thousand from the top of the rock, so that they were shattered. Afterward he worshipped the gods of Edom and sent to Joash king of Israel: “Come, let us face one another.” The meaning is that Edom is the foremost husk, the most important of all the nations, as stated in Avodah Zarah: Edom enters immediately after Israel because of its importance. Immediately beyond this husk begins the name Israel. At present Israel has not been granted authority over them; that is only for the future, as explained in its place. Amaziah’s killing of the twenty thousand corresponds to the ten levels of the husk, for “God made this opposite that”: twenty thousand alludes to all ten levels from below upward and from above downward. He thought that since his power over them had become so great, whatever he now did would surely not turn his heart from God, nor would any evil have power to prevail over him, as will be in the future. He therefore tried worshipping the gods of Edom and sent Joash, “Come, let us face one another,” meaning: Although I have done something that appears evil, I am still more attached to the blessed God than you. But this was not the blessed God’s will. Therefore he was punished, and Joash king of Israel captured him. Nevertheless, it says there that Amaziah lived fifteen years after Joash’s death, hinting that in all fifteen levels found in Israel, Amaziah was greater than Joash, and his sin was only relative to the limits of human apprehension.',
   'The Ishbitzer explicitly says that Amaziah’s attempted test was not God’s will and that he was punished. His subsequent spiritual interpretation does not remove that statement. Both parts are retained in this direct parallel to what Rav Tzadok heard.',
   anchorEnd='מֵעִנְיַן אֲמַצְיָהוּ')

ref='Mei HaShiloach, Volume I, Talmud, Shabbat 138b:1'
he=cut_bare(local('mei-hashiloach',ref),'"תהום" מורה על הדברים')
inside(b,199,'mei-hashiloach-hezekiah-and-concealed-guidance',8,'mei-hashiloach',ref,he,
   '“The deep” signifies the things a person does in concealment while directing himself to the will of the Holy One, blessed be He, because in the depths of his heart he is attached to Him, even where his intellect and awareness do not reach. This is “By His knowledge the depths were split”: from the depths of the human heart, the Holy One, blessed be He, builds within a person’s heart the fulfillment of His will even in concealment, thereby clarifying that he is wholly attached to Him. This is the meaning of “by His knowledge”—not by human knowledge. Thus we find of Hezekiah king of Judah: “And so with the envoys of the princes of Babylon … God left him, to test him, to know all that was in his heart.” He concealed Himself from him and tested whether he would direct himself to God’s will even in concealment, as it is written, “I will surely hide My face on that day.”',
   'This is the received teaching’s direct parallel for Hezekiah. It explains the trial as the concealment of felt divine guidance, exposing what is present in the depths of the heart.')

ref='Machshavot Charutz 7:10'
he=cut_bare(local('machshavot-charutz',ref),'דאורייתא מסטרא דגבורה','ואחר כך כשהשם יתברך עונהו ועוזר לו, אז הוא במרחב')
inside(b,199,'machshavot-torah-discipline-opens-into-breadth',14,'machshavot-charutz',ref,he,
   'The Torah comes from the side of might, which is the mystery of restraint: one’s conduct is bounded by “Do this and do not do that.” Yet this restraint of Torah is entirely an expansion, for it is the root of Jacob’s inheritance without boundaries. Through this temporary restraint in this world, one grasps the tree of life and merits the abundance of Torah, whose measure is “longer than the earth and broader than the sea.” The restraint applies only to bodily activities and deeds. In apprehension, however—the principal wisdom of Torah, through contemplation in the mind and heart—one may expand without boundaries. “From the narrow place I called to God; He answered me with spaciousness”: the calling is the beginning of entry into Torah, which needs restraint and a narrow passage. Afterward, when the blessed God answers and helps him, he is in spaciousness.',
   'The author explains how the discipline associated with Isaac and gevurah can produce intellectual breadth. The limits on bodily conduct remain in place while understanding opens beyond them.')

ex(b,199,'berakhot-devoting-oneself-to-torah',15,'Berakhot 63b:14',ext('Berakhot 63b',14),
   'Another interpretation of “Be silent and listen, Israel”: crush yourselves over words of Torah. This is as Reish Lakish said: From where do we know that words of Torah endure only in one who makes himself as dead over them? For it is written, “This is the Torah: when a person dies in a tent.”',
   'The Gemara supplies the homiletic reading of the verse cited in the body. Rav Tzadok uses it for wholehearted devotion to Torah under the heading “with all your soul.”')

ex(b,199,'taanit-ravina-requires-gentleness',19,'Taanit 4a:3',
   cut(ext('Taanit 4a',3),'אמר רבינא:'),
   'Ravina said: Even so, a person must train himself to act gently, as it is written, “Remove anger from your heart.”',
   'This qualification follows the Gemara’s description of a scholar whose Torah makes him heated. It adds the requirement of gentleness, complementing the already-present quotation about Torah’s fire and Rav Tzadok’s insistence that compassion remain active.')

# 200: great and enduring love, including the relative truth of recurring prayer-love.
ex(b,200,'zohar-akiva-lesser-and-greater-love',0,'Zohar, Pekudei 51:667',ext('Zohar, Pekudei 51:666-667',2),
   'When he reached that place called the Palace of Love, he attached himself to it with the will of his heart. He said: This palace must be joined to the palace above, in great love. Then he was perfected in the mystery of faith, and he ascended and completed lesser love with greater love, as was fitting. Therefore he died in love, and his soul departed with this verse, “You shall love.” Fortunate is his portion.',
   'In its account of Rabbi Akiva’s ascent, the Zohar describes completing “lesser love” with “greater love.” This supplies the Zohar passage cited in the opening sentence, alongside the already-present discussion of the prayer wording in Berakhot.',
   anchorEnd='(רנד עַמּוּד ב)')

ex(b,200,'tanya-great-delight-as-a-gift',5,'Tanya, Part I; Likkutei Amarim 14:2',ext('Tanya, Part I; Likkutei Amarim 14',2),
   'By contrast, in a matter entrusted to the heart—that evil should truly be repulsive to one’s heart and hated with utter hatred, or even without utter hatred—this cannot be fully true except through the greatness and intensity of love of God, in the form of “love in delights”: delighting in God with a foretaste of the World to Come. Of this our Sages said, “May you see your world in your lifetime.” Not everyone merits this, for it is like receiving a reward, as it is written, “I grant your priesthood as a service of gift,” as explained elsewhere.',
   'Tanya identifies the inward delight that transforms one’s relation to evil as a gift not attained by everyone. Rav Tzadok similarly distinguishes great love from the fear cultivated through deliberate effort.',
   anchorEnd='בְּהִשְׁתַּדְּלוּתוֹ')

ref='Resisei Layla 31:1'
he=cut_bare(local('resisei-layla',ref),'כי אברהם נקרא "תחלה לגרים"','שרק על ידי השתדלותו זוכה;')
inside(b,200,'resisei-abraham-first-in-human-effort',6,'resisei-layla',ref,he,
   'For Abraham is called “the first of the converts”: he is the first of those who exert themselves. Of him it is said, “Walk before Me”—walking signifies effort, the level of “when you walk.” This is called the convert, of whom the Sages said in Kiddushin that first comes “You shall be My people”; he merits only through his own effort.',
   'Resisei Layla names Abraham as the beginning of self-initiated service. Rav Tzadok’s point here is the reversal: this patriarch of effort ultimately receives love as a divine gift.')

ref='Resisei Layla 42:1'
he=cut_bare(local('resisei-layla',ref),'שהיראה שורש למצות לא תעשה','ד"אף על פי שחטא, ישראל הוא" (סנהדרין מד.).')
inside(b,200,'resisei-isaac-born-holy-and-the-work-of-fear',7,'resisei-layla',ref,he,
   'Fear is the root of the prohibitions, the level of Isaac, the mighty one who conquers his inclination. This is the whole root of his effort: to clarify “You shall have no other gods”—every kind of dross and the separation of evil from good, the outer boundary of the world that distinguishes it from what lies beyond. This is possible only for one whose conception and birth are in holiness, and in whose heart the root of “I am the Lord your God” is already fixed and enduring, a peg that cannot move. Nevertheless, afterward he still needs the warning “You shall have no other gods.” Even one who is an Israelite from birth, a believer descended from believers, can have evil prevail within him, God forbid, so strongly that it says to him, “Go, worship,” until it can even sever his root, God forbid—as with Esau, who is called an apostate Israelite in Kiddushin, yet became a nation of his own. All the effort of our father Isaac was directed toward this: to beget Jacob, whose offspring are complete, whose root cannot be severed in any way, for “even though he sinned, he is Israel.”',
   'The parallel explains why inherited holiness does not eliminate Isaac’s task of resisting evil. Its qualification about the continuing need for vigilance, and its distinction between Esau and Jacob, are retained.')

ex(b,200,'zohar-complete-love-in-good-and-hardship',13,'Zohar, Introduction 22:200-201',ext('Zohar, Introduction 22:200-201'),
   'Therefore we learned: love, the love of the Holy One, blessed be He, is distinguished on two sides. There is one who loves Him because he has wealth, length of days, children around him, mastery over his enemies, and success in his ways; because of this he loves Him. If these circumstances were reversed and the Holy One, blessed be He, brought upon him a turn of harsh judgment, he would hate Him and not love Him at all. Therefore this love is not a love with a root. Love called complete is that which exists on both sides, in judgment as in goodness. His ways are set right so that he loves his Master, as we learned, even if He takes your soul from you. This is complete love on both sides. Thus the light of Creation came forth and afterward was hidden. When it was hidden, harsh judgment emerged, and both sides were included together, so that this love would be properly complete.',
   'The Zohar explicitly contrasts love dependent on favorable circumstances with love sustained through both goodness and adversity. This is the passage cited at the introduction to the Zohar, 12a.')

ex(b,200,'eliyahu-david-joy-fear-and-love',14,'Tanna DeBei Eliyahu Rabbah 3:1',
   cut(ext('Tanna DeBei Eliyahu Rabbah 3',1),'עוד אמר דוד המלך ע"ה','ואהבתי עלתה על כלם'),
   'King David, peace be upon him, further said: I feared through my joy, and rejoiced through my fear, and my love rose above them all.',
   'The source places these words in David’s mouth. Rav Tzadok invokes their mutual inclusion of joy and fear to explain the enduring love associated here with Jacob.')

ex(b,200,'berakhot-patriarchs-and-the-three-prayers',15,'Berakhot 26b:5-7',span('Berakhot 26b',5,7),
   'A baraita was taught in support of Rabbi Yosei son of Rabbi Ḥanina, and a baraita was taught in support of Rabbi Yehoshua ben Levi. The baraita supporting Rabbi Yosei son of Rabbi Ḥanina teaches: Abraham instituted the morning prayer, as it is written, “Abraham rose early in the morning to the place where he had stood.” Standing means prayer, as it is written, “Pinehas stood and prayed.” Isaac instituted the afternoon prayer, as it is written, “Isaac went out to meditate in the field toward evening.” Meditation means prayer, as it is written, “A prayer of the poor when he is overwhelmed and pours out his plea before the Lord.” Jacob instituted the evening prayer, as it is written, “He encountered the place and spent the night there.” Encounter means prayer, as it is written, “Do not pray for this people, do not raise a cry or prayer for them, and do not entreat Me.”',
   'This baraita connects each patriarch with a daily prayer. It provides the source for the attribution of evening to Jacob and morning to Abraham in this and the next sentence.',
   anchorEnd='שֶׁתִּיקֵּן תְּפִלַּת עַרְבִית')

ex(b,200,'tanya-recurring-prayer-love-is-true-at-its-level',20,'Tanya, Part I; Likkutei Amarim 13:11-14',span('Tanya, Part I; Likkutei Amarim 13',11,14),
   'This love described in intermediate people during prayer, through the strengthening of the divine soul, is not called “service in truth” at all in comparison with the level of the righteous who serve God in His fullest truth, since it passes and departs after prayer; and it is written, “A truthful lip endures forever, but a lying tongue is only for a moment.” Nevertheless, in relation to the level of intermediate people it is called complete service in their fullest truth, each according to his own level among them. I also apply “A truthful lip endures forever” to their love during prayer, since their divine soul has the power to awaken this love again always, through its strengthening during prayer day after day, with the preparation suited to each soul’s standing and level. For truth is the attribute of Jacob, called “the middle bar that extends from end to end”—from the height of levels to the end of all ranks. Within every level it runs through the middle point, which is that level’s point and quality of truth. Truth is “an inheritance without boundaries,” without an upward limit, to the highest levels. All lower levels are as nothing compared with those above them [as is known to those versed in the hidden wisdom: the head and intellect of lower levels are below the heels and feet of higher ones, as our Sages said, “The feet of the living creatures correspond to them all”].',
   'Tanya distinguishes the enduring truth of a higher spiritual level from the recurring truth of an intermediate person’s prayer. Its explicit affirmation that such prayer is true at that person’s level qualifies the comparison and must accompany it.')

ref='Mei HaShiloach, Volume II, Numbers, Korach 1'
he=cut_bare(local('mei-hashiloach',ref),'וכל זה אינו מבורר בשלימות','שכונתו באמת לשם שמים.')
inside(b,200,'mei-hashiloach-fire-needs-divine-confirmation',21,'mei-hashiloach',ref,he,
   'All this is not yet completely clarified, as we find written: “The Lord was not in the wind … the Lord was not in the earthquake.” Wind corresponds to the will found in a person of good deeds; earthquake is the fear within Torah, corresponding to the righteous person; and fire corresponds to the priest, whose service is in mighty love. Therefore it was first written, “The God who answers by fire—He is God; and all the people answered, ‘The proposal is good.’” They all agreed that the one able to act before the blessed God through service in mighty love is the one God chose. Yet afterward the blessed God showed Elijah the prophet that after all these things a person still needs God to agree and set His seal upon all of them. Thus it says, “After the fire, a still, thin voice”: voice is God’s seal upon wind, the will of one who performs good deeds—when they come from God, they are good; stillness is God’s seal upon earthquake; thinness is God’s seal upon fire. When God seals these things, so that the person does not incline in them toward his own interest, they are completely clarified. For even in such matters, when a person longs for love and fear, he may covet them as he covets worldly things. He needs the blessed God to affirm that his intention is truly for the sake of Heaven.',
   'The Ishbitzer’s teaching explains why spiritual intensity alone still needs examination: even love and fear can become objects of self-interested desire. This is the direct parallel to the closing report “as I heard.”')

# Audit facts and editorial choices stay out of the public notes.
decisions={
196:[
    'Preserved native notes 1280–1288 and the existing Machshavot Charutz 19:4 connection; did not duplicate the Flood passage, Israel-before-Torah teaching, or existing biblical and Talmudic excerpts.',
    'Added the Zohar’s three bound levels, original Boaz enactment and Ishbitzer explanation, the purified inclination with its no-sin qualification, angels versus human delight, soul origin, the Midrash and Ramhal on restorative Torah light, and two distinct authorial explanations of Torah and souls.',
    'The further companion references in the supplied footnotes were read as alternative elaborations; retained the direct, distinct originals above rather than stack redundant treatments of the same claim.'
],
197:[
    'Preserved native notes 1289–1309, including the previously reviewed R. Pinchas donkey, Jacob’s flocks, Zohar rods and Sinai passages, Rav Yosef attribution, and Bekhorot qualification.',
    'Preserved Beit Yaakov, Torah, Lech Lecha 18:3 and Kometz HaMinchah 2:77:1 connected sources; did not duplicate their general account of possessions as extension of the person.',
    'Added seven distinct sources. The Shabbat note explicitly identifies utensil-rest as Beit Shammai’s position; the Kometz note retains the distinction between fighting an inclination and transforming it after victory.'
],
198:[
    'Preserved native notes 1310–1332 and Peri Tzadik, Chanukah 16:4. In particular, retained the existing Tosafot/Tosefta mule dispute including its final objection, and the Rosh Hashanah rejection of judging without witnesses.',
    'Added original explanations of Torah’s reciprocal labor, stationary breastplate letters, tet/tzadi, particularized instruction, compassion and love, tribal designations, the heavenly academy, and Solomon’s consecrated song.',
    'The eight selected sources provide distinct explanatory content; additional cross-references to already-covered basic verses, Aaron’s peacemaking, and ordinary halakhic decision remain represented by the existing notes.'
],
199:[
    'Preserved native notes 1333–1345 and the Peri Tzadik, Rosh Chodesh Kislev 6:2 connection.',
    'Added eight original passages. The Amaziah quotation retains both the explicit punishment for acting against God’s will and the following spiritual interpretation.',
    'The extra Taanit note is only Ravina’s subsequent demand for gentleness, which was absent from the existing quotation; the existing scholar-anger passage is not duplicated.'
],
200:[
    'Preserved native notes 1346–1353 and the existing Kometz HaMinchah 2:23:1 and Sod Yesharim, Rosh HaShanah 36:1 connections.',
    'Added the missing Zohar originals, Tanya’s gift and relative-truth qualifications, the author’s Abraham/Isaac parallels, the original fear-and-joy saying, the patriarchs’ prayer baraita, and the Ishbitzer’s examination of spiritual fire.',
    'Tanna DeBei Eliyahu expressly places the joy-and-fear sentence in David’s mouth. The new note identifies that original speaker without changing the body’s application to Jacob.',
    'Retained all four paragraphs of Tanya 13:11–14 so the lower level’s recurring love is affirmed as true at its own level, including the concluding bracketed comparison.'
]}
b.entries.sort(key=lambda e:(e['section'],e['phraseIndex'],e['heCharOffset']))
b.save(decisions)

