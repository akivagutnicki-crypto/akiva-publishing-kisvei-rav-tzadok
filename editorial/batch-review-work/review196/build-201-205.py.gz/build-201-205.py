from common import *

D=json.loads((HERE/'primary.json').read_text())
def ext(ref,*indices):
    t=D[ref]['he']
    for i in indices:t=t[i-1]
    return bare(t)
def span(ref,a,b):return bare(D[ref]['he'][a-1:b])
def ex(b,s,id,pi,ref,he,en,ctx,**kw):
    b.add(s,id,pi,ref,he,en,ctx,sourceFile='review-work/review196/primary.json',**kw)
def inside(b,s,id,pi,book,ref,he,en,ctx,**kw):
    b.add(s,id,pi,ref,he,en,ctx,book=book,**kw)

pages={
201:{'integratedB':list(range(102,109)),'neimosB':list(range(90,99))},
202:{'integratedB':list(range(108,114)),'neimosB':list(range(98,103))},
203:{'integratedB':list(range(113,121)),'neimosB':list(range(102,109))},
204:{'integratedB':list(range(120,126)),'neimosB':list(range(108,114))},
205:{'integratedB':list(range(125,133)),'neimosB':list(range(113,121))}}
b=Batch(201,pages)

# 201: devotion, inheritance, and the four who entered Pardes.
ex(b,201,'zohar-all-soul-and-all-possessions',1,'Zohar, Terumah 66:670',ext('Zohar, Terumah 66:670'),
   '“And with all your soul”: it could have said “with your soul.” What is “with all your soul”—why this “all”? Rather, it includes nefesh, ruaḥ, and neshamah. This is “with all your soul”: with everything bound to this soul. “And with all your might” is similar: there are several kinds of possessions, all differing from one another, and therefore it says “all.” Love of the Holy One, blessed be He, means handing all of this over to Him, loving Him with each and every one.',
   'The Zohar explicitly includes all three levels of soul and all varieties of possessions. The latter part also supplies the source Rav Tzadok cites a few phrases later.')

ex(b,201,'yerushalmi-heart-and-purse',4,'Jerusalem Talmud Terumot 8:4:14',
   cut(ext('Jerusalem Talmud Terumot 8:4',14),'כל האיברין תלויין בלב','והלב תלוי בכיס.'),
   'All the limbs depend upon the heart, and the heart depends upon the purse.',
   'Rabbi Yoḥanan says this after being robbed, when his distress prevents him from answering Resh Lakish’s questions. Rav Tzadok applies the dependence of the heart upon possessions to the different desires that money can serve.')

ex(b,201,'bava-batra-daughters-wisdom-exegesis-and-righteousness',9,'Bava Batra 119b:9-12',span('Bava Batra 119b',9,12),
   'It was taught: Zelophehad’s daughters were wise, skilled in interpretation, and righteous. They were wise because they spoke at the appropriate moment. Rabbi Shmuel bar Rav Yitzḥak said: This teaches that Moses our teacher was sitting and expounding the passage about levirate marriage, as it says, “When brothers dwell together.” They said to him: If we count as a son, give us an inheritance as a son; if not, let our mother enter levirate marriage! Immediately, “Moses brought their case before the Lord.” They were skilled in interpretation because they said: Had he had a son, we would not have spoken. But was it not taught, “a daughter”? Rabbi Yirmeya said: Remove “a daughter” from here. Abaye said: Even had the son had a daughter, we would not have spoken. They were righteous because they married only men worthy of them. Rabbi Eliezer ben Yaakov taught: Even the youngest of them did not marry before the age of forty.',
   'The existing Niddah note explains the relationship of daughters to their father. This passage is the separate source for their wisdom and interpretive ability, and preserves the Gemara’s third description, their righteousness.',
   anchorEnd='חַכְמָנִיּוֹת, דַּרְשָׁנִיּוֹת')

ex(b,201,'rashi-inheritance-passage-through-the-daughters',9,'Rashi on Numbers 27:5',ext('Rashi on Numbers 27:5'),
   '“Moses brought their case”: The law escaped him; here he was repaid for taking a crown for himself when he said, “The matter that is too difficult for you, bring to me.” Another interpretation: This passage was fit to be written through Moses, but Zelophehad’s daughters merited that it be written through them.',
   'Rashi’s second interpretation supplies the claim that the daughters brought a new Torah passage into revelation. The first interpretation is retained as Rashi’s distinct explanation of why Moses brought the question before God.')

ref='Dover Tzedek, Miscellany 4:140'
inside(b,201,'dover-tzedek-inheriting-the-fathers-powers',10,'dover-tzedek',ref,
   cut_bare(local('dover-tzedek',ref),'והנה עשיר או עני'),
   'Whether a person is rich or poor depends on his mazal—that is, on the receptivity of his mazal and hidden root. How, then, does a poor son inherit a rich father when the father dies, if the son lacks the capacity to receive so much wealth? In truth, the father’s hevel de-garmei, the power of his mazal and hidden root, extends into the son himself, and the son becomes a vessel able to receive it. Therefore, in the chapter “HaPoalim,” concerning Rabbi Elazar son of Rabbi Shimon, they said, “The fruit of the righteous is a tree of life”: every son can attain his father’s level after his death if he wishes. This concerns the level of a righteous person; concerning the level of a Torah scholar, however, they said in Nedarim that scholars do not commonly bequeath it to their sons, for the three kinds of gifts correspond to the three hidden powers mentioned above.',
   'This parallel explains inheritance as a transmission of spiritual capacity. It expressly distinguishes inheriting a righteous father’s level from the different case of scholarly attainment, and conditions attainment on the son’s will.')

ex(b,201,'yevamot-study-and-deed',19,'Yevamot 109b:4-6',
   cut(span('Yevamot 109b',4,6),'תוקע עצמו לדבר הלכה'),
   'One who fixes himself in a matter of halakhah: it was taught that Rabbi Yosei says, “Whoever says that he has no Torah has no Torah.” That is obvious! Rather: “Whoever says that he has only Torah has only Torah.” This too is obvious! Rather, he does not have even Torah. Why? Rav Pappa said: Scripture says, “You shall learn and you shall do”—whoever participates in doing participates in learning; whoever does not participate in doing does not participate in learning. Alternatively, it is as you said at first: whoever says that he has only Torah has only Torah. This is needed where he teaches others and they go and act. One might have thought that he receives their reward; it teaches us otherwise.',
   'The Gemara’s principal reading makes action integral to learning. It also records a second reading, concerning a teacher who does not himself act and cannot claim the reward for his pupils’ actions; both readings are retained.',
   anchorEnd='אַף תּוֹרָה אֵין לוֹ')

ex(b,201,'zohar-pardes-and-the-four-elements',21,'Zohar, Pekudei 51:666-670',span('Zohar, Pekudei 51:663-674',4,8),
   'In this manner we learned: Four entered Pardes, and all were tested at this place, in these four elements. Each became attached to his place: one to the side of fire, one to water, one to air, and one to earth. All sank in their element as they entered, except for that perfect, pious one, who came from the right side, clung to the right, and ascended above. When he reached the place called the Palace of Love, he clung to it with the will of his heart. He said: This palace must be joined to the palace above through great love. Then he became complete in the mystery of faith; he ascended and properly completed lesser love with great love. Therefore he died in love, and his soul departed with the verse “You shall love.” Happy is his portion! All the others descended below, each one, and were punished in the element into which they descended. Elisha descended on the left side, which is fire; he descended into it and did not ascend, encountering the other side called “another god.” Repentance was withheld from him, and he was expelled because he clung to it; therefore he is called Aḥer, as we have explained. Ben Azzai descended into the element of earth; before reaching the burning of earth that extends to the other side, he sank in that earth and died. Of this it is written, “Precious in the eyes of the Lord is the death of His pious ones.” Ben Zoma descended into the element of air and encountered another spirit reaching the side of impurity, called an evil affliction. It therefore struck him, and he did not become settled. None of them escaped punishment. Of this Solomon said, “There is a vanity that occurs upon the earth: there are righteous people to whom it happens according to the deeds of the wicked,” because these descended into these levels and were punished.',
   'The Zohar assigns the three unsuccessful entrants to distinct elements and contrasts them with Rabbi Akiva’s ascent through love. Its account of his later death in love is distinct from his safe departure from Pardes.',
   anchorEnd='דְּהוּא אִדְבַּק בְּעָפָר')

ex(b,201,'tanya-character-traits-and-four-elements',23,'Tanya, Part I; Likkutei Amarim 1:15',ext('Tanya, Part I; Likkutei Amarim 1',15),
   'The explanation is based on what Rabbi Ḥayyim Vital wrote in Shaar HaKedushah, and in Etz Ḥayyim, gate 50, chapter 2: every person of Israel, righteous or wicked, has two souls, as it is written, “Souls I have made.” These are two animating souls. One is from the kelippah and the other side; it clothes itself in a person’s blood to give life to the body, as it is written, “The life of the flesh is in the blood.” From it come all the bad traits, from the four bad elements within it: anger and pride from fire, which rises upward; desire for pleasures from water, for water causes every kind of pleasure to grow; frivolity, mockery, self-glorification, and idle talk from air; and laziness and sadness from earth.',
   'Tanya provides the explicit correspondence between elements and character traits that Rav Tzadok invokes here. It speaks of the negative traits of the animal soul, rather than defining every use of these elements as evil.')

ref='Mei HaShiloach, Volume I, Leviticus, Emor 4'
inside(b,201,'mei-hashiloach-ben-zoma-and-created-beings',26,'mei-hashiloach',ref,local('mei-hashiloach',ref),
   '“In your land you shall not do this”: this means not to mock the creatures of the Holy One, blessed be He. The Gemara in Ḥagigah derives from this that castration is forbidden, and this signifies the prohibition against mockery. As stated there, they asked Ben Zoma: May one castrate a dog? He answered: “In your land you shall not do this”—do not do this to anything in your land. They also asked whether a virgin who became pregnant was permitted to a High Priest: should one be concerned about Shmuel’s case? He answered that Shmuel’s case was uncommon. They asked these questions because they saw that he had not descended in peace—as the Gemara says, he looked and was stricken—and understood that his apprehension was incomplete and that he had erred in something. Their first question tested whether he lightly regarded mocking God’s creatures. They asked about castrating a dog, the lowliest creature, to see whether nullifying its existence seemed trivial to him. He answered that it was forbidden: one must not mock it, for it is a creature of the blessed God. Then they asked whether his error lay in the opposite direction, attributing to created beings more power than they possess. This was the question about a pregnant virgin and the High Priest: the High Priest is the greatest of created beings, and perhaps he had overestimated the power of his existence. He answered that Shmuel’s case was uncommon: one should not ascribe to him greater existence than he possesses, or impose more stringency upon him than is fitting; since Shmuel’s case is uncommon, she is permitted to him. In truth, his principal error was apprehending a great distinction between the lower and upper waters, although only a hair’s breadth—the separating firmament—stands between them. Both are God’s creations, and one must receive them according to His will. This was the meaning of the lamb accompanying the omer, whose meal offering was doubled to two tenths, corresponding to the upper and lower waters, while the lamb alludes to the separating firmament. [Supplement:] As the Gemara says, he stated that only three fingerbreadths separate the lower and upper waters, and they said, “Ben Zoma is still outside.” This means that he apprehended a great separation between evil desire and good desire.',
   'The Ishbitzer reads the questions as tests of Ben Zoma’s attitude toward creation. The complete passage preserves both tests and his actual error; it does not say that his answer about the dog was mistaken.')

# 202: the ordered growth of love, fear, and settled knowledge.
ref='Peri Tzadik, Parshat Parah 7:3'
inside(b,202,'peri-tzadik-abraham-as-beginning-jacob-as-maturity',3,'peri-tzadik',ref,
   cut(local('peri-tzadik',ref),'וזה היה שרש נפש אברהם','כמו בימי הנעורים.'),
   'This was the root of our father Abraham’s soul: the first beginning of holiness, the aspect of loving kindness. As we heard from the holy master, of blessed memory, in his explanation of “There is no understanding among the elders, and no counsel among the children”: the elder is our father Jacob, in whom holiness had already matured and become threefold; “the children” refers to our father Abraham, who was the beginning of holiness, as in the days of youth.',
   'Rav Tzadok records the same teaching elsewhere, explicitly identifying Abraham with the beginning of holiness and Jacob with its mature, threefold development.')

ex(b,202,'tur-three-festivals-and-patriarchs',7,'Tur, Orach Chaim 417',
   cut(ext('Tur, Orach Chaim 417'),'ושמעתי מאחי הר"י','ולמקנהו עשה סוכות'),
   'I heard a reason for this from my brother Rabbi Yehudah: the festivals were established corresponding to the patriarchs. Passover corresponds to Abraham, as it says, “Knead and make cakes,” and it was Passover. Shavuot corresponds to Isaac, for the shofar blast at the giving of the Torah was with the horn of Isaac’s ram. Sukkot corresponds to Jacob, as it says, “For his livestock he made booths.”',
   'The Tur supplies the precise sequence of the three festivals and patriarchs used here. His larger discussion concerns the festivals and Rosh Ḥodesh; this is the complete unit concerning the three pilgrimage festivals.')

ref='Mei HaShiloach, Volume I, Exodus, Bo 6'
inside(b,202,'mei-hashiloach-proverbs-and-the-heart-of-torah',9,'mei-hashiloach',ref,
   cut_bare(local('mei-hashiloach',ref),'והנה משה רבינו'),
   'Moses our teacher embodied the wisdom of all Israel, and all his power lay in this: the mind and thought, with the blessed God always before him. Therefore the Torah speaks chiefly of actual deeds, so that action too should be as purified as thought. For this Moses made the Tabernacle, whose place was in the human form, in the depth of the heart, and which could be dismantled and carried elsewhere. Solomon’s wisdom, however, lay in actions; therefore he built the chosen House in a fixed place. The book of Proverbs that he composed speaks chiefly of the uprightness of the heart and thought, that they should be established as firmly as action.',
   'The Ishbitzer contrasts the Torah’s direction of practical action with Proverbs’ direction of the heart. This is the parallel behind Rav Tzadok’s report that Proverbs unfolds the inner meaning of the commandments.')

ref='Takanat HaShavin 5:6'
inside(b,202,'takanat-fear-first-in-service-love-first-from-above',12,'takanat-hashavin',ref,
   cut_bare(local('takanat-hashavin',ref),'ולכך מצד עבדות ישראל','אברהם הוליד את יצחק״'),
   'Therefore, from the standpoint of Israel’s service, which is an awakening from below, fear comes first. From the standpoint of His attributes, however, love is known to come first, as it says, “Yours, Lord, are greatness and might”—greatness precedes. Likewise with the patriarchs, who are the divine chariot: “Abraham fathered Isaac.”',
   'Rav Tzadok explicitly distinguishes the order of individual service from the order of divine initiative. That distinction explains why this section first presents love before fear and then requires fear before love.')

ex(b,202,'tanya-love-and-fear-as-serving-wings',15,'Tanya, Part I; Likkutei Amarim 40:12-14',span('Tanya, Part I; Likkutei Amarim 40',12,14),
   'Just as a bird’s wings are not its essence, and its life does not depend on them at all—as we learned, “If its wings were removed, it is kosher”—its head and entire body are the principal thing, and its wings only serve the head and body by enabling flight. So, by analogy, Torah and commandments are the essence of the supernal union, through the revelation of the higher will disclosed by them; fear and love raise them to the place where the will, the blessed Infinite Light, and the union are revealed, namely Yetzirah and Beriah. [Gloss:] Or even into the ten holy sefirot of Asiyah, the place of practical commandments, and likewise Scripture. In Mishnah, however, the union and the blessed Infinite Light are revealed in Yetzirah, and in Talmud in Beriah. Through studying Scripture, the union and the Infinite Light extend from Atzilut to Asiyah; through Mishnah, only to Yetzirah; and through Talmud, only to Beriah—for all are in Atzilut. Kabbalah, however, does not extend from Atzilut into Beriah, Yetzirah, and Asiyah at all, as stated in Peri Etz Ḥayyim. Although fear and love themselves are among the 613 commandments, they are nevertheless called “wings,” because the purpose of love is service from love. Love without service is “love in delights,” delighting in God as a foretaste of the World to Come and the receiving of reward; but it is written, “Today, to perform them,” and tomorrow to receive their reward.',
   'Tanya explains why love and fear serve the fuller life of Torah and action as wings serve a bird. The concluding qualification is essential: love and fear are themselves commandments, even while they function as means of ascent.',
   anchorEnd='כִּי אַהֲבָה וְיִרְאָה נִקְרָא "גַּדְפִין" בַּזֹּהַר')

ex(b,202,'zohar-patriarchs-arms-and-body',15,'Zohar, Pinchas 14:97',
   cut(ext('Zohar, Pinchas 14:97'),'אמר ליה, ודאי','גופא, לקבל יעקב.'),
   'He said to him: Certainly, the body and the two arms correspond to the patriarchs. The head corresponds to the first Adam; the right arm to Abraham; the left arm to Isaac; and the body to Jacob.',
   'This passage in Raaya Meheimna supplies the explicit bodily arrangement. Rav Tzadok uses Abraham’s love and Isaac’s fear as the arms serving the whole represented by Jacob.')

ex(b,202,'maimonides-knowledge-as-human-form',16,'Mishneh Torah, Foundations of the Torah 4:8',ext('Mishneh Torah, Foundations of the Torah 4:8-9',1),
   'The soul of every living body is the form that God gave it. The additional knowledge found in the human soul is the form of a human being perfected in knowledge. Concerning this form the Torah says, “Let us make a human in Our image, according to Our likeness”: that he should possess a form that knows and apprehends intelligible things without material substance, like the angels, who are form without matter, so that he resembles them. This does not refer to the form visible to the eyes—the mouth, nose, jaws, and the other bodily features—which is called physical appearance. Nor is it the soul found in every living being, through which it eats, drinks, reproduces, perceives, and thinks. Rather, it is the knowledge that is the form of the soul; concerning the form of the soul Scripture says, “In Our image, according to Our likeness.” This form is often called nefesh or ruaḥ. Therefore one must be careful with these names to avoid error; each term must be understood from its context.',
   'Maimonides supplies the philosophical meaning of human “form” as knowledge, while distinguishing it from bodily shape and from the ordinary life powers of a living creature.',
   anchorEnd='כִּי עִיקַּר צוּרַת הָאָדָם הִיא הַדֵּעָה שְׁלֵימָה')

ref='Machshavot Charutz 14:1'
inside(b,202,'machshavot-jacob-and-the-divine-name',18,'machshavot-charutz',ref,
   cut_bare(local('machshavot-charutz',ref),'כי יעקב אבינו עליו השלום הוא תכלית השלימות','כי הוא חלק ה׳ ודבוק בשם ההוי״ה יתברך שמו כנודע'),
   'Our father Jacob is the ultimate perfection of the human form that the blessed God fashioned in His world. Therefore his form is engraved on the Throne of Glory: it is the “likeness with the appearance of a human” upon the throne, for he is the Lord’s portion and is attached to the name Havayah, blessed be His name, as is known.',
   'This exact parallel links Jacob’s complete human form, its engraving on the throne, and his attachment to the divine name.')

# 203: dreams, prophecy, and the limits of elevating alien thoughts.
ex(b,203,'magen-avraham-idleness-as-sleep',1,'Magen Avraham 583:6',ext('Magen Avraham 583:6'),
   '“And not to sleep”: The Ari said that after midday it is permitted to sleep, for the angel has already been awakened through the prayers and shofar blasts. The Baḥ writes that Maharam slept on Rosh HaShanah. One who sits idly is like one who sleeps.',
   'This comment is about the custom of sleeping on Rosh HaShanah. Its final comparison supplies a precise parallel for Rav Tzadok’s analogy between waking idleness and sleep; its qualifications concerning actual sleep are retained.',
   anchorEnd='יוֹשֵׁב בָּטֵל כְּיָשֵׁן דָּמֵי')

ex(b,203,'berakhot-wicked-alive-called-dead',1,'Berakhot 18b:3',ext('Berakhot 18b',3),
   '“The dead know nothing”: these are the wicked, who are called dead during their lives, as it says, “And you, slain wicked prince of Israel.” Alternatively, it is from here: “By the testimony of two witnesses or three witnesses the dead one shall be put to death.” But he is alive! Rather, he is already called dead.',
   'This is the original aggadic description cited alongside the saying that sleep is one sixtieth of death. The two sayings are distinct sources.')

guide=json.loads((HERE/'guide-2-36-ibn-tibbon.json').read_text())
g=lambda i:bare(guide['he'][i-1])
b.add(203,'guide-dream-and-prophecy-differ-in-degree',7,'Guide for the Perplexed, Part 2 36:2',
   cut(g(2),'וכבר ידעת עוד פעולות','אלא שיש בו קצור ולא הגיע אל תכלית.'),
   'You already know the actions of this imaginative faculty: recalling objects perceived by the senses, combining them, and the imitation natural to it. Its greatest and noblest activity occurs when the senses rest and cease their operations; then a measure of influence flows upon it in accordance with its preparedness. This is the cause of true dreams, and it is itself the cause of prophecy: the difference is one of more or less, not of kind. You know their statement that a dream is one sixtieth of prophecy. A numerical ratio does not apply to things differing in kind: it would be inappropriate to say that human perfection is so many times the perfection of a horse. They repeated this matter in Bereshit Rabbah, saying, “The fallen fruit of prophecy is a dream”—a marvelous comparison. Fallen fruit is the fruit itself, but it fell before attaining perfection and ripening. Likewise, the imaginative faculty’s action during sleep is its action during prophecy, though deficient and not brought to its full extent.',
   'In Ibn Tibbon’s translation, Maimonides explains the shared faculty behind true dreams and prophecy. “One sixtieth” describes a relation in degree; it does not make every ordinary dream a reliable revelation.',
   sourceFile='review-work/review196/guide-2-36-ibn-tibbon.json',
   anchorEnd='חֲלוֹם אֶחָד מִשִּׁשִּׁים בִּנְבוּאָה (בְּרָכוֹת נז:)')

b.add(203,'guide-prophecy-and-prepared-imagination',12,'Guide for the Perplexed, Part 2 36:1',
   cut(g(1),'דע – כי','בתכלית מה שאפשר.'),
   'Know that the truth and essence of prophecy is an influence flowing from God, blessed and exalted, through the Active Intellect, first upon the rational faculty and afterward upon the imaginative faculty. This is the highest of human levels and the ultimate perfection possible for the human species. It is the ultimate perfection of the imaginative faculty. It is in no way possible for every individual, nor is it attained through perfection in theoretical sciences and the improvement of character—even when both reach the highest possible goodness and excellence—unless these are joined by the greatest possible perfection of the imaginative faculty in one’s original constitution.',
   'This is the chapter Rav Tzadok expressly cites. Maimonides makes imagination part of prophetic reception while retaining the requirements of intellectual, moral, and innate imaginative preparedness.',
   sourceFile='review-work/review196/guide-2-36-ibn-tibbon.json',
   anchorEnd='וְכֵן הוּא בְּמוֹרֶה נְבוּכִים')

ex(b,203,'ramban-wisdom-and-prophetic-vision',12,'Chiddushei Ramban on Bava Batra 12a:1',ext('Chiddushei Ramban on Bava Batra 12a',1),
   'Concerning the statement that, from the day the Temple was destroyed, although prophecy was taken from the prophets it was not taken from the sages: Rashi explained that it was taken from prophets who were not sages. One may object that Nedarim says the Holy One rests His Presence only upon one who is wise, strong, and wealthy. Some answer that He rests His Presence without interruption only upon a wise person, unlike a prophet sent on a mission, such as Jonah son of Amittai’s mission to Nineveh; but this does not satisfy me. Rather, the meaning is that although the prophets’ prophecy, which consists of appearance and vision, was taken away, the sages’ prophecy by way of wisdom was not taken away. They know the truth through the holy spirit within them. For a time He may rest His Presence even upon pious people who are not sages, since there they learn the rule from Moses, whose prophecy did not cease; this is the sense of “rests.” Although they also derive wealth from Jonah, he too was a prophet without interruption, and was sent only to Nineveh.',
   'Ramban distinguishes visionary prophecy from the sages’ apprehension through wisdom and holy inspiration. His explanation is more specific than the bare statement that a sage is superior to a prophet.',
   anchorEnd='וְכִדְאִיתָא בְּבָבָא בַּתְרָא (יב.)')

ari=json.loads((HERE/'orhasulam.json').read_text())
a=ari['Likutei Torah, Vayeshev 25']
b.add(203,'ari-dream-as-greatness-within-smallness',19,a['ref'],a['he'],
   'We shall now explain the dreams of Pharaoh, the chief cupbearer, and the chief baker. You know the Sages’ statement that Joseph rejoiced in these dreams because they pointed to him; their entire meaning concerns Joseph’s exile and the redemption from Egypt. Understand this as follows: the mystery of the dream is the three expanded intellectual powers, represented by three names Havayah, whose numerical value equals ḥet-lamed-mem, “dream.” This is when they descend within the three names Elohim in the throat, represented by the three officials. You know that sleep occurs entirely in a state of diminished consciousness. The dream then comes from the expanded consciousness remaining within the diminished consciousness, where it is concealed. Therefore the dream is concealed and is explained only through the interpreter—Joseph, who is the Yesod of Zeir Anpin. All the higher lights gather there.',
   'This is the Ari’s explicit explanation cited here: moḥin de-gadlut remains concealed within moḥin de-katnut. The bodily locations and divine names belong to the passage’s symbolic account of the sefirot.',
   url=a['url'],sourceFile='review-work/review196/orhasulam.json')

ex(b,203,'tanya-limits-on-elevating-distracting-thoughts',25,'Tanya, Part I; Likkutei Amarim 28:1-6',span('Tanya, Part I; Likkutei Amarim 28',1,6),
   'Even if thoughts of desire or other alien thoughts fall upon a person while serving through Torah or attentive prayer, he should pay no attention to them, but immediately turn his attention away from them. Nor should he foolishly engage in elevating the traits within the alien thought. Those teachings were said only of righteous people, whose alien thoughts are not their own but come from others. But someone whose thoughts arise from his own evil, in the left chamber of his heart—how can he raise them above when he himself is bound below? Nevertheless, he should not become dejected and downcast during his service, which requires great joy. On the contrary, he should strengthen himself and add all his energy to the concentration of prayer with greater gladness and joy, considering that the alien thought comes from the kelippah in the left chamber, which struggles in the intermediate person against his divine soul. As is known of those who fight or wrestle, when one grows stronger the other strives with all his strength to prevail as well. Therefore, when the divine soul strengthens itself to pray, the kelippah also rises against it, to confuse it and cast it down with its alien thought. This is contrary to the common error of inferring from the arrival of an alien thought that one’s prayer is worthless, since proper prayer would supposedly exclude such thoughts. That would be true if one soul alone both prayed and produced the alien thoughts. In truth, however, there are two souls struggling in a person’s mind, each wishing to rule and fill the mind alone. Thoughts of Torah and fear of Heaven come from the divine soul, while worldly thoughts come from the animal soul, within which the divine soul is clothed.',
   'The limitation to exceptional righteous people is explicit. The same passage also rejects discouragement and the inference that an unwanted thought proves the prayer worthless; these qualifications are part of the source’s meaning.')

# 204: Torah in the heart, restorative rest, and Moses' clear prophecy.
ref='Peri Tzadik, Vayetzei 3:1'
inside(b,204,'peri-tzadik-eight-thoughts-and-inner-heart',1,'peri-tzadik',ref,
   cut(local('peri-tzadik',ref),'וכדאי\' (באדר"נ פ\' כ)','וביחוד באים לזה ע"י קדושת שבת והוא זכר ליציאת מצרים.'),
   'As stated in Avot de-Rabbi Natan, chapter 20: whoever places words of Torah upon his heart has the various thoughts removed from him. It counts eight kinds of thoughts and concludes with the verse in Psalms: “The precepts of the Lord are upright, gladdening the heart; the commandment of the Lord is clear, enlightening the eyes.” Rescue from these eight thoughts alludes to Torah entering the innermost point of the heart, the aspect of Binah, “the heart, the eighth level.” All eight traits in the heart are purified, from Malkhut, the lower heh and the heart’s exterior, through Binah, the upper heh and its interior. This is alluded to in “gladdening the heart” and “enlightening the eyes.” Concerning contrary thoughts it says, “Do not stray after your heart and after your eyes,” and the Sages interpret the heart as thoughts of heresy and the eyes as thoughts of transgression: the eye sees and the heart desires. When Torah enters the depth of the heart, joy is born in it, and the eyes are illuminated to see His providence in everything: “Raise your eyes on high and see who created these.” Conversely, one who does not place Torah upon his heart receives all eight thoughts; the teaching concludes with “Because you did not serve the Lord your God with joy and a good heart.” The central aim is service in the innermost point of the heart, from which joy arises, redeeming one from all the thoughts that constrict and burden the soul. One reaches this particularly through the holiness of Shabbat, which commemorates the exodus from Egypt.',
   'Rav Tzadok gives a full parallel to the eightfold structure, including the link between Torah, the inner heart, the eyes, and joy. The source interprets the list spiritually rather than merely repeating it.',
   anchorEnd="וְהֵם נֶגֶד ח' מַדְרֵגוֹת מִבִּינָה עַד מַלְכוּת")

ex(b,204,'tanya-heart-thoughts-rise-to-the-mind',1,'Tanya, Part I; Likkutei Amarim 9:1-2',span('Tanya, Part I; Likkutei Amarim 9',1,2),
   'The dwelling place of the animal soul from kelippat nogah in every person of Israel is in the heart, in the left chamber, which is full of blood, as it is written, “The blood is the soul.” Therefore all desires, self-glorification, anger, and the like are in the heart. From the heart they spread throughout the body and also ascend to the brain in the head, to think and reflect upon them and devise ways concerning them—just as the blood originates in the heart, spreads from it to all the limbs, and also ascends to the brain in the head.',
   'Tanya supplies the account of emotion arising in the heart and recruiting thought in the mind. Its description is the historical spiritual physiology used by the passage.')

ref='Machshavot Charutz 18:4'
inside(b,204,'machshavot-rest-for-renewed-service',5,'machshavot-charutz',ref,
   cut_bare(local('machshavot-charutz',ref),'וכן דרשו גם כן שם: ״טוב מאד״'),
   'They likewise expounded “very good” as referring to sleep, because through it one gains strength afterward. This is a descent for the sake of ascent. Only when a person sinks into sleep and fails to awaken in fear of the blessed God and for His service does the evil inclination awaken him to worldly desires, and it may, God forbid, bring him down to the pit. This no longer proceeds from the blessed God, who made him upright and created him. He created sleep only to rest and pause briefly from work and exertion, so that one could serve afterward with greater strength and immediately rise like a lion to the service of one’s Creator.',
   'This parallel preserves the distinction between restorative rest and remaining sunk in inactivity. The goodness of sleep is explained through the renewed service it makes possible.')

ex(b,204,'rashi-interrupting-torah-to-uphold-it',6,'Rashi on Menachot 99b:1:1',ext('Rashi on Menachot 99b:1',1),
   '“Its interruption is its foundation”: for example, interrupting Torah for accompanying the dead or bringing a bride to her wedding. “This is its foundation” means that one receives reward as though sitting, establishing Torah, and studying it. For it says, “Which you broke,” and He did not speak to Moses angrily. We learn that the divine Presence agreed with him when he interrupted Torah and broke the tablets, since he intended it for the good.',
   'Rashi illustrates the Talmudic saying with concrete obligations and Moses’ breaking of the tablets. Rav Tzadok applies its larger principle to necessary rest; the original examples remain visible.')

ref='Mei HaShiloach, Volume I, Genesis, Vayetzei 4'
inside(b,204,'mei-hashiloach-jacob-always-attached',8,'mei-hashiloach',ref,local('mei-hashiloach',ref),
   '“And behold, the Lord was stationed over him”: this verse itself is a blessing. Its explanation is like the holiness of Shabbat, which is fixed and enduring without any sanctification or awakening from Israel, but is holy from the blessed God Himself, unlike festivals, which Israel sanctifies. So is our father Jacob’s holiness like the holiness of Shabbat: holy from the blessed God, requiring no awakening. Therefore it does not say “standing over him,” but “stationed”: “standing” would imply that He is standing over him now and not previously, through Jacob’s own awakening, whereas “stationed” means that He is always attached to him.',
   'The Ishbitzer interprets the wording within Jacob’s dream as constant attachment. This supports Rav Tzadok’s distinction between Jacob’s sleeping consciousness and the lower state of others.')

ex(b,204,'sifrei-moses-this-is-the-word',15,'Sifrei Bamidbar 153:2',
   cut(ext('Sifrei Bamidbar 153',2),'זה הדבר –','ומוסיף עליהם זה הדבר:'),
   '“This is the word”: this teaches that just as Moses prophesied with “Thus says,” so the prophets prophesied with “Thus says”; Moses adds beyond them, “This is the word.”',
   'The Sifrei preserves both parts: Moses also used “Thus says,” but uniquely adds “This is the word.” Rav Tzadok explains the latter as direct clarity rather than an image resembling the matter.')

ref='Peri Tzadik, Matot 2:1'
inside(b,204,'peri-tzadik-prophecy-and-the-receivers-disposition',15,'peri-tzadik',ref,
   cut(local('peri-tzadik',ref),'והיינו שכל הנביאים בעת','כמו שהוא בעצם.'),
   'When all the prophets receive their prophecy, it is not fully explicit, but has a likeness and a relation to the recipient’s disposition. Therefore the prophet has the ability to express the words according to that disposition. As the Sages said, Josiah sent to Huldah because women are compassionate. Moses adds to this by prophesying “This is the word”: he received this very word from the blessed God as it is in itself.',
   'This parallel explains the contrast in the Sifrei through the prophetic recipient’s contribution to expression, and Moses’ distinctive reception of the word itself.')

b.add(204,'guide-moses-and-the-imaginative-faculty',20,'Guide for the Perplexed, Part 2 36:5',
   cut(g(5),'ושמשה עליו השלום'),
   'From the incident involving the spies until the entire generation of the wilderness had died, Moses, peace be upon him, did not receive prophecy as he had previously, because he grew weary of bearing them through their many complaints. This was so even though the imaginative faculty had no part in his prophecy: the intellect flowed upon him without its mediation, as we have mentioned several times, for he did not prophesy in parables like the other prophets. This will be explained, but it is not the subject of the present chapter.',
   'The Guide expressly excludes imaginative mediation from Moses’ prophecy. Rav Tzadok develops his own description of Moses’ unity of Torah, wisdom, and prophetic apprehension; the distinction from other prophets is explicit in this earlier source.',
   sourceFile='review-work/review196/guide-2-36-ibn-tibbon.json')

# 205: the heart and eyes, place, Egypt, and the completion of clarification.
sifrei=cut(ext('Sifrei Bamidbar 115',1),'ד"א ולא תתורו').split("ר' ישמעאל")[0].strip()
ex(b,205,'sifrei-eyes-follow-the-heart',0,'Sifrei Bamidbar 115:1',sifrei,
   'Another interpretation: “Do not stray after your heart” teaches that the eyes follow the heart. Or does the heart follow the eyes? You must ask: Is there not a blind person who commits all the abominations in the world? What, then, does “Do not stray after your heart” teach? That the eyes follow the heart.',
   'The Sifrei discusses the direction from the heart to the eyes, complementing the existing Talmudic source about what sight can awaken in the heart. The two directions are both part of Rav Tzadok’s account.')

ex(b,205,'degel-possessions-and-sparks-of-the-soul',6,'Degel Machaneh Ephraim, Lech Lecha 12',
   cut(ext('Degel Machaneh Ephraim, Lech Lecha',12),'ששמעתי בזה הקדמה מאא"ז','וצריך הוא לתקנם ולהעלותם לשרשם'),
   'I heard this introduction from my grandfather, whose soul rests in Eden, of blessed memory: every righteous person has holy sparks belonging to the root of his soul that he must repair and raise. Even his servants, animals, and utensils all contain holy sparks, and he must repair them and raise them to their root.',
   'The Baal Shem Tov’s grandson records the teaching directly in his name. It explains the spiritual connection between a person and the objects surrounding him.')

ref='Kometz HaMinchah 2:21:1'
inside(b,205,'kometz-place-and-powers-of-the-soul',9,'kometz-haminchah',ref,
   cut_bare(local('kometz-haminchah',ref),'העולם הוא דוגמת הנפש','כידוע "אלהים" מורה דין, שהוא יראה.'),
   'The world corresponds to the soul, as written in Sefer Yetzirah. As the Midrash says, a covenant was apportioned to the different airs: one atmosphere makes wise, another enriches, and so forth. Every atmosphere has a particular power, corresponding to the different powers of the soul. The Land of Israel, “a land that the Lord your God seeks,” alludes to the power in the soul that God seeks, namely fear, as it says, “What does the Lord your God ask of you but to fear?” This is the meaning of “The air of the Land of Israel makes wise,” as it says, “Fear of the Lord is wisdom.” Likewise, “One who lives in the Land of Israel is like one who has a God”: as is known, Elohim signifies judgment, which is fear.',
   'This parallel makes explicit the correspondence between places in the world and powers in the soul. It interprets the wisdom associated with the Land of Israel as recognition and fear of God.',
   anchorEnd='כִּי בְּרִית חָלוּק לַאֲוִירוֹת כְּמוֹ שֶׁכָּתוּב בִּבְרֵאשִׁית רַבָּה (סוֹף פָּרָשָׁה לד)')

ref='Mei HaShiloach, Volume I, Talmud, Berakhot 12b:1'
inside(b,205,'mei-hashiloach-egypt-and-imagined-fear',14,'mei-hashiloach',ref,
   cut_bare(local('mei-hashiloach',ref),'כי ענין הרהור עבודה זרה','נקרא הרהורי עבירה;'),
   'The meaning of a thought of idolatry is that a person’s heart contains fear and submission to emptiness and imagination, something he need not fear. Opposite this stands the exodus from Egypt, as it says, “Who brings you up from the land of Egypt”: that you should always be above all matters of this world. Egypt alludes to worldly matters in their entirety, as we say, “He brought His people Israel out to eternal freedom.” Why, then, should you contain submission and fear toward vanity and imagination? Yet against this a person must guard against heretical thinking, lest he reject submission where it is needed—accepting the yoke of Heaven. Opposite this stands the yoke of the commandments: where it is needed, be like an ox under its yoke. Here too one must guard against thoughts of transgression, so that God’s commandments do not appear a burden, and one does not serve merely from fear but serves from love. This is called a thought of transgression: even if one commits no transgression in deed, thoughts in the heart that prevent love of the Holy One, blessed be He, are called thoughts of transgression.',
   'The Ishbitzer explicitly interprets Egypt through imagined fear. The passage preserves its balancing conditions: freedom from misplaced fear must not become rejection of the divine yoke, and that service should develop into love.',
   anchorEnd='וְשָׁמַעְתִּי דְּמִצְרַיִם רְצוֹנוֹ לוֹמַר דִּמְיוֹן')

a=ari['Likutei Torah, Vayeshev 9']
b.add(205,'ari-egypt-as-the-narrow-throat',14,a['ref'],a['he'],
   'Know that the throat is called the land of Egypt, because it is the narrowest place in the human form. When the three intellectual powers descend and spread below into the body, they spread across its breadth in three lines. Above, at their root in the head, their place is narrower than the body. But when they descend into the throat, it is extremely narrow: how can three intellectual powers gather in a place as narrow as the throat? They are therefore delayed there, and this is the mystery of Egypt. This, however, is only from the aspect of the rear, for the external forces have no hold from within. As I have explained, “God made this corresponding to that,” and the external forces have a hold throughout Zeir Anpin. The kingdom of Egypt corresponds to the throat but draws nourishment from the rear, the back of the throat. In that constriction the three higher intellectual powers extend; therefore Egypt’s wisdom is greater than that of the other nations, since it takes all the intellectual powers in a single constriction and receives an illumination at the furthest limit.',
   'This is the original Ari passage behind Rav Tzadok’s reference. Its throat and bodily form are the symbolic structure of Zeir Anpin; the restriction that the external forces draw only from the rear is retained.',
   url=a['url'],sourceFile='review-work/review196/orhasulam.json')

ex(b,205,'rashi-pharaoh-spoke-at-the-appointed-time',20,'Rashi on Exodus 10:29',ext('Rashi on Exodus 10:29'),
   '“You have spoken correctly”: You have spoken well and at the proper time. It is true that I shall no longer see your face.',
   'Rashi supplies the wording “at the proper time,” which Rav Tzadok develops as the completion of what Moses had to draw out of Egypt.',
   anchorEnd='וְאָמַר לוֹ: "כֵּן דִּבַּרְתָּ" (שָׁם, כט) בִּזְמַנּוֹ')

# Remove only the explicitly marked modern editorial gloss; retain the ancient source text.
mh=D["Mekhilta d'Rabbi Yishmael 15:2:2"]['he'][0]
mh=re.sub(r'<sup class="footnote-marker">.*?</sup><i class="footnote">.*?</i>','',mh,flags=re.S)
ex(b,205,'mekhilta-direct-recognition-at-the-sea',21,'Mekhilta DeRabbi Yishmael, Tractate Shirah 3:10',bare(mh),
   '“This is my God”: Rabbi Eliezer says: From where do you learn that a maidservant at the sea saw what Isaiah and Ezekiel did not see? For it says, “Through the prophets I use likenesses,” and, “The heavens opened, and I saw visions of God.” They compared it to a mortal king entering a province, surrounded by an escort, with warriors at his right and left and his forces before and behind him. Everyone asks, “Which one is the king?” because he is flesh and blood like them. But when the Holy One, blessed be He, revealed Himself at the sea, none needed to ask, “Which is He?” As soon as they saw Him, they recognized Him, and all opened their mouths and said, “This is my God, and I will glorify Him; my father’s God, and I will exalt Him!”',
   'The complete parable explains the exceptional directness of recognition at the sea, which Rav Tzadok contrasts with ordinary imaginative apprehension.',
   anchorEnd='רַק בִּקְרִיעַת יַם סוּף שֶׁרָאֲתָה שִׁפְחָה וְכוּלֵי')
b.entries[-1]['sourceEvidence'][0]['textExtraction']='Only the modern edition’s explicitly marked lexical footnote is excluded; the ancient source text is retained.'

ref='Dover Tzedek, Miscellany 4:55'
inside(b,205,'dover-tzedek-tenth-plague-and-hidden-root',24,'dover-tzedek',ref,
   cut_bare(local('dover-tzedek',ref),'ולכן במכת בכורות','וממילא היו יכולים לצאת גם כן כנזכר לעיל'),
   'Therefore, in the plague of the firstborn, “from Pharaoh’s firstborn” and so forth—firstborn means beginning, and it is the tenth plague, for the plagues correspond to the ten sefirot from below upward, uprooting the beginning of evil—Moses was afraid, and it could not be done through him, but only by “I, the Lord” Himself. “I” signifies the attribute of His kingship, from which the root of evil is drawn. When it is revealed, as in His passing through Egypt, the yoke of His kingship over creatures is revealed and illuminated before all; the root of utter evil is taken from its evil place and sweetened, and all the bodies that served as vessels for that light of the root of evil are nullified. Pharaoh alone remained, as the Sages said, so that he would see further. Had there been a complete revelation, leaving not even Pharaoh, it would also have been a complete revelation for Israel and the final end would have arrived. Not only the firstborn but the entirety of evil would then have had to be removed. But the time had not yet come, because this did not arise through Israel’s own effort; Israel still had to wait until they attained it through their effort. Therefore Pharaoh remained, and all the unfolding of evil apart from the firstborn remained as well. Nevertheless, it was then clarified that “Every firstborn is Mine,” and that Israel’s root clings to the good. The judgment therefore arrived for the exodus from Egypt: their root, for whose clarification the exile had existed, was already clarified, and they could consequently depart.',
   'This fuller parallel connects the firstborn, the tenth plague, and the hidden beginning. It also distinguishes that clarification from the complete future removal of evil; Pharaoh’s remaining and the continuing need for Israel’s effort are essential qualifications.')

ref='Peri Tzadik, Noach 9:3'
inside(b,205,'peri-tzadik-abrahams-tenth-trial',26,'peri-tzadik',ref,
   cut_bare(local('peri-tzadik',ref),'וכן כל הנסיונות','וזכה לבחי\' זקן.'),
   'All the trials correspond to the attributes from below upward, up to the ninth trial, corresponding to Ḥokhmah—the first revelation from creation out of nothing that human apprehension can reach, the first attribute of which there is some grasp. Abraham was then perfected in everything that could be clarified from his own side. Afterward came the trial of the binding of Isaac, corresponding to the supernal Keter, concealed from every thought. This was clarification from the blessed God’s side, clarifying him in everything down to the root, so that he attained the aspect of “elder.”',
   'Rav Tzadok explains why the tenth trial completes the series while distinguishing what Abraham can clarify through his own powers from the divine clarification at the hidden root.')

ex(b,205,'shabbat-death-without-sin-disputed',27,'Shabbat 55b:3-5',span('Shabbat 55b',3,5),
   'An objection was raised: Four died through the serpent’s counsel, and these are they: Benjamin son of Jacob, Amram father of Moses, Jesse father of David, and Chileab son of David. All are known through received tradition except Jesse, whose case is explicit in Scripture: “Absalom appointed Amasa over the army in place of Joab; Amasa was the son of a man named Ithra the Israelite, who had relations with Abigail daughter of Naḥash, sister of Zeruiah, Joab’s mother.” Was she Naḥash’s daughter? Was she not Jesse’s daughter, as it says, “Their sisters were Zeruiah and Abigail”? Rather, she was the daughter of one who died through the serpent’s counsel. Whose teaching is this? If it is the tanna of the account of the ministering angels, there are also Moses and Aaron! Rather, it must be Rabbi Shimon ben Elazar. Learn from this that there is death without sin and suffering without transgression. This is a refutation of Rav Ammi—a refutation.',
   '“There is no death without sin” is Rav Ammi’s statement on Shabbat 55a. The Gemara subsequently disputes it, concluding here that death and suffering can occur without personal sin. Rav Tzadok’s spiritual use of the earlier formulation should be read with that Talmudic disagreement in view.',
   anchorEnd='אֵין מִיתָה בְּלֹא חֵטְא')

ex(b,205,'tanchuma-moses-wisdom-passes-to-joshua',28,'Midrash Tanchuma, Vaetchanan 6:1',
   cut(ext('Tanchuma, Vaetchanan 6',1),'אמר לפניו, רבוני, אם מפני יהושע','ועכשו הרי נפשי נתונה לך.'),
   'Moses said before Him: My Master, if I am to die because of Joshua, I will go and become his pupil. He replied: If you wish to do so, go and do it. Moses rose early and went to Joshua’s doorway. Joshua was sitting and expounding, while Moses stood, bent his stature, and placed his hand upon his mouth. Joshua’s eyes were concealed and he did not see him, so that Moses would be distressed and accept death. Israel went to Moses’ doorway to learn Torah and asked where he was. They were told that he had gone early to Joshua’s doorway. They went and found Joshua sitting and Moses standing. They said to Joshua: What has entered your heart, that Moses our teacher stands while you sit? When Joshua raised his eyes and saw him, he immediately tore his clothing, cried, and wept: My teacher, my teacher, my father, my father, and my master! Israel said to Moses: Teach us Torah. He replied: I have no permission. They said: We will not leave you. A heavenly voice declared: Learn from Joshua; accept sitting and learning from Joshua. Joshua sat at the head, Moses at his right, and Aaron’s sons at his left, and Joshua expounded before Moses. Rabbi Shmuel bar Naḥmani said in Rabbi Yonatan’s name: When Joshua said, “Blessed is He who chooses the righteous,” the traditions of wisdom were taken from Moses and given to Joshua, and Moses did not know what Joshua was expounding. After Israel rose from the gathering, they asked Moses to explain the Torah to them. He said: I do not know what to answer you. Moses stumbled and fell. Then he said: Master of the worlds, until now I sought life; now my soul is given over to You.',
   'The Midrash narrates the transfer of teaching authority and wisdom to Joshua immediately before Moses’ death. This is the narrative source behind the statement that Moses’ fountains of wisdom closed on that day.')

decisions={
201:[
 'Preserved all native and connected material; added the original Terumah and Pekudei passages, Yerushalmi proverb, the daughters’ wisdom passage, Rashi’s two interpretations, inheritance parallel, Yevamot’s two readings, the elemental traits, and the complete Ishbitzer discussion.',
 'Kept the distinction between Rabbi Akiva’s safe departure from Pardes and his later death in love. Preserved the actual conclusion of Mei HaShiloach about Ben Zoma rather than treating the dog answer as his error.',
 'No additions or body changes applied to the appended canonical phrases32–34, which are absent from both supplied editions at the end of201.'
],
202:[
 'Preserved the existing Solomon, festival reading, and connected quotations. Added the precise patriarch/festival mapping, love/fear ordering, Proverbs parallel, and the human-form sources.',
 'The Tanya wings passage includes its gloss and the qualification that love and fear are themselves commandments. The Tur’s festival order is kept distinct from other symbolic mappings.'
],
203:[
 'Preserved existing dream, Zohar, and Gemara quotations. Added the public-domain Ibn Tibbon Guide text rather than the API’s modern default translation.',
 'Verified the Ari’s exact Vayeshev source directly in the Or HaSulam original-text transcription, including the concealed greater consciousness within lesser consciousness.',
 'Tanya28 preserves both the restriction on elevating alien thoughts and the rejection of discouragement or declaring one’s prayer worthless.',
 'The supplied editions’ Yaavetz quotation was read, including the prohibition on endangering life. No new quotation of this source is asserted as independently verified pending an original scan; the body citation is preserved.'
],
204:[
 'Preserved Avot de-Rabbi Natan, Bereshit Rabbah, Menachot, Zohar, and the connected quotations. Added fuller original parallels for the eight thoughts, heart and mind, restorative rest, Jacob’s attachment, and Moses’ clarity.',
 'Retained the distinction between rest that renews service and remaining sunk in inactivity. Rashi’s original examples of pausing Torah for other obligations remain explicit.',
 'Sifrei retains both Moses’ use of Thus says and his additional This is the word. The Guide’s account is identified as its own description alongside Rav Tzadok’s explanation.'
],
205:[
 'Preserved all existing native and connected quotations, including Derashot HaRan. Added original sources for the heart/eyes, soul-linked possessions, place and soul powers, and Egypt’s symbolism.',
 'The complete Ari unit retains the restriction to the rear aspect; the Ishbitzer parallel retains submission to the divine yoke and the goal of love.',
 'Included the original Rashi timing phrase and the Mekhilta’s complete recognition parable; only its explicitly marked modern lexical footnote is excluded.',
 'Dover Tzedek retains Pharaoh’s remaining and the incomplete removal of evil. Peri Tzadik retains the distinction between personal and divine clarification.',
 'The no-death-without-sin statement is accompanied by the Gemara’s explicit refutation, and Tanchuma is quoted through Moses’ acceptance after the transfer of wisdom.'
]}
observations=[
 {'section':201,'kind':'canonical-body-discrepancy-not-applied','rowN':1,'phraseIndices':[32,33,34],
  'detail':'Canonical201 appends Proverbs18:16, gifts to the poor, and head-tefillin after the completed Pardes discussion. Both supplied editions end201 with Rabbi Akiva’s safe departure (NeimosB97; integratedB108 boundary). Body and existing notes preserved; no new markers applied to the appended material.'},
 {'section':203,'kind':'original-source-retrieval-limit','detail':'Siddur Yaavetz nighttime conduct4:12 is quoted in both supplied editions. The life-preservation qualification has been read there, but an original edition scan has not yet been independently retrieved; no new source quotation for it is included.'}
]
b.entries.sort(key=lambda e:(e['section'],e['phraseIndex'],e['heCharOffset']))
if __name__=='__main__':b.save(decisions,observations)
