// Reproduce the production add-only workflow against a complete local candidate.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const work=path.dirname(fileURLToPath(import.meta.url));
const repo=path.resolve(work,'../akiva-repo');
const {loadPack,applyPublication,fileInfo,verifyBatchChain}=await import(path.join(repo,'scripts/publish-tzidkat-batch-review.mjs'));
const [rootArg,packArg]=process.argv.slice(2);
assert(rootArg&&packArg,'Usage: apply-local-batch.mjs SITE_DIRECTORY PACK_PATH');
const root=path.resolve(rootArg),prepared=loadPack(path.resolve(packArg));
function inventory(dir,prefix='',out={}){
  for(const e of fs.readdirSync(dir,{withFileTypes:true})){
    assert(!e.isSymbolicLink(),'Unexpected link');
    const p=path.join(dir,e.name),name=prefix+e.name;
    if(e.isDirectory())inventory(p,name+'/',out);else out[name]=fileInfo(p);
  }
  return out;
}
const report=applyPublication(root,prepared,{files:inventory(root),publication:{localReproduction:true}});
const checked=verifyBatchChain({directory:root,verifyAllBaseline:true});
console.log(JSON.stringify({release:report.release,notes:report.newNotes,changes:report.changedFiles.length,proof:checked.proof},null,2));
