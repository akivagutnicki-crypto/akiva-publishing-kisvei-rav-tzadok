from common import *

pages={
191:{'neimosB':list(range(48,53)),'integratedB':list(range(59,64))},
192:{'neimosB':list(range(52,56)),'integratedB':list(range(64,67))},
193:{'neimosB':list(range(54,59)),'integratedB':list(range(66,70))},
194:{'neimosB':list(range(58,62)),'integratedB':list(range(70,73))},
195:{'neimosB':list(range(61,65)),'integratedB':list(range(72,76))},
}
b=Batch(191,pages)
def src(file,ref,*inds):return cached(HERE/file,ref,*inds)
def external(s,id,pi,ref,he,en,ctx,file,**kw):
 b.add(s,id,pi,ref,he,en,ctx,sourceFile='review-work/review-136-150/'+file,**kw)

# 191: the distinction between a boor and an unlearned person, and the missing verses.
b.add(191,'machshavot-recognizing-the-giver-of-bread',4,'Machshavot Charutz 9:14',
 cut_bare(local('machshavot-charutz','Machshavot Charutz 9:14'),'ועד ״נתן לחם','היינו לנהוג מנהג דרך ארץ'),
 'Up to “He gives bread to all flesh” is the completion of the proper worldly conduct that preceded Torah: one recognizes the Giver. This is the blessing that comes first, through which “He gave the earth to human beings,” as explained at the beginning of the chapter How Do We Bless—that is, to engage in proper worldly conduct.',
 'In explaining the concluding verses of Psalm 136, Rav Tzadok identifies the completion of derekh eretz with recognizing who provides one’s food. This supplies his fuller explanation of the connection between blessing, ordinary worldly activity, and recognition of God.',book='machshavot-charutz')
external(191,'rabbeinu-yonah-the-boor-and-the-unlearned-person',5,'Rabbeinu Yonah on Pirkei Avot 2:5:1',
 cut(src('primary-191a.json','Rabbeinu Yonah on Pirkei Avot 2:5',1),'הוא היה אומר','ולעשות ולקיים במה שאומר לו שנצטוה.'),
 'He used to say: A boor does not fear sin, and an unlearned person is not pious. A boor is empty: he has neither Torah nor commandments nor proper conduct expressed in good character. In the Targum, “Let it not become desolate” is rendered “Let it not lie fallow.” It was unnecessary to say that a boor is not pious, since he does not even fear sin: because of his emptiness, he does not know how to guard against transgressions. But an unlearned person participates in society with worthy qualities and has some sound views. He knows how to take care, guards himself against wrongdoing, and can be righteous, doing and fulfilling what he is told he has been commanded.',
 'Rabbeinu Yonah distinguishes the person lacking both learning and cultivated conduct from the unlearned person who has worthy character and can obey the commandments. His explanation supplies the fallow-field image behind Rav Tzadok’s use of the word bor.','primary-191a.json',anchorEnd='הַיְינוּ כְּמוֹ שָׂדֶה בּוּרָה,')
external(191,'exodus-the-distinction-in-the-cattle-plague',8,'Exodus 9:4',src('primary-191a.json','Exodus 9:4'),
 'The Lord will distinguish between Israel’s livestock and Egypt’s livestock, and nothing belonging to the children of Israel will die.',
 'The verb vehiflah explicitly describes a distinction in the livestock plague. Rav Tzadok compares this wording with the already quoted verse about the swarms and with the differently worded account of the hail.','primary-191a.json',anchorEnd='(שָׁם ט, ד),')
external(191,'exodus-no-hail-in-goshen',8,'Exodus 9:26',src('primary-191a.json','Exodus 9:26'),
 'Only in the land of Goshen, where the children of Israel were, was there no hail.',
 'The verse states the exception for Goshen without using the verb “distinguish.” This is the textual difference on which Rav Tzadok’s comparison of the plagues depends.','primary-191a.json')
external(191,'shabbat-the-affliction-of-the-daughters-of-zion',15,'Shabbat 62b:21',src('primary-191a.json','Shabbat 62b',21),
 '“The Lord will afflict the scalp of the daughters of Zion.” Rabbi Yose son of Rabbi Ḥanina said: This teaches that tzaraat broke out upon them. Here it is written vesippaḥ, “He will afflict,” and there it is written, “For a swelling or a scab.”',
 'The discussion concerns the ostentatious behavior described in Isaiah 3 and interprets Isaiah 3:17 through the vocabulary of skin afflictions in Leviticus 14:56. This is the passage behind the brief allusion here; the statement is attributed in the Talmud to Rabbi Yose son of Rabbi Ḥanina.','primary-191a.json')

# 192: the immersion discussion, its distinctions, and the explicit removal of the restriction.
external(192,'midrash-tehillim-israels-longing-for-god',1,'Midrash Tehillim 92:8',
 cut(src('primary-191c.json','Midrash Tehillim 92',8),'דבר אחר מה התמרה הזו יש לה תאוה','מיד עשתה פירות. כך תאותן של ישראל להקב"ה.'),
 'Another interpretation: Just as this date palm has a longing, so Israel’s longing is for the Holy One, blessed be He. Our Rabbis said: There was a date palm in Ḥamtan that they would pollinate, yet it bore no fruit. A palm grower said to them: This palm sees a palm from Jericho and longs for it. They went and brought from that palm; immediately it bore fruit. So is Israel’s longing for the Holy One, blessed be He.',
 'The Midrash uses the date palm and a story of its longing as a parable for Israel’s desire for God. Rav Tzadok draws on this image when explaining how immersion can redirect desire toward divine love.','primary-191c.json')
external(192,'berakhot-immersion-as-a-restraint',4,'Berakhot 22a:20',src('primary-191b.json','Berakhot 22a',20),
 'Rabbi Ḥanina said: They established a great fence through it. For it was taught: A man once solicited a woman for a transgression. She said to him: Empty fellow! Do you have forty seah in which to immerse? He immediately withdrew.',
 'The story explains how the immersion requirement could restrain a person before acting on desire. Rav Tzadok then interprets that restraint as bringing desire into agreement with the fear of God. The later annulment discussed in the same chapter is quoted separately below.','primary-191b.json',anchorEnd='רֵיקָה וְכוּלֵי,')
external(192,'eruvin-water-covering-the-whole-body',7,'Eruvin 4b:6',
 cut(src('primary-191c.json','Eruvin 4b',6),'״כל בשרו״'),
 '“All his flesh”: water in which his whole body can be immersed. How much is that? A cubit by a cubit, with a height of three cubits. The Sages measured the water of a ritual bath as forty seah.',
 'The Talmud connects forty seah with water sufficient for immersion of the entire body. Rav Tzadok interprets that bodily completeness as corresponding to desire that has stirred the whole body into action.','primary-191c.json',anchorEnd='שֶׁכָּל גּוּפוֹ עוֹלֶה,')
external(192,'berakhot-ravas-four-cases',10,'Berakhot 22b:5',src('primary-191b.json','Berakhot 22b',5),
 'Rava said: The rule is that a healthy person who brings about the emission and an ill person who brings it about require forty seah. A healthy person whose emission occurs involuntarily requires nine kav. But an ill person whose emission occurs involuntarily is exempt from everything.',
 'Rava distinguishes intentional from involuntary emission and health from illness. Rav Tzadok interprets these categories spiritually; the qualification exempting the ill person in the involuntary case is part of the Talmud’s actual wording.','primary-191b.json')
external(192,'rashi-the-scholars-compared-to-the-ill',10,'Rashi on Berakhot 22a:19:3',src('primary-191f.json','Rashi on Berakhot 22a:19',3),
 '“It is possible by pouring”: nine kav. Although below this was taught only concerning an ill person, Torah scholars are generally considered ill, as stated in tractate Nedarim: According to whom do we pray for ketzirei and meri’ei? According to Rabbi Yose. Ketzirei are the ill; meri’ei are the Rabbis.',
 'Rashi supplies the comparison between Torah scholars and the ill that Rav Tzadok invokes. His comment concerns the immersion discussion’s treatment of scholars whose strength has been diminished by study. It explains the textual basis for the comparison without turning every distinction here into an independent practical ruling.','primary-191f.json',anchorEnd='בֵּין תַּלְמִיד חָכָם לְעַם הָאָרֶץ,')
external(192,'berakhot-torah-does-not-contract-impurity',11,'Berakhot 22a:8',src('primary-191b.json','Berakhot 22a',8),
 'It was taught: Rabbi Yehuda ben Beteira used to say that words of Torah do not contract impurity. A student was once reciting hesitantly before Rabbi Yehuda ben Beteira. He said to him: My son, open your mouth and let your words shine, for words of Torah do not contract impurity, as it says, “Is not My word like fire, declares the Lord?” Just as fire does not contract impurity, so words of Torah do not contract impurity.',
 'Later on the same page, the Talmud explains the annulment of the immersion requirement by reference to Rabbi Yehuda ben Beteira. His teaching and the encouragement to the hesitant student make clear why Torah study itself remains available. Rav Tzadok then gives the fire image its spiritual interpretation.','primary-191b.json',anchorEnd='(יִרְמְיָה כג, כט),')
external(192,'rambam-purification-in-the-waters-of-knowledge',12,'Mishneh Torah, Immersion Pools 11:12',
 cut(src('primary-191b.json','Mishneh Torah, Immersion Pools 11:12'),'ואף על פי כן רמז','במי הדעת טהור.'),
 'Nevertheless, there is an allusion in this matter: Just as one who directs his heart toward purification becomes pure once he immerses, although nothing has changed in his body, so one who directs his heart toward purifying his soul from the impurities of the soul—wrongful thoughts and harmful views—becomes pure once he resolves in his heart to separate from those counsels and brings his soul into the waters of knowledge.',
 'Rambam first states that ritual impurity and immersion are scriptural decrees: impurity is not physical dirt washed away by water. He then offers this analogy of inward purification through knowledge. The distinction illuminates Rav Tzadok’s comparison of Torah study with immersion.','primary-191b.json')

# 193: inner desire and speech, David and Uzziah, and participating in communal study.
b.add(193,'tzidkat-229-the-voices-at-sinai',1,'Tzidkat HaTzadik 229:1',
 cut_bare(local('tzidkat-hatzadik','Tzidkat HaTzadik 229:1'),'ושמעתי דקולות','שעל זה הוא כל מתן תורה.'),
 'I heard that the voices at the giving of Torah came from the mouths of the children of Israel, for there is no voice in the world except through the five organs of speech. It says, “My soul went out when He spoke”: they then united all the parts of their souls with God. From each power of the soul came a cry particular to that power, recognizing the truth of God and uniting with Him; this is the purpose of the entire giving of Torah.',
 'Rav Tzadok repeats the teaching later and explains its inward meaning: each power of the soul responds to revelation with its own voice. This is his fuller account of the teaching reported briefly here.',book='tzidkat-hatzadik')
b.add(193,'tzidkat-38-private-thought-and-public-expression',6,'Tzidkat HaTzadik 38:1',
 cut_bare(local('tzidkat-hatzadik','Tzidkat HaTzadik 38:1'),'ורצונו לומר:'),
 'The meaning is this: Even matters that are clear in thought should be held in doubt when they come to expression through the tongue, which brings into actuality what is latent in the heart, for a person is liable to error. Therefore all the outward manifestations of one’s actions must be matters clear to everyone, rather than what is clear only to oneself in thought. In one’s thoughts, however, one may consider even matters clear only to oneself. Concerning such a case: The heart does not disclose it to the mouth.',
 'This earlier passage explains the caution required when private understanding becomes outward speech or action. It concerns ideas that a person finds clear inwardly, while acknowledging human susceptibility to error; it helps delimit the freedom of inward thought described here.',book='tzidkat-hatzadik')
external(193,'numbers-the-priestly-boundary-at-the-altar',7,'Numbers 18:7',src('primary-191d.json','Numbers 18:7'),
 'You and your sons with you shall guard your priesthood in every matter of the altar and within the curtain, and you shall serve. I give your priesthood to you as a service of gift; the outsider who approaches shall be put to death.',
 'Numbers 18:7 applies the warning about an outsider specifically to priestly service at the altar and within the curtain. The verse already quoted in the reader, Numbers 1:51, concerns the Levites’ responsibility for dismantling and erecting the Tabernacle. This additional verse supplies the priestly setting relevant to David’s desire.','primary-191d.json')
external(193,'yalkut-david-ate-the-showbread-to-save-life',8,'Yalkut Shimoni on Nach 130:1',
 cut(src('primary-191e.json','Yalkut Shimoni on Nach 130',1),'כיון שלא מצא שם כי אם לחם הפנים'),
 'Since he found there only the showbread, David said to him: Give it to me so that we do not die of hunger, for even a possible danger to life overrides Shabbat. How much did David eat at that time? Rav Huna said: David ate nearly seven seah because of his hunger, for he had been seized by ravenous hunger.',
 'The Midrash explicitly presents David’s eating as a response to danger to life, describing an acute attack of hunger. This is the essential qualification in Rav Tzadok’s statement: the eating fulfilled his longing within the law governing the preservation of life.','primary-191e.json')
external(193,'chronicles-uzziah-crosses-the-priestly-boundary',9,'II Chronicles 26:16-19',src('primary-191c.json','II Chronicles 26:16-19'),
 'When he became strong, his heart grew proud to the point of corruption. He trespassed against the Lord his God and entered the Temple of the Lord to burn incense on the incense altar. Azariah the priest entered after him, with eighty valiant priests of the Lord. They confronted King Uzziah and said to him: It is not for you, Uzziah, to burn incense to the Lord, but for the priests, the sons of Aaron who have been consecrated to burn incense. Leave the sanctuary, for you have trespassed, and this will bring you no honor from the Lord God. Uzziah became angry, holding a censer to burn incense; while he raged against the priests, tzaraat broke out on his forehead before the priests in the house of the Lord, beside the incense altar.',
 'Chronicles explicitly describes Uzziah’s action as trespass and records the priests’ warning before the affliction appears. Rav Tzadok contrasts an inward longing for sacred service with an unauthorized outward act, and interprets Uzziah’s episode in relation to David.','primary-191c.json',anchorEnd='עֻזִיָּה שֶׁבִּקֵּשׁ לְהַקְטִיר,')
b.add(193,'tzidkat-258-jotham-and-a-little-folly',10,'Tzidkat HaTzadik 258:1',
 cut_bare(local('tzidkat-hatzadik','Tzidkat HaTzadik 258:1'),'ואמרו (בברכות לד.)','כמיעוט היותר אפשרי.'),
 'They said: “Leaven in excess is harmful, but a little is beneficial.” Likewise, I heard concerning Jotham, of whom it says, “Only he did not enter the Temple of the Lord,” that this was said as a deficiency in him: he had no deficiency at all. In truth it says, “A little folly is more precious than wisdom and honor,” for everyone must have at least a little folly, and this is completeness. Yet it is good for a person that this folly be as small as possible.',
 'This later passage supplies the explanation postponed here. Rav Tzadok reads Jotham’s absence of deficiency as itself lacking something human; he immediately limits the “little folly” to the smallest possible measure. This is his homiletical reading, alongside the plain biblical account already quoted in the reader.',book='tzidkat-hatzadik')
external(193,'berakhot-thinking-about-the-communitys-subject',13,'Berakhot 20b:21-22',
 src('primary-191c.json','Berakhot 20b',21)+' '+src('primary-191c.json','Berakhot 20b',22),
 'But if thought is not like speech, why does he think the words? Rabbi Elazar said: So that everyone should not be occupied with them while he sits idle. Then let him study another chapter! Rav Adda bar Ahava said: He should think about the matter with which the congregation is occupied.',
 'The exchange explains silent participation according to the view that thought does not itself count as speech for fulfilling the obligation. It still requires engagement with the congregation’s subject. Rav Tzadok develops that shared attention into a connection between the individual’s thoughts and the congregation’s Torah.','primary-191c.json',anchorEnd='בְּדָבָר שֶׁהַצִּבּוּר עֲסוּקִין,')

# 194: voiced response, standing before God, and exertion in Torah and mitzvot.
external(194,'rashi-answering-in-a-raised-voice',2,'Rashi on Deuteronomy 26:5:1',src('primary-191d.json','Rashi on Deuteronomy 26:5:1'),
 '“You shall answer”: in a raised voice.',
 'Rashi explains the verb aniyah in the declaration over first fruits as speaking aloud. This supplies a direct example for Rav Tzadok’s distinction between answering aloud and the quiet amirah described in the existing Zohar note.','primary-191d.json',anchorEnd='בְּקוֹל,')
external(194,'rambam-prayer-as-standing-before-the-divine-presence',4,'Mishneh Torah, Prayer and the Priestly Blessing 4:16',src('primary-191d.json','Mishneh Torah, Prayer and the Priestly Blessing 4:16'),
 'What is concentration? One should clear one’s heart of all thoughts and see oneself as though standing before the Divine Presence. Therefore one must sit a little before prayer to direct the heart, and afterward pray calmly and pleadingly. One should not make prayer like someone carrying a burden, throwing it down, and going away. Therefore one must sit a little after prayer and then depart. The early pious ones would wait an hour before prayer and an hour after prayer, and extend their prayer for an hour.',
 'Rambam explains the inward preparation appropriate to standing before God, together with its expression in calm, pleading prayer. This develops the distinction that Rav Tzadok makes between the first cry of fear and the quieter prayer that follows.','primary-191d.json')
external(194,'taz-the-aris-teaching-on-effort-in-making-matzah',11,'Turei Zahav on Shulchan Arukh, Orach Chayim 460:2',
 cut(src('primary-191f.json','Turei Zahav on Shulchan Arukh, Orach Chayim 460:2'),"בס' כוונות"),
 'In the book of the Ari’s intentions it is written that a person should exert himself over the matzah of the commandment until he becomes warm and sweats; through this he breaks the husks that were produced by semen emitted in vain.',
 'Turei Zahav records this teaching in the Ari’s name specifically about the effort involved in preparing the matzah used for the commandment. Rav Tzadok relates that particular example to his broader account of exertion in mitzvot and returns to matzah below.','primary-191f.json')
external(194,'shaar-hamitzvot-effort-to-resolve-torah-difficulties',14,"Sha'ar HaMitzvot, Vaetchanan 8",src('primary-191f.json',"Sha'ar HaMitzvot, Vaetchanan",8),
 'Regarding the study of halakhah in depth with companions: I saw my master, of blessed memory, exert himself with the strength of a lion while studying halakhah, until he was weary and perspired greatly. I asked him why he exerted himself so much. He answered me that in-depth study serves to break the husks, which are the difficulties in that halakhah that prevent a person from understanding it. A person therefore must exert himself and expend his strength then. For this reason Torah is called tushiyah: it weakens the strength of the one who studies it. Therefore it is fitting to exert oneself and expend one’s strength while engaged in Torah.',
 'Rabbi Ḥayyim Vital describes the Ari’s exertion while learning with companions and records his explanation of intellectual difficulties as husks to be broken. This is a concrete parallel to Rav Tzadok’s account of bodily effort in sacred work.','primary-191f.json')
b.add(194,'yisrael-kedoshim-the-purpose-of-mitzvot-is-holiness',17,'Yisrael Kedoshim 1:2',
 cut_bare(local('yisrael-kedoshim','Yisrael Kedoshim 1:2'),'כל המצות','להיות על ידם קדושים'),
 'All the commandments bring holiness into the heart of a Jew, as it says: “So that you remember and perform all My commandments, and be holy to your God.” Likewise we say, “Sanctify us through Your commandments,” and bless over them, “Who has sanctified us through His commandments and commanded us.” It appears that this is the intended purpose of all the commandments: to become holy through them.',
 'Rav Tzadok opens Yisrael Kedoshim by explaining the sanctifying effect of mitzvot through the same wording of the blessing cited here. This supplies his general statement behind the particular holiness he associates with matzah.',book='yisrael-kedoshim')

# 195: the universal inheritance of Torah and fear, and Torah during the time of Shema.
b.add(195,'peri-tzadik-kingship-awakens-fear',0,'Peri Tzadik, Vayetzei 3:1',
 cut_bare(local('peri-tzadik','Peri Tzadik, Vayetzei 3:1'),"כי ה' תתאה","היראה והבושה כו'."),
 'The lower heh represents the revelation of the kingship of Heaven in the souls of Israel, and from this fear shines into their souls, as it says, “If I am a master, where is the fear of Me?” As stated at the beginning of Oraḥ Ḥayyim: When a person takes to heart that the King of kings stands over him, fear and shame immediately come upon him.',
 'Peri Tzadik explains how the attribute of divine kingship awakens fear within Israel. The lower heh refers to the final letter of the divine name, associated here with that revealed kingship.',book='peri-tzadik',anchorEnd='כַּנּוֹדָע,')
external(195,'avot-the-boor-and-the-unlearned-person',1,'Pirkei Avot 2:5',
 cut(src('primary-191e.json','Pirkei Avot 2:5'),'הוא היה אומר','ולא עם הארץ חסיד,'),
 'He used to say: A boor does not fear sin, and an unlearned person is not pious.',
 'The Mishnah uses different descriptions: the boor lacks fear of sin, while the unlearned person is denied the higher description of piety. Rav Tzadok builds on that distinction to explain how an unlearned person can nevertheless possess fear of Heaven.','primary-191e.json',anchorEnd='אֵין יְרֵא חֵטְא,')
external(195,'vayikra-rabbah-torah-is-the-whole-communitys-inheritance',4,'Vayikra Rabbah 9:3',
 cut(src('primary-191e.json','Vayikra Rabbah 9:3'),'קם תפסיה','כל הדא דרך ארץ גבך וקריתך כלבא,'),
 'He rose, seized him, and said: My inheritance is with you, and you are withholding it from me! He said: What inheritance of yours is with me? He answered: Once I passed a school and heard the children saying, “Moses commanded us Torah, an inheritance of the congregation of Jacob.” It does not say “the congregation of Yanai,” but “the congregation of Jacob.” Rabbi Yanai said to him: What merit enabled you to eat at my table? He answered: In all my days I have never heard an evil report and repeated it to the person concerned; and whenever I saw two people quarreling, I made peace between them. Rabbi Yanai said: You possess all this proper conduct, and I called you a dog!',
 'Rabbi Yanai had welcomed a guest, found him lacking in Torah learning, and insulted him. The guest’s reply establishes Torah as the inheritance of the entire congregation, and his conduct leads Rabbi Yanai to acknowledge his error. The Midrash joins precisely the two themes discussed here: unlearned people’s share in Torah and the worth of derekh eretz.','primary-191e.json')
external(195,'avot-wisdom-and-fear-require-each-other',5,'Pirkei Avot 3:17',
 cut(src('primary-191d.json','Pirkei Avot 3:17'),'רבי אלעזר בן עזריה אומר','אם אין יראה, אין חכמה.'),
 'Rabbi Elazar ben Azariah says: If there is no Torah, there is no proper worldly conduct; if there is no proper worldly conduct, there is no Torah. If there is no wisdom, there is no fear; if there is no fear, there is no wisdom.',
 'The Mishnah states the relationship in both directions. Rav Tzadok uses this reciprocity to explain why fear presupposes some share in Torah, even where that share is concealed, and why Torah learning includes fear.','primary-191d.json')
external(195,'berakhot-rebbis-teaching-about-the-exodus',13,'Berakhot 13b:19-20',
 src('primary-191e.json','Berakhot 13b',19)+' '+src('primary-191e.json','Berakhot 13b',20),
 'Does he return and complete it, or does he not return and complete it? Bar Kappara says: He does not return and complete it. Rabbi Shimon son of Rabbi says: He returns and completes it. Bar Kappara said to Rabbi Shimon son of Rabbi: According to me, who say that he does not return and complete it, this explains why Rabbi seeks a teaching that contains the Exodus from Egypt. But according to you, who say that he returns and completes it, why must he seek such a teaching? So that he mentions the Exodus from Egypt at its proper time.',
 'This follows the account of Rabbi Yehuda HaNasi reciting the first verse of Shema while teaching. Both opinions recognize his effort to teach about the Exodus; they differ over whether he later completes the rest of Shema. Rav Tzadok uses this practice as an analogy for Torah study that includes the content of the service otherwise expressed through prayer.','primary-191e.json')

b.save({
191:'Both editions read in full. Preserved the existing honoring-parents, field, swarms, beast, Daniel, and Machshavot Charutz quotations. Added the precise distinction between bor and am haaretz, the recognition-of-the-Giver parallel, both missing plague verses, and the Shabbat source for the Isaiah allusion.',
192:'Both editions read in full, including the continuation of the Rambam note. Preserved all existing awe, morning-prayer, fire, and streams quotations. Added seven direct sources, retaining Rava’s involuntary-illness exemption, Rashi’s specific scholarly comparison, the annulment context of Rabbi Yehuda ben Beteira, and Rambam’s distinction between ritual purification and physical washing.',
193:'Both editions read in full. Preserved the complete Tosafot, prophecy, Aaron-and-Levi, biblical, and Tanya notes. Added the two internal explanations of Sinai and cautious expression, the priestly restriction, the life-saving qualification for David, Uzziah’s transgression, the fuller Jotham interpretation, and the communal-thought passage with its argumentative premise.',
194:'Both editions read in full. Preserved the fourfold-awe, quiet-speech, prayer, River of Fire, Gehenna, matzah, and evil-inclination quotations. Added five sources concerning voiced response, prayerful concentration, the Ari’s teaching as explicitly recorded in Turei Zahav, Rabbi Chayyim Vital’s direct account of study, and the purpose of commandments. Did not attribute an unverified Mishnat Chasidim transcription as a direct quotation.',
195:'Both editions read in full. Preserved all native quotations, especially the limitation of the exemption from interrupting Torah study to Rabbi Shimon ben Yochai and his companions. Added the kingship/fear explanation, both needed Avot passages, the Midrash about the communal inheritance of Torah, and both opinions on Rabbi Yehuda HaNasi completing Shema.'
},[
 {'section':191,'observation':'The body’s expansion of the abbreviation before the Isaiah allusion is left untouched. The new source note accurately identifies Rabbi Yose son of Rabbi Chanina in Shabbat 62b.'},
 {'section':193,'observation':'Numbers 1:51 and its existing quotation remain untouched; the additional Numbers 18:7 source supplies the explicit priestly-service restriction.'},
 {'section':194,'observation':'For the teaching reported in the Ari’s name, the new source quotes Turei Zahav’s own recorded attribution and identifies its matzah-specific scope. Shaar HaMitzvot provides a separately verified direct account of exertion in study.'}
])
