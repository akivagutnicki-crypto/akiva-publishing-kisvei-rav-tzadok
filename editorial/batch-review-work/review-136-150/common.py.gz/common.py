import json,re,html,hashlib
from pathlib import Path
HERE=Path(__file__).parent
OUT=HERE.parent
ROOT=OUT.parent
OLD=Path('/workspace/scratch/f85ae98f1669/review-work')
B=ROOT/'site-current/mcp-data/text'
BASE=ROOT/'live-baseline'
def plain(t):
    if isinstance(t,list):t=' '.join(plain(x) for x in t)
    return ' '.join(html.unescape(re.sub('<[^>]*>','',t)).replace('\u200e','').replace('\u200f','').split())
def bare(t):return re.sub('[\u0591-\u05bd\u05bf-\u05c2\u05c4-\u05c5\u05c7]','',plain(t))
def cached(file,ref,*inds):
    p=Path(file)
    if not p.is_absolute():p=OLD/file
    v=json.loads(p.read_text())[ref]
    if 'data' in v:t=v['data']['he']
    elif 'versions' in v:t=next(x['text'] for x in v['versions'] if x.get('language') in ('he','source',None))
    else:raise ValueError((file,ref))
    for i in inds:t=t[i-1]
    return bare(t)
def local(book,ref,lo=0,hi=None):
    r=next(r for r in json.loads((B/f'{book}.json').read_text())['paras'] if r['r']==ref)
    return plain([x[0] for x in r['p'][lo:hi]]) if 'p' in r else plain(r['t'])
def cut(t,a,b=None):
    i=t.index(a)
    return t[i:] if b is None else t[i:t.index(b,i)+len(b)]
def cut_bare(t,a,b=None):
    positions=[i for i,c in enumerate(t) if not re.match('[\u0591-\u05bd\u05bf-\u05c2\u05c4-\u05c5\u05c7]',c)]
    unpointed=''.join(t[i] for i in positions)
    start=unpointed.index(a)
    if b is None:return t[positions[start]:]
    stop=unpointed.index(b,start)+len(b)
    return t[positions[start]:positions[stop] if stop<len(positions) else len(t)]
class Batch:
    def __init__(self,start,pages):self.start=start;self.pages=pages;self.entries=[]
    def add(self,s,id,pi,ref,he,en,ctx,book=None,url=None,anchorEnd=None,sourceFile=None):
        rows=json.loads((BASE/f'{s-1}.json').read_text());r=next(r for r in rows if r.get('n')==1)
        prefix=plain(r['p'][pi][0]);prefix=prefix if anchorEnd is None else prefix[:prefix.index(anchorEnd)+len(anchorEnd)]
        url=url or ('#/read/'+ref.replace(' ','_') if book else 'https://www.sefaria.org/'+ref.replace(' ','_'))
        he=plain(he)
        ev={'ref':ref,'url':url,'he':he,'en':en,'heSha256':hashlib.sha256(he.encode()).hexdigest(),'translation':'Original English translation prepared directly from the original Hebrew or Aramaic source.','coverage':'Complete selected source unit with all qualifications necessary to its meaning.'}
        if book:
            assert he in local(book,ref),(s,id,'not contiguous canonical text')
            ev.update(canonicalReaderRef=ref,canonicalSourceFile=f'mcp-data/text/{book}.json')
        if sourceFile:ev['retrievalCache']=sourceFile
        e={'section':s,'id':id,'rowN':1,'phraseIndex':pi,'heAnchorPrefix':prefix,'heCharOffset':len(prefix),'ref':ref,'url':url,'he':he,'en':en,'context':ctx,'sourceEvidence':[ev],'reviewEvidence':{'pdfPages':self.pages[s],'preserveExisting':True,'status':'verified','dedup':'All destination native and connected quotations compared; no existing complete source passage is replaced or duplicated.','method':'Both supplied editions reviewed; original sources read in context; exact canonical Hebrew prefix checked.'}}
        if book:e['readerRef']=ref
        else:e['openExternal']=True
        self.entries.append(e)
    def save(self,decisions,observations=None):
        catalog=json.loads((ROOT/'site-current/library/connected-ideas/catalog.json').read_text())
        coverage=[]
        for s in range(self.start,self.start+5):
            file=BASE/f'{s-1}.json';rows=json.loads(file.read_text());notes=[n for r in rows for n in r.get('footnotes',[])]
            coverage.append({'section':s,'status':'complete-add-only-review','bothSuppliedEditionsRead':True,'pdfPages':self.pages[s],'existingNativeNumbersPreserved':[n['number'] for n in notes],'existingConnectedSourcesPreserved':[r['targetRef'] for r in catalog['records'] if r.get('originRef','').startswith(f'Tzidkat HaTzadik {s}:')],'baselineSha256':hashlib.sha256(file.read_bytes()).hexdigest(),'additions':sum(e['section']==s for e in self.entries),'decisions':decisions[s]})
        assert len({(e['section'],e['id']) for e in self.entries})==len(self.entries)
        result={'schemaVersion':1,'reviewedSections':list(range(self.start,self.start+5)),'reviewMode':'Add only missing original-source quotations; preserve every existing note and all body text.','entries':self.entries,'coverage':coverage,'observationsNotApplied':observations or [],'sourceVerification':'Each selected original Hebrew or Aramaic source read in context with relevant qualifications; English translated directly. Internal Hebrew uses exact contiguous canonical reader wording. No public attribution to the supplied commentary compilations.','reproducibleBuilder':f'review-work/review-136-150/build-{self.start}-{self.start+4}.py'}
        p=OUT/f'ois-{self.start}-{self.start+4}.json';p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
        print(json.dumps({'proposal':str(p),'entries':len(self.entries),'counts':{s:sum(e['section']==s for e in self.entries) for s in range(self.start,self.start+5)}}))
