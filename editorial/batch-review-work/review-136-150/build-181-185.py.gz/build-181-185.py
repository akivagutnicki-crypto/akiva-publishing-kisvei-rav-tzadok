from common import *

pages={
181:{'neimosA':[553,554,555,556],'integratedB':[14,15,16]},
182:{'neimosA':[556,557,558,559,560,561],'integratedB':[16,17,18,19,20,21]},
183:{'neimosB':[7,8,9,10,11],'integratedB':[21,22,23,24,25]},
184:{'neimosB':[11,12,13,14,15,16],'integratedB':[25,26,27,28,29,30]},
185:{'neimosB':[16,17,18,19,20,21,22,23,24,25],'integratedB':[30,31,32,33,34,35,36,37]},
}
b=Batch(181,pages)
def src(file,ref,*inds):return cached(HERE/file,ref,*inds)
def external(s,id,pi,ref,he,en,ctx,file,**kw):
 b.add(s,id,pi,ref,he,en,ctx,sourceFile='review-work/review-136-150/'+file,**kw)

# 181: the native notes already contain the complete Shevuel narrative and its sequel.
b.add(181,'tzidkat-44-strong-desire-as-a-vessel',1,'Tzidkat HaTzadik 44:1',
 cut_bare(local('tzidkat-hatzadik','Tzidkat HaTzadik 44:1'),'מי שיש לו תשוקה גדולה','תשוקת דרישת האמת.'),
 'One who has a great yearning for bodily desires should not become sad about it, thinking how defective he must be to have such a yearning. On the contrary, he is a vessel prepared for a powerful love and yearning to seek the truth.',
 'Rav Tzadok states the underlying principle earlier: the intensity of a desire can become a capacity for seeking truth. Here he applies that principle to money and explicitly conditions its blessing on returning to God with the whole heart.',book='tzidkat-hatzadik')
external(181,'haggai-silver-and-gold-belong-to-god',8,'Haggai 2:8',src('primary-181a.json','Haggai 2:8'),
 'Mine is the silver and Mine is the gold, declares the Lord of hosts.',
 'This is the biblical wording behind returning the desire for wealth to its source. Shevuel’s appointment becomes service of the One to whom the treasury belongs.', 'primary-181a.json')
b.add(181,'takanat-davids-kingship-from-heaven',9,'Takanat HaShavin 6:20',
 cut_bare(local('takanat-hashavin','Takanat HaShavin 6:20'),'והיינו דענין ציווי התורה במלך','וכטעם ״וישב שלמה על כסא ה׳״'),
 'The Torah’s command concerning a king, that his awe should be upon you, does not mean fear of flesh and blood in its simple sense, for of that it is said, “Who are you that you fear a mortal man?” Rather, an Israelite king’s kingship is drawn from the kingship of Heaven. As is known, the spiritual level of King David, peace be upon him, is the attribute of kingship, for he was attached to God’s attribute of kingship, in the sense of “Solomon sat upon the throne of the Lord.”',
 'This explains why service in David’s treasury can redirect attachment to money toward Heaven: Rav Tzadok understands David’s kingship as an expression of divine kingship.',book='takanat-hashavin')

# 182: missing foundations of Torah as calling God and embodying His attributes.
external(182,'ramban-torah-as-divine-names',2,'Ramban on Genesis, Foreword 14',
 cut(src('primary-181e.json','Ramban on Genesis, Foreword',14),'עוד יש בידינו','מלבד צרופיהן וגימטריאותיהם של שמות.'),
 'We also possess a true tradition that the entire Torah consists of the names of the Holy One, blessed be He, its words being divided into names in another manner. For example, imagine the verse beginning “Bereshit” divided into different words, such as “be-rosh yitbara Elohim”; so it is with the entire Torah, apart from the permutations and numerical values of the names.',
 'Ramban explicitly presents this as an esoteric tradition about the Torah’s letters and their divisions. It supplies the background to Rav Tzadok’s statement that the whole Torah is God’s names; it does not replace the ordinary reading of its narratives and commandments.', 'primary-181e.json',anchorEnd='וְכוּלֵי,')
external(182,'bereshit-rabbah-torah-as-creation-plan',4,'Bereshit Rabbah 1:1',
 cut(src('primary-181a.json','Bereshit Rabbah 1:1'),'דבר אחר אמון, אמן.'),
 'Another interpretation: “amon” means a craftsman. The Torah says: I was the Holy One’s instrument of craftsmanship. Ordinarily, when a mortal king builds a palace, he does not build it from his own ideas but from those of an architect. The architect, in turn, does not build it from his own ideas: he has plans and notebooks by which to know how to make the rooms and the small entrances. So the Holy One, blessed be He, looked into the Torah and created the world. The Torah said, “In the beginning God created.” “Beginning” means Torah, as it says, “The Lord acquired me at the beginning of His way.”',
 'The opening midrash supplies the architectural comparison behind “the pattern of Creation.” Rav Tzadok uses it to connect the Torah with the divine will expressed throughout the created world.', 'primary-181a.json',anchorEnd='שֶׁהוּא דְּפוּס מַעֲשֵׂה בְרֵאשִׁית,')
external(182,'abba-shaul-clinging-through-divine-attributes',8,'Shabbat 133b:6',src('primary-181b.json','Shabbat 133b',6),
 'Abba Shaul says: “And I will glorify Him”—be like Him: just as He is gracious and compassionate, so you should be gracious and compassionate.',
 'The cited ideal of attachment to God’s attributes has a concrete ethical meaning: becoming gracious and compassionate. Rav Tzadok identifies Torah studied in order to act with bringing that divine will into one’s life.', 'primary-181b.json',anchorEnd='וְכוּלֵי",')
external(182,'devarim-rabbah-ten-names-for-prayer',9,'Devarim Rabbah 2:1',
 cut(src('primary-181a.json','Devarim Rabbah 2:1'),'אמר רבי יוחנן עשרה לשונות','ויאנחו בני ישראל מן העבדה ויזעקו וגו\'.'),
 'Rabbi Yoḥanan said: Prayer is called by ten expressions, and these are: an outcry, a cry, a groan, a ringing call, an entreaty, distress, a calling, falling down, intercession, and supplication. An outcry and a cry are indicated by the verse, “The children of Israel groaned from the labor and cried out.”',
 'The midrash explicitly includes shavah, an outcry, among the names of prayer, and grounds it in the cry from Egyptian bondage. This connects the paragraph’s opening description of Torah with its later interpretation of Israel’s cry in Egypt.', 'primary-181a.json')
b.add(182,'likkutei-divine-will-and-egyptian-responsibility',27,'Likkutei Maamarim, Compositions on the Festivals 11:11',
 cut_bare(local('likkutei-maamarim','Likkutei Maamarim, Compositions on the Festivals 11:11'),'שכל דבר הוא מאמתת רצון השם יתברך','לכך נענשו.'),
 'Everything comes from the true will of God; therefore Nebuchadnezzar is called “My servant,” and Assyria “the rod of My anger.” Yet “liability is brought about through one who is liable”: he thinks that he himself is the doer, so that he receives his punishment afterward. Otherwise, he would not deserve punishment, since it is God’s will—as Rambam asks concerning Egypt, when “they will enslave them” had been said beforehand. But because they said, “Who is the Lord?” they themselves were the enslavers, and therefore they were punished.',
 'Rav Tzadok’s parallel treatment preserves the distinction essential here: recognizing divine providence in the exile does not absolve the Egyptians of their chosen oppression. He places their responsibility alongside his interpretation of the exile as an expression of divine will.',book='likkutei-maamarim')

# 183: retain the existing full Doeg, Abraham, and three levels of learning excerpts.
b.add(183,'sefer-hazikhronot-recitation-and-understanding',3,'Sefer HaZikhronot 14:2',
 cut_bare(local('sefer-hazikhronot','Sefer HaZikhronot 14:2'),'אבל יראה שלשונן','לבוא לידי השגה אמיתית;'),
 'It appears, however, that their language and their reading are included in the commandment of Torah study, like one studying Ezekiel’s passage of the Chariot: he is certainly called one who studies Torah, although he understands only the plain narrative. We read the Chariot as the haftarah on Shavuot; although none of us knows the extent of its mysteries, the reader is considered to be studying the words of the Prophets. In the first chapter of Avodah Zarah, concerning the revealed parts of Torah as well, they said: “Let a person recite, even though he does not know what he is saying.” The same applies to its hidden parts: since they are actual words of Torah, even though he does not understand, he has studied Torah. The Ari, our honored teacher Rabbi Yitzḥak of blessed memory, said that the language of the holy Zohar is beneficial to the soul. It seems that the intention is that familiarity with its language helps one arrive at true understanding.',
 'Rav Tzadok distinguishes the value of reading Torah from having already attained its inner meaning. The continuation does not make reading esoteric books obligatory and rejects adopting mystical prayer intentions without understanding them. The positive point relevant here is that faithful recitation can prepare the way for genuine understanding.',book='sefer-hazikhronot')
external(183,'yerushalmi-the-good-of-torah-talk',6,'Jerusalem Talmud Berakhot 9:5:19',
 cut(src('primary-181b.json','Jerusalem Talmud Berakhot 9:5',19),'רבי יונה בשם','ופיטטיא דאוריתא טבין.'),
 'Rabbi Yonah said in the name of Rabbi Yose ben Gezirah: All idle talk is bad, but talk of Torah is good.',
 'The Yerushalmi provides the expression pittatya de-oraita. Rav Tzadok applies it to Torah words that have become natural speech after a person has first labored to bring them into the heart.', 'primary-181b.json',anchorEnd='פִּטְטַיָּא דְּאוֹרַיְיתָא,')
external(183,'avodah-zarah-gods-torah-becomes-his',7,'Avodah Zarah 19a:8',src('primary-181b.json','Avodah Zarah 19a',8),
 'Rava also said: At first it is called by the name of the Holy One, blessed be He, and in the end it is called by the learner’s name, as it says, “His desire is in the Torah of the Lord,” and then, “In his Torah he meditates day and night.”',
 'The change from “the Torah of the Lord” to “his Torah” supplies Rav Tzadok’s language for Torah becoming internal to the learner, so that even apparently effortless speech can express it.', 'primary-181b.json')
external(183,'shir-hashirim-god-is-israels-heart',12,'Shir HaShirim Rabbah 5:2:1',
 cut(src('primary-181b.json','Shir HaShirim Rabbah 5:2:1'),'אני ישנה מן הגאלה,'),
 'I sleep with respect to redemption, but the heart of the Holy One, blessed be He, is awake to redeem me. Rabbi Ḥiyya bar Abba said: Where do we find the Holy One, blessed be He, called the heart of Israel? From this verse: “God is the rock of my heart and my portion forever.”',
 'The midrash’s identification of God as Israel’s heart explains Rav Tzadok’s association of speech “from the heart” with the Divine Presence speaking through Moses.', 'primary-181b.json')

# 184: direct missing sources and the important nonliteral qualification of 600,000 letters.
b.add(184,'mei-hashiloach-desire-and-diligence',2,'Mei HaShiloach, Volume II, Five Scrolls, Ecclesiastes 5',
 cut_bare(local('mei-hashiloach','Mei HaShiloach, Volume II, Five Scrolls, Ecclesiastes 5'),'טוב שם משמן טוב.'),
 '“A good name is better than good oil.” A name alludes to desire, as explained in many places in the first volume. Thus “David made a name” means diligence and exertion in serving God, as stated in the holy Zohar, Vayera 116b. Good oil signifies clarity and wisdom in Torah. “A good name” thus means that desire and diligence are better than knowledge and wisdom. Just as someone satisfied with one loaf should not envy someone who needs many loaves, a person who studies one chapter all day should not envy a person of broad understanding who studies several chapters. The essential thing is diligence and desire: this is precious before God. How long a person takes to grasp a matter makes no difference to this value. This is “a good name is better than good oil.”',
 'Mei HaShiloach records the teaching alluded to here and gives its practical illustration: the measure of devotion is the learner’s diligence and desire, rather than the number of chapters understood.',book='mei-hashiloach',anchorEnd='(קֹהֶלֶת ז, א)')
external(184,'berakhot-choice-and-fear-of-heaven',7,'Berakhot 33b:23',src('primary-181c.json','Berakhot 33b',23),
 'Rabbi Ḥanina also said: Everything is in the hands of Heaven except fear of Heaven, as it says, “And now, Israel, what does the Lord your God ask of you, except to fear?”',
 'The Talmudic statement locates the demand for reverence in the human response. Rav Tzadok uses it to distinguish the desire and initiative for learning from the understanding received from God.', 'primary-181c.json',anchorEnd='מִיִּרְאַת שָׁמַיִם')
b.add(184,'peri-tzadik-six-hundred-thousand-as-spiritual-correspondence',11,"Peri Tzadik, Ha'Azinu 5:1",
 cut_bare(local('peri-tzadik',"Peri Tzadik, Ha'Azinu 5:1"),'וכל נפש יש לו נר מיוחד','והוא נר שלו נר ה\' נשמת אדם.'),
 'Each soul has its own particular lamp, the human soul, and the Torah too is a lamp: “Torah is light”; “light” means Torah, as stated in Megillah 16b. It is “Your word is a lamp to my foot and a light to my path.” Every Israelite has a share in Torah, which is that person’s lamp. In the wilderness generation the principal number was six hundred thousand souls, corresponding to six hundred thousand letters of Torah, as indicated by the initials of Yisrael: “There are six hundred thousand letters in Torah.” Although the numerical count does not correspond, every letter divides into sparks; this is the Written Torah. Afterward, through the Torah insights for which God renews a teaching each day, as stated in Bereshit Rabbah 49, the souls of Israel multiply. This is our request, “Give us our share in Your Torah”: every Israelite has a share in Torah, which is that person’s lamp—“The human soul is the lamp of the Lord.”',
 'Rav Tzadok explicitly acknowledges that six hundred thousand is not the ordinary count of written letters. His explanation is a spiritual correspondence between souls, letters, and the sparks within letters; this qualification clarifies the expression used here.',book='peri-tzadik')
external(184,'bereshit-rabbah-changing-angelic-names',16,'Bereshit Rabbah 78:4',src('primary-181c.json','Bereshit Rabbah 78:4'),
 '“Jacob asked and said: Tell me your name.” Rav said in the name of Rabbi Yose bar Dostai: One verse says, “He counts the number of the stars; He calls them names,” and another says, “He brings out their host by number; He calls them all by name.” This teaches that the name changes: the name by which one is called now is not the name by which one is called later, as it says, “The angel of the Lord said to him: Why do you ask my name, since it is wondrous?” He does not know to which name he will change.',
 'The midrash explicitly describes changing names. Rav Tzadok reads this change in relation to an angel’s changing mission, contrasting that dependence with the human experience of a stable identity and choice.', 'primary-181c.json')
external(184,'rashi-renaming-as-an-expression-of-rule',17,'Rashi on II Chronicles 36:4:1',src('primary-181c.json','Rashi on II Chronicles 36:4',1),
 '“He changed his name to Jehoiakim.” Such is the way of kings and rulers: they give their servants whatever name they wish. Examples are “Pharaoh called Joseph’s name,” “Moses called Hoshea son of Nun Joshua,” and “The chief of the eunuchs gave them names.” All this is to show that he rules over him, naming him as he wishes.',
 'Rashi’s commentary supplies the explicit explanation of imposed names as a sign of a ruler’s authority. Rav Tzadok uses that relationship as an analogy for creatures whose agency is wholly dependent on their sender.', 'primary-181c.json')
external(184,'taanit-oil-and-vinegar',18,'Taanit 25a:5',src('primary-181c.json','Taanit 25a',5),
 'One Sabbath eve he saw his daughter looking sad. He said to her: “My daughter, why are you sad?” She replied: “I confused a container of vinegar with a container of oil and lit the Sabbath lamp from it.” He said: “My daughter, why should that trouble you? The One who told oil to burn will tell vinegar to burn.” It was taught: It continued burning all that day, until they took from it a flame for Havdalah.',
 'The story concerns Rabbi Ḥanina ben Dosa. Its saying supplies Rav Tzadok’s example of seeing a thing’s activity as dependent on God’s command, even when ordinary natural distinctions appear decisive.', 'primary-181c.json',anchorEnd='יֹאמַר לַחֹמֶץ וְיִדְלַק,')

# 185: add the missing portions of Berakhot without duplicating the existing one-person passage.
external(185,'berakhot-hezekiah-and-hidden-outcomes',6,'Berakhot 10a:28-29',
 src('primary-181d.json','Berakhot 10a',28)+' '+src('primary-181d.json','Berakhot 10a',29),
 'Hezekiah said to him: “Why so severe a judgment?” Isaiah said: “Because you did not engage in procreation.” Hezekiah replied: “Because I saw through the holy spirit that unworthy children would come from me.” Isaiah said: “What have you to do with the Merciful One’s hidden matters? You must do what you were commanded, and let the Holy One, blessed be He, do what is pleasing to Him.”',
 'The phrase about God’s hidden matters originally concerns Hezekiah’s refusal to have children because he foresaw their wrongdoing. Rav Tzadok applies the same distinction to teaching: an uncertain future outcome does not cancel the present duty to teach and to judge unknown conduct favorably.', 'primary-181d.json')
external(185,'sefer-yetzirah-end-bound-to-beginning',13,'Sefer Yetzirah 1:7',src('primary-181d.json','Sefer Yetzirah 1:7'),
 'Ten sefirot of nothingness: their end is embedded in their beginning and their beginning in their end, like a flame bound to a coal. For the Master is one and has no second; before One, what can you count?',
 'The image explains the return of the end to the beginning. Rav Tzadok applies it to the discovery that even the learner’s initial desire and power of choice were given by God.', 'primary-181d.json',anchorEnd='נָעוּץ סוֹפָן בִּתְחִלָּתָן')
external(185,'psalm-146-help-and-hope-in-god',15,'Psalms 146:5',src('primary-181e.json','Psalms 146:5'),
 'Happy is the one whose help is the God of Jacob, whose hope is in the Lord his God.',
 'The complete verse joins help with hope. Rav Tzadok reads this blessing, following the warning against relying on mortal patrons, as the learner’s recognition that God supplies the help through which Torah endures.', 'primary-181e.json',anchorEnd='(שָׁם, ה)')
external(185,'berakhot-two-learners-and-the-book-of-remembrance',22,'Berakhot 6a:14',src('primary-181d.json','Berakhot 6a',14),
 'Since this is true even of one person, is it necessary to say it of two? The words of two are written in the book of remembrance; the words of one are not written in the book of remembrance.',
 'The preceding discussion affirms the Divine Presence even with one person studying. This passage adds the particular distinction of two learners, “their words are written,” which Rav Tzadok interprets as Torah becoming durably impressed upon their souls.', 'primary-181d.json',anchorEnd='מִילַּיְיהוּ",')
b.add(185,'likkutei-the-soul-as-divine-writing',22,'Likkutei Maamarim, Compositions on the Festivals 8:2',
 cut_bare(local('likkutei-maamarim','Likkutei Maamarim, Compositions on the Festivals 8:2'),'וכמו כשאדם עוסק בדברי תורה בדבור','נוצרים נפשות.'),
 'Just as, when a person engages in Torah through speech, the Holy One, blessed be He, sits and engages in it opposite him, as the Sages say in Tanna de-Vei Eliyahu Rabbah 18, so when he writes words of Torah, the Holy One writes them as well. God’s writing means the coming into being of souls—for example, the Written Torah, whose letters are the roots of the souls of Israel, as is known. So too all writing of the Oral Torah reveals what is concealed in the Written Torah. All souls consist of letters, and a person’s deeds, in commandments and transgressions, change their combination, as explained in Raavad’s commentary to Sefer Yetzirah at the beginning of chapter 3, concerning the three books of the wholly righteous and the others; see there. Through those letters written by the hand of the Holy One, souls are formed.',
 'This parallel explains the mystical meaning of a heavenly book as the souls themselves. It is quoted as Rav Tzadok’s explanation in Likkutei Maamarim, including his attribution to the commentary on Sefer Yetzirah, rather than as an independently verified quotation from that commentary.',book='likkutei-maamarim')
external(185,'rambam-teacher-of-equal-or-lesser-learning',26,'Rambam on Pirkei Avot 1:6:1',
 cut(src('primary-181d.json','Rambam on Pirkei Avot 1:6',1),'עשה לך רב.','וכן בארו בפירוש זאת המצוה.'),
 '“Make yourself a teacher.” This means: even if he is not fit to be your teacher, appoint him as your teacher until you regard him as one who teaches, and through this you will gain the study of wisdom. A person’s learning alone is not like learning from another. Learning alone is good, but learning from another remains with him more firmly and is clearer, even if the other is equal to him in wisdom or below him. This is how they explained this instruction.',
 'Rambam makes the intended limitation explicit: the person may be equal or inferior in learning and still help one learn. “Not fit to be your teacher” here concerns scholarly rank; this passage does not authorize choosing a morally corrupt teacher.', 'primary-181d.json',anchorEnd='הָרַמְבַּ"ם שָׁם,')
external(185,'berakhot-judgment-and-the-presence-that-precedes-ten',34,'Berakhot 6a:15-16',
 src('primary-181d.json','Berakhot 6a',15)+' '+src('primary-181d.json','Berakhot 6a',16),
 'Since this is true even of two, is it necessary to say it of three? One might have thought that judgment merely makes peace and that the Divine Presence does not come; this teaches that judgment too is Torah. Since this is true even of three, is it necessary to say it of ten? With ten, the Divine Presence arrives beforehand; with three, only once they sit.',
 'The Talmud distinguishes two learners, a court of three, and a gathering of ten. Rav Tzadok develops a spiritual sequence from these distinctions, culminating in the Presence preceding the group. The Talmud’s immediate discussion of ten concerns communal prayer; applying its pattern to a teacher and disciples is his interpretation.', 'primary-181d.json',anchorEnd='וְאָתְיָא,')

b.save({
181:'Both editions read in full. Preserved the already quoted Shevuel narratives, generosity verse, hospitality passage, and Resisei Layla parallel; added the earlier Tzidkat principle, Haggai verse, and direct account of David’s kingship.',
182:'Both editions read in full. Preserved the extensive native Torah/prayer, Zohar, and Egyptian-labor sources and the connected Tanya passage. Added five missing foundations, retaining the Egyptian agents’ moral responsibility in the parallel discussion.',
183:'Both editions read in full. Preserved the complete existing quotations concerning ordinary speech, Abraham, Doeg, and the three levels of study. Added four missing sources; the Sefer HaZikhronot context retains its distinction between recitation and attained understanding.',
184:'Both editions read in full. Preserved the native youthful/elderly sages, teachers/friends/students, naming, and blessing sources, and the Resisei Layla parallel. Added six direct gaps, including Rav Tzadok’s explicit qualification of the six-hundred-thousand-letter expression.',
185:'Both editions read in full. Preserved all existing Avot, Tosafot Yom Tov, Nedarim, memory, charity, and public-lecture notes. Added seven missing quotations, with Rambam’s scholarly-rank qualification and the original context of the ten-person discussion.'
},[
 {'section':185,'observation':'Existing body expansions of abbreviations as Shammai are not modified. Existing notes already clarify the Psalm and Sukkah attributions.'},
 {'section':185,'observation':'Existing note 1180 already clarifies Bava Batra 12b as a public lecture/assembly; no duplicate quotation or body change added.'},
 {'section':182,'observation':'Ramban’s relevant source is the Foreword, paragraph 14, not the separate six-paragraph introductory poem; the exact node was verified from the source index.'},
 {'section':181,'observation':'Edition boundary verified: Neimos A contains 181–182; Neimos B begins with 183. Integrated B begins with 181. Only the restored actual 525-page Integrated B cache was used.'}
])
