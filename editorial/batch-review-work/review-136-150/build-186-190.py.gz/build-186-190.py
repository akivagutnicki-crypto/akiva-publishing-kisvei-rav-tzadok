from common import *

pages={
186:{'neimosB':list(range(25,33)),'integratedB':list(range(37,44))},
187:{'neimosB':list(range(33,37)),'integratedB':list(range(43,48))},
188:{'neimosB':list(range(36,43)),'integratedB':list(range(47,53))},
189:{'neimosB':list(range(42,46)),'integratedB':list(range(52,57))},
190:{'neimosB':list(range(45,49)),'integratedB':list(range(56,60))},
}
b=Batch(186,pages)
def src(file,ref,*inds):return cached(HERE/file,ref,*inds)
def external(s,id,pi,ref,he,en,ctx,file,**kw):
 b.add(s,id,pi,ref,he,en,ctx,sourceFile='review-work/review-136-150/'+file,**kw)

# 186: complementary learning, its limits, and the sources of the threefold pattern.
external(186,'rashi-received-wisdom-and-derived-understanding',1,'Rashi on Proverbs 4:7:1',src('primary-186a.json','Rashi on Proverbs 4:7',1),
 '“The beginning of wisdom: acquire wisdom.” At the beginning of your wisdom, learn from others; acquire a teaching from the mouth of a teacher. Afterward, “with all your acquisitions, acquire understanding”: consider it on your own, to understand the reasons, deriving one matter from another.',
 'Rashi distinguishes received teaching from the understanding developed through reflection. This supplies the distinction between chochmah and binah that Rav Tzadok applies to learning from a teacher and learning with companions.','primary-186a.json')
external(186,'berakhot-the-zimmun-proposal-is-not-the-conclusion',3,'Berakhot 48a:2',src('primary-186d.json','Berakhot 48a',2),
 'The halakhah does not follow any of these teachings, but rather this statement of Rav Naḥman: A minor who knows to whom the blessing is addressed may be included in a zimmun.',
 'This is the conclusion of the discussion that includes the proposal to count two scholars who sharpen one another as three. Rav Tzadok develops the spiritual meaning of that proposal; the Talmud does not accept it as the practical rule for a two-person zimmun. Its concluding statement turns instead to the qualified case of a minor.','primary-186d.json',anchorEnd='(מז:)')
external(186,'maharal-the-middle-unites-opposites',6,'Derekh Chayyim 3:3:9',
 cut(src('primary-186j.json','Derekh Chayyim 3:3:9'),'ושני דברים שהם הפכים'),
 'Take two opposite things, such as black and white, and introduce a third color, such as red. This color is intermediate: it is neither black nor white, but stands between them. Through it the two opposites are joined, because it is between them. Thus, through the third, they have a connection.',
 'Maharal’s example makes the threefold structure explicit: the third supplies a middle that connects the two extremes. Rav Tzadok applies this pattern to distinct minds joining in study and at a meal.','primary-186j.json',anchorEnd='וְאֶמְצָעִי הַמְחַבֵּר,')
external(186,'rambam-the-shofar-awakens-sleepers',13,'Mishneh Torah, Repentance 3:4',
 cut(src('primary-186a.json','Mishneh Torah, Repentance 3:4'),'אף על פי','ומחשבתו אשר לא טובה.'),
 'Although sounding the shofar on Rosh Hashanah is a decree of Scripture, it contains an allusion: Awake, sleepers, from your sleep; slumberers, arise from your slumber. Examine your deeds, return in repentance, and remember your Creator. You who forget the truth amid the vanities of the times and wander all year in emptiness that neither benefits nor saves: look to your souls, improve your ways and deeds, and let each of you abandon his evil path and his thought that is not good.',
 'Rambam first preserves the shofar’s status as a scriptural command and then explains its call to awakening. Rav Tzadok uses that call as the preparation preceding the unity and joy of Sukkot.','primary-186a.json',anchorEnd='עוּרוּ יְשֵׁנִים וְכוּלֵי,')
external(186,'zohar-responsibility-in-new-torah-teachings',18,'Zohar, Introduction 11:71',src('primary-186f.json','Zohar, Introduction 11:71'),
 'Rabbi Shimon said to the companions: I beg you not to bring from your mouths a word of Torah that you do not know and have not properly heard from a great tree, so that you do not cause that sinner to kill multitudes of people for nothing. They all began and said: May the Merciful One save us; may the Merciful One save us.',
 'The great tree is the image of an authoritative teacher. The warning follows the Zohar’s symbolic account of someone unfamiliar with Torah’s mysteries inventing teachings without properly understanding them. It supplies the reverent caution required alongside the creativity that Rav Tzadok praises.','primary-186f.json')
external(186,'avot-enduring-disagreement-for-heaven',20,'Pirkei Avot 5:17',src('primary-186a.json','Pirkei Avot 5:17'),
 'Every dispute that is for the sake of Heaven will endure; one that is not for the sake of Heaven will not endure. What is a dispute for the sake of Heaven? The dispute of Hillel and Shammai. What is one that is not for the sake of Heaven? The dispute of Korah and his entire company.',
 'The Mishnah supplies both the positive example and its contrasting case. Rav Tzadok’s praise concerns disagreement directed toward Heaven, with the humility and sincerity specified immediately before it.','primary-186a.json',anchorEnd='סוֹפָהּ לְהִתְקַיֵּים,')

# 187: books as teachers, divine knowledge, and the initiative described as motherhood.
b.add(187,'tzidkat-236-torah-supports-a-person-in-decline',1,'Tzidkat HaTzadik 236:1',
 cut_bare(local('tzidkat-hatzadik','Tzidkat HaTzadik 236:1'),'ועיקר סמיכת נופלים','ועל ידי זה נסמך.'),
 'The chief support for those who fall from their spiritual level is through words of Torah, which give strength and sound wisdom. This occurs through truthful speech recognizing God’s greatness, even when a person is utterly distant from Him. Such is Torah study: it is not like standing before the King. It is therefore possible even at a time of falling and distance, and through it the person is supported.',
 'In his later explanation Rav Tzadok describes Torah as a source of strength even when one cannot feel close to God. This develops the meaning of the divine help identified here with the Torah that illuminates the learner.',book='tzidkat-hatzadik')
external(187,'shevut-yaakov-books-as-teachers',6,'Shevut Yaakov 2:64',
 cut(src('primary-187-shevut.json','Shevut Yaakov 2:64'),'וכבר אמרו חז"ל אסור','בלתי עיון תחלה בספר'),
 'The Sages have already said that a student may not issue a ruling in his teacher’s place unless he is three parasangs away. All the more so, since our teachers are the books that have spread among Israel, it is fitting for everyone qualified to issue rulings not to give any ruling without first consulting a book.',
 'Shevut Yaakov rebukes a hasty ruling that declared an animal forbidden without first checking the books, stressing care for another person’s financial loss. The quoted comparison of books to teachers is the precise passage Rav Tzadok invokes.','primary-187-shevut.json',url='https://wiki.jewishbooks.org.il/mediawiki/wiki/שבות_יעקב/ב/סד')
external(187,'rambam-god-and-divine-knowledge-are-one',11,'Mishneh Torah, Foundations of the Torah 2:10',
 cut(src('primary-186f.json','Mishneh Torah, Foundations of the Torah 2:10'),'הקדוש ברוך הוא מכיר','להכירו על בריו.'),
 'The Holy One, blessed be He, recognizes His own reality and knows it as it is. He does not know through knowledge outside Himself, as we do, for we and our knowledge are not one. But the Creator, blessed be He, His knowledge, and His life are one in every respect and in every manner of unity. Were He alive through a life outside Himself and knowing through a knowledge outside Himself, there would be many divinities: He, His life, and His knowledge. This is not so; He is one in every respect and in every manner of unity. Thus He is the knower, the known, and knowledge itself—all are one. The mouth has no power to state this, the ear to hear it, or the human heart to comprehend it clearly.',
 'Rambam supplies a related account of divine knowledge as inseparable from God, while explicitly acknowledging the limits of human understanding. This helps explain the premise behind Rav Tzadok’s language of Torah and God as one; it is not a claim that human knowledge has the same kind of unity.','primary-186f.json',anchorEnd='חַד,')
b.add(187,'resisei-human-awakening-and-my-mother',15,'Resisei Layla 53:3',
 cut_bare(local('resisei-layla','Resisei Layla 53:3'),'וראשית דישראל','כמו שהוא מתעורר.'),
 'Israel’s beginning is God, “for You are our Father.” Yet the Sages said: He did not cease loving her until He called her “My mother.” This has the meaning of “Ascribe strength to God”: God’s will was that a person’s awakening from below should give birth to an awakening above. It is as though the person were the beginning and the mother who gives birth to the awakening above that follows, so that above is awakened in accordance with the person’s awakening.',
 'Rav Tzadok directly connects the name “My mother” with “Ascribe strength to God.” The maternal image describes the human initiative that, by God’s own will, calls forth a response from above.',book='resisei-layla')

# 188: the unquoted clauses in Shabbat and the missing Zohar image.
external(188,'rashi-gathering-to-learn-and-the-basic-teaching',2,'Rashi on Shabbat 63a:25:1-2',src('primary-186g.json','Rashi on Shabbat 63a:25'),
 '“Madgilin”: They gather one another and say, “Come, let us learn and understand between the two of us, since we have no teacher to teach us.” “The form”: They have learned a little of the root of the matter from their teacher.',
 'Rashi’s own comments in Shabbat explain both the gathering and the prerequisite of knowing the basic teaching. This adds the direct wording alongside the existing Tosafot discussion of Rashi’s interpretation.','primary-186g.json',anchorEnd='לְפֵירוּשׁ רַשִּׁ"י,')
external(188,'proverbs-the-heart-answers-the-heart',8,'Proverbs 27:19',src('primary-186g.json','Proverbs 27:19'),
 'As water reflects face to face, so the human heart reflects one person to another.',
 'The verse supplies the image of reciprocal response. Rav Tzadok uses it to explain why the learners’ generous effort to gather, despite their limitations, calls forth love.','primary-186g.json')
external(188,'shabbat-the-cost-of-failing-to-listen',14,'Shabbat 63a:24',src('primary-186f.json','Shabbat 63a',24),
 'If they do not do so, they cause the Divine Presence to depart from Israel, as it says, “Flee, my beloved, and be like…”',
 'This is the continuation of the preceding teaching about two scholars who listen to one another. It supplies the negative clause alluded to here, while the existing note quotes the positive promise that God hears their voice.','primary-186f.json',anchorEnd='"אִם אֵין עוֹשִׂין וְכוּלֵי",')
external(188,'zohar-talmudic-debate-as-the-brides-ornaments',21,'Zohar, Ki Teitzei 1:20',
 cut(src('primary-186i.json','Zohar, Ki Teitzei 1',20),'ועבדו לה כמה גדרין','בזמנא דתיתי לגבה בפורקנא בתרייתא'),
 'They made many fences for her and cut many garments for her, garments of gold, through many rulings. They disputed and raised objections about these rulings, to prepare her through many resolutions and adorn her with many kinds of ornaments for Sabbaths and festivals, so that she would be adorned for you when you come to her at the final redemption.',
 'The bride in this passage represents Torah, particularly its oral development through halakhic rulings. Questions, objections, and their resolutions become her garments and ornaments. This is the Zohar’s image behind Rav Tzadok’s description of Talmudic analysis as bridal adornment.','primary-186i.json',anchorEnd='קִשּׁוּטֵי כַּלָּה')
external(188,'shabbat-distinctive-clothing-away-from-home',21,'Shabbat 145b:15',
 cut(src('primary-186f.json','Shabbat 145b',15),'מפני מה','תותבאי.'),
 'Why are the Torah scholars of Babylonia distinguished by their appearance? Because they are not in their home place. As people say: In my town, my name identifies me; outside my town, my clothing does.',
 'This is Rabbi Yoḥanan’s answer in the discussion, replacing the earlier suggestion that disparaged their learning. The immediate explanation concerns recognition away from home; Rav Tzadok interprets being taken beyond one’s place as a quality of analytical study.','primary-186f.json',anchorEnd='שֶׁאֵינָן בְּנֵי מְקוֹמָן,')

# 189: the exact Zohar distinction and the sources behind the patriarchal inheritance.
external(189,'zohar-patriarchs-and-moses-visible-and-hidden',3,'Zohar, Vaera 2:23',
 cut(src('primary-186j.json','Zohar, Vaera 2:22-23'),'וגוונין דלעילא, סתימין'),
 'The higher colors are concealed and are not seen; no one attained them except Moses. Therefore it is written, “By My name, the Lord, I was not known to them”: I was not revealed to them in the higher colors. And if you say that the patriarchs did not know of them—the patriarchs did know of them, through those that were revealed.',
 'The Zohar distinguishes direct attainment of the concealed level from knowing it through what is revealed. Its final qualification is essential: the patriarchs were not ignorant of the higher level. Rav Tzadok develops this into his distinction between seeing through creation and the knowledge associated with Moses.','primary-186j.json')
b.add(189,'peri-tzadik-rabbi-bunim-on-enough-creation',7,'Peri Tzadik, Vaera 3:1',
 cut_bare(local('peri-tzadik','Peri Tzadik, Vaera 3:1'),'ואומרים בשם','להכרת כבוד מלכותו ית\'.'),
 'It is said in the name of our master Rabbi Bunim, of blessed memory, that he explained “He said to His world: Enough” to mean that this would suffice for the creature to recognize His blessed kingship. The intended purpose of creation is that a person should recognize His kingship, and one can learn from everything that was created. As stated in Eruvin 100b: Had Torah not been given, we would have learned modesty from the cat, the avoidance of theft from the ant, and sexual fidelity from the dove, and so forth. The world continued expanding so that people could recognize His kingship more fully, until the Holy One, blessed be He, told it that no further expansion was needed: the creation already made was sufficient to recognize the glory of His blessed kingship.',
 'Peri Tzadik records Rabbi Bunim’s teaching explicitly and explains its purpose through learning from the creatures. This supplies the fuller account behind the brief attribution here.',book='peri-tzadik')
external(189,'isaiah-creation-meant-to-be-inhabited',8,'Isaiah 45:18',src('primary-186h.json','Isaiah 45:18'),
 'For thus says the Lord, Creator of the heavens—He is God—who formed the earth and made it, who established it: He did not create it as emptiness; He formed it to be inhabited. I am the Lord, and there is no other.',
 'The second half of the phrase, “He formed it to be inhabited,” completes the verse alluded to by “He did not create it as emptiness.” It explains the connection Rav Tzadok draws between creation, continuity, and children.','primary-186h.json')
b.add(189,'divrei-soferim-moses-shines-in-each-generation',14,'Divrei Soferim 10:2',
 cut_bare(local('divrei-soferim','Divrei Soferim 10:2'),'וכן ידוע דברי האר"י','והוא הוא שמאיר בו אורו,'),
 'The Ari’s words concerning the expression in Shabbat 101b and elsewhere, “Moses, you have spoken well,” are well known: each sage of the generation is called Moses. Its plain meaning is that he is like Moses our teacher in his generation and stands in his place. The Zohar in Ekev says that Moses our teacher shines in every generation: that is, in the sage of the generation who is the head of the congregation of Israel in that generation, like Moses our teacher; it is Moses’ own light that shines within him.',
 'Rav Tzadok’s parallel explanation connects the continuing presence of Moses with the Torah sage who leads a later generation. It makes explicit the inheritance of Moses’ light that underlies the statement here.',book='divrei-soferim',anchorEnd='מִיִּשְׂרָאֵל,')
external(189,'mekhilta-the-maidservants-vision-at-the-sea',17,'Mekhilta DeRabbi Yishmael, Tractate Shirah 3:10',
 cut(src('primary-186h.json','Mekhilta DeRabbi Yishmael, Tractate Shirah 3',10),'"זה אלי".','"נפתחו השמים ואראה מראות אלהים."'),
 '“This is my God.” Rabbi Eliezer says: From where do you say that a maidservant saw at the sea what Isaiah and Ezekiel did not see? As it says, “Through the prophets I use likenesses,” and “The heavens opened and I saw visions of God.”',
 'The Mekhilta continues with a parable contrasting uncertainty about a mortal king with Israel’s immediate recognition of God at the sea. The saying concerns the exceptional clarity of that revelation, which Rav Tzadok relates to the whole generation’s readiness for the knowledge of Moses.','primary-186h.json')

# 190: heart, generosity, and the necessary joining of love and fear.
external(190,'rabbeinu-yonah-giving-the-whole-heart',1,'Rabbeinu Yonah on Proverbs 23:26',src('primary-190-yonah.json','Rabbeinu Yonah on Proverbs 23:26'),
 '“My son, give Me your heart, and let your eyes keep My ways.” “To Me”: to fear and love Me. The heart is desire and longing. He therefore warns a person to give the whole heart to Him, blessed be He, for one is obliged to long and desire only for the service of God, and to make one’s worldly desires solely means of serving God. “Let your eyes keep My ways”: the commandments and good deeds.',
 'Rabbeinu Yonah explains the positive direction of the heart and eye: desire is dedicated to divine service, and the eyes attend to commandments and good deeds. This complements the Yerushalmi’s saying already quoted in the reader.','primary-190-yonah.json',url='https://he.wikisource.org/wiki/רבינו_יונה_על_משלי_כג#פסוק_כו')
external(190,'avot-the-good-heart-includes-the-good-eye',10,'Pirkei Avot 2:9',
 cut(src('primary-186h.json','Pirkei Avot 2:9'),'אמר להם, צאו','שבכלל דבריו דבריכם.'),
 'He said to them: Go out and see which is the upright path to which a person should adhere. Rabbi Eliezer said: A good eye. Rabbi Yehoshua said: A good companion. Rabbi Yose said: A good neighbor. Rabbi Shimon said: Seeing what is to come. Rabbi Elazar said: A good heart. He said to them: I prefer the words of Elazar ben Arakh to yours, for your words are included in his.',
 'Rabban Yoḥanan ben Zakkai’s response includes the good eye within the good heart. The Mishnah provides the rabbinic terminology behind Rav Tzadok’s explanation of a generous, unenvious disposition.','primary-186h.json')
external(190,'proverbs-the-stingy-hosts-divided-heart',12,'Proverbs 23:6-7',src('primary-186i.json','Proverbs 23:6-7'),
 'Do not eat the bread of one with an evil eye, and do not desire his delicacies. For as he reckons within himself, so he is. “Eat and drink,” he says to you, but his heart is not with you.',
 'The verses describe a host whose outward invitation conceals inward reluctance to give. Here the evil eye denotes stinginess and begrudging another’s enjoyment, the opposite of the generosity discussed in the preceding sentence.','primary-186i.json')
b.add(190,'kometz-love-and-fear-united-in-one-coin',15,'Kometz HaMinchah 2:23:1',
 cut_bare(local('kometz-haminchah','Kometz HaMinchah 2:23:1'),'וזה שאמרו בבבא קמא','האהבה ויראה.'),
 'This is what they said in Bava Kamma 97a: The coin of Abraham our patriarch had an old man and an old woman on one side, and a young man and a maiden on the other. A coin is something with which one acquires all necessities. Likewise, love and fear are the parents that bring forth all holy qualities, corresponding to jealousy and desire on the side of impurity. Love is familiar in youth, unlike old age: “Desire fails.” As is known, Solomon said the Song of Songs in his youth—the intensity of love—and Ecclesiastes in his old age—the intensity of fear. But Abraham introduced and established this as a current coin: on one coin there should be an old man and an old woman on one side, and a young man and a maiden on the other, all united in complete unity—love and fear.',
 'This parallel explains why the contrast between the qualities of Joseph and his brothers is not the final ideal. Rav Tzadok describes completeness as bringing love and fear together, so that restraint and generosity become parts of one service of God.',book='kometz-haminchah')

b.save({
186:'Both editions read in full. Preserved all native group-of-three, shared-meal, Akedah, and complementary-sage quotations. Added six missing sources, expressly retaining the Talmud’s rejection of the two-scholars zimmun proposal as the practical conclusion and the mystical context of the Zohar warning.',
187:'Both editions read in full. Preserved the existing Torah-as-antidote, Abraham, Rashi on Avot, daughter/sister/mother, and Peri Tzadik quotations. Added four sources, including the original Shevut Yaakov passage verified in its responsum rather than quoting the supplied commentary.',
188:'Both editions read in full. Preserved all four positive Shabbat teachings and their existing qualifications, the public-lecture sources, and the enduring-voice Zohar passages. Added Rashi’s direct comments, the missing negative clause, the reciprocal-heart verse, the bridal-ornaments Zohar, and the unquoted clothing explanation.',
189:'Both editions read in full. Preserved the full burning-palace, expanding-world, Exodus, Rambam, and connected Peri Tzadik sources. Added five missing sources, preserving the Zohar’s qualification that the patriarchs knew the concealed colors through the revealed.',
190:'Both editions read in full. Preserved the complete Yerushalmi, biblical, eye-and-heart, and Isaac sources. Added four missing sources on dedicating desire, the good heart, the stingy host, and joining love with fear; avoided duplicating existing generosity and jealousy verses.'
},[
 {'section':186,'observation':'The Talmudic two-scholars proposal is interpreted spiritually in the body; the new Berakhot 48a note supplies the missing explicit practical qualification without altering the body.'},
 {'section':188,'observation':'The previously quoted Shabbat 145b clause about flowers for Torah is preserved. The new note quotes only the different clause about scholars’ clothing and gives Rabbi Yoḥanan’s answer in context.'},
 {'section':189,'observation':'Zohar Vaera II 23a was resolved to the modern paragraph node 2:23; the returned exact range 2:22–23 and the full chapter were read and cached.'}
])
