import json, hashlib, sys
from pathlib import Path
from common_b import plain, bare, local, ROOT, HERE, BASE

proposal=ROOT/'review-work/ois-211-215.json'
data=json.loads(proposal.read_text())
primary=json.loads((HERE/'primary.json').read_text())
web=json.loads((HERE/'211-215-web-originals.json').read_text())
checked=[]
seen=set()
for e in data['entries']:
    rows=json.loads((BASE/f"{e['section']-1}.json").read_text())
    row=next(r for r in rows if r.get('n')==e['rowN'])
    phrase=plain(row['p'][e['phraseIndex']][0])
    assert phrase.startswith(e['heAnchorPrefix']),e['id']
    assert len(e['heAnchorPrefix'])==e['heCharOffset'],e['id']
    ev=e['sourceEvidence'][0]
    for k in ['ref','url','he','en']:
        assert ev[k]==e[k],(e['id'],k)
    assert ev['heSha256']==hashlib.sha256(e['he'].encode()).hexdigest()
    key=e['section'],e['ref'],bare(e['he'])
    assert key not in seen,e['id']
    seen.add(key)
    if 'readerRef' in e:
        source=ROOT/'site-current'/ev['canonicalSourceFile']
        candidates=[p for p in json.loads(source.read_text())['paras'] if p['r']==e['readerRef']]
        assert candidates,e['readerRef']
        texts=[plain([v[0] for v in p['p']]) if 'p' in p else plain(p['t']) for p in candidates]
        assert any(e['he'] in text for text in texts),e['id']
        assert e['ref']==e['readerRef']==ev['canonicalReaderRef']
        evidence=str(source.relative_to(ROOT))
    elif e['ref'] in web:
        source=web[e['ref']]
        assert e['url']==source['url']
        assert e['he'] in plain(source['he']),e['id']
        assert (HERE/'em-kol-chai-1-31.html').exists()
        evidence='review-work/review121/211-215-web-originals.json#'+e['ref']
    else:
        source=primary[e['ref']]
        assert 'error' not in source,e['ref']
        assert source['ref']==e['ref'],(e['ref'],source['ref'])
        assert bare(e['he']) in bare(source['he']),e['id']
        evidence='review-work/review121/primary.json#'+e['ref']
    for edition,pages in e['reviewEvidence']['pdfPages'].items():
        assert all((ROOT/f'review-work/source-pages/{edition}-{p:03}.txt').exists() for p in pages)
    checked.append({'section':e['section'],'id':e['id'],'ref':e['ref'],'anchor':'pass','sourceQuoteExactContiguous':'pass','sourceEvidence':evidence})
for c in data['coverage']:
    path=BASE/f"{c['section']-1}.json"
    assert c['baselineSha256']==hashlib.sha256(path.read_bytes()).hexdigest()
    assert c['additions']==sum(e['section']==c['section'] for e in data['entries'])
report={'proposal':str(proposal.relative_to(ROOT)),'proposalSha256':hashlib.sha256(proposal.read_bytes()).hexdigest(),'status':'passed','count':len(checked),'checks':checked,'reproducibleCheck':'review-work/review121/check_211_215.py'}
out=HERE/'ois-211-215-audit.json'
out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'passed','count':len(checked),'sha256':report['proposalSha256'],'report':str(out.relative_to(ROOT))}))
