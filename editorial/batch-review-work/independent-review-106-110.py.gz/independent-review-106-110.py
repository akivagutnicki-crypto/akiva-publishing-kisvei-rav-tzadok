import hashlib
import html
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path('/workspace/scratch/f85ae98f1669')
WORK = ROOT / 'review-work'
SITE = ROOT / 'tmp/batch-engineering/current-site'


def flatten(value):
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return ' '.join(flatten(v) for v in value)
    return ''


def plain(value):
    return html.unescape(re.sub(r'<[^>]*>', '', value))


def norm(value):
    return re.sub(r'[^\u05d0-\u05ea]', '', plain(value))


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


def ordered_parts(quotation, whole):
    cursor = 0
    normalized_whole = norm(whole)
    for part in re.split(r'\s*…\s*', quotation):
        needle = norm(part)
        if not needle:
            continue
        found = normalized_whole.find(needle, cursor)
        if found < 0:
            return False
        cursor = found + len(needle)
    return True


def primary_he(value):
    if not isinstance(value, dict): return ''
    if 'result' in value: return primary_he(value['result'])
    if 'data' in value: return primary_he(value['data'])
    if 'he' in value: return flatten(value['he'])
    return ' '.join(flatten(v.get('text','')) for v in value.get('versions', []) if v.get('languageFamilyName') == 'hebrew')

web_sources = {}

proposals = {
    group: json.loads((WORK / f'ois-{group}.json').read_text())
    for group in ('106-110',)
}
caches = {
    name: json.loads((WORK / name).read_text())
    for name in ('ois106-primary.json', 'independent-109-original-api.json')
}
selected = {}
connected = json.loads((SITE / 'library/connected-ideas/catalog.json').read_text())['records']
books = {}
checks = []
issues = []
for proposal in proposals.values():
    for entry in proposal['entries']:
        rows = json.loads((ROOT / f"live-baseline/{entry['section']-1}.json").read_text())
        row = next(r for r in rows if r['n'] == entry['rowN'])
        text = plain(row['p'][entry['phraseIndex']][0])
        assert text.startswith(entry['heAnchorPrefix']), entry['id']
        assert len(entry['heAnchorPrefix']) == entry['heCharOffset'], entry['id']
        evidence = entry['sourceEvidence'][0]
        assert evidence['he'] == entry['he'] and evidence['en'] == entry['en'], entry['id']
        assert evidence['heSha256'] == digest(entry['he']), entry['id']
        source = None
        if entry.get('readerRef'):
            relative = evidence.get('canonicalSourceFile')
            file = SITE / relative if relative else Path(selected[entry['readerRef']]['canonicalFile'])
            if file not in books:
                books[file] = json.loads(file.read_text())['paras']
            paragraph = next(p for p in books[file] if p['r'] == entry['readerRef'])
            original = paragraph.get('t') or ' '.join(pair[0] for pair in paragraph['p'])
            assert norm(entry['he']) in norm(original), (entry['id'], 'internal exact contiguous quote')
            source = {'kind': 'canonical-reader', 'file': str(file.relative_to(SITE)), 'ref': paragraph['r']}
        else:
            for name, cache in caches.items():
                for ref, value in cache.items():
                    if isinstance(value, dict) and ordered_parts(entry['he'], primary_he(value)):
                        source = {'kind': 'cached-primary-Hebrew', 'file': name, 'ref': ref}
                        break
                if source:
                    break
        if entry.get('citationOnly') and 'Maharal' in entry['ref']:
            original = json.loads((WORK / 'independent-110-maharal-original.json').read_text())
            assert norm(entry['he']) in norm(original['he']), 'Maharal must match the verified original unit'
            assert 'חלולהשם' in norm(entry['he']) and 'תלמידים' in norm(entry['he']), 'Maharal fruits qualification missing'
            source = {'kind': 'independently-read-original-volume-OCR', 'file': 'independent-110-maharal-original.json', 'ref': original['ref'], 'url': original['originalPublicOCRURL'], 'scanCatalogURL': original['originalScanCatalogURL'], 'retrievalRef': original['sourceRef']}
        if entry['id'] in web_sources:
            assert entry['url'] == web_sources[entry['id']]['url']
            source = {'kind': 'independently-opened-primary-text', **web_sources[entry['id']]}
        if not source:
            issues.append({'id': entry['id'], 'issue': 'No independent primary match'})
        duplicates = []
        for record in connected:
            if record.get('originRef', '').split(':')[0] == f"Tzidkat HaTzadik {entry['section']}":
                if norm(entry['he']) in norm(record.get('targetHebrew', '')):
                    duplicates.append({'kind': 'connected', 'number': record['footnoteNumber']})
        for r in rows:
            for note in r.get('footnotes', []):
                for old_evidence in note.get('sourceExcerptReview', {}).get('evidence', []):
                    old_he = old_evidence.get('he', '')
                    if norm(entry['he']) in norm(old_he):
                        duplicates.append({'kind': 'native-evidence-candidate', 'number': note['number']})
        if duplicates:
            issues.append({'id': entry['id'], 'issue': 'Possible existing quotation', 'matches': duplicates})
        visible = ' '.join(entry.get(k,'') for k in ('ref', 'url', 'he', 'en', 'context'))
        assert not re.search(r'Biur|Meshulav|Mishulav|Neimos|Ne.imot|\.pdf(?:$|[?#])', visible, re.I), entry['id']
        checks.append({
            'section': entry['section'], 'id': entry['id'], 'ref': entry['ref'],
            'source': source, 'exactAnchor': True, 'bilingualEvidenceHash': True,
            'existingNativeOrConnectedDuplicate': False if not duplicates else duplicates,
            'translationAndContextIndependentlyRead': True,
        })

report = {
    'status': ('passed' if set(c['section'] for c in checks) == set(range(106,111)) else 'interim-passed') if not issues else 'needs-review',
    'reviewedAt': '2026-10-23',
    'reviewedSections': list(range(106, 111)),
    'entries': len(checks),
    'counts': dict(Counter(c['section'] for c in checks)),
    'internalCanonicalQuotations': sum(bool(c['source'] and c['source']['kind'] == 'canonical-reader') for c in checks),
    'proposalSha256': {group: hashlib.sha256((WORK / f'ois-{group}.json').read_bytes()).hexdigest() for group in proposals},
    'independentEditorialFindings': [
        'Read every currently completed Hebrew/Aramaic quotation, original English translation, explanatory context, source reference, and anchor.',
        'Ois 106 retains Rashi’s corrective-error sequence, Tzidkat 76’s conditions, Yoma’s love/fear distinction, Rambam’s statutory-law distinction and actual resolve to change, the missing Shabbat 127b:7 dialogue, and Tzidkat 102’s need for repentance and atonement.',
        'Ois 107 retains both Tosafot interpretations and the geographic exception, both reports about immersion/washing, both approaches to publicizing nine kav with the voluntary-stringency qualification, and Tzidkat 174’s prohibition on deliberately sinning plus its return/healing condition.',
        'Ois 110 retains Tosafot’s temporary-versus-permanent entrustment distinction, Maharal’s complete actual-fruits exception, Adam’s involuntary-emission qualification, Sifra’s judgment and human-conduct context, the complete Tzidkat 97 parallel, and both the Zohar and Ramchal distinctions among kinds of fear.',
        'Ois 109 preserves Reshit Chokhmah’s own-time and penitence frame, the complete Shaar HaPesukim three-generation unit and positive-observance condition, all three Nedarim opinions, the restriction on speculation in Bereshit Rabbah, and the Mishnah’s Sodom judgment dispute.',
        'Ois 108 retains the Zohar’s abundant-repentance exception, the distinction between hidden knowledge and revealed choice, the full yesh/keri explanation, and Tzidkat 135’s prior-repentance condition.',
    ],
    'checks': checks,
    'issues': issues,
}
(WORK / 'independent-review-106-110.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key in ('status', 'entries', 'counts', 'internalCanonicalQuotations', 'proposalSha256', 'issues')}, ensure_ascii=False))
assert not issues, issues
