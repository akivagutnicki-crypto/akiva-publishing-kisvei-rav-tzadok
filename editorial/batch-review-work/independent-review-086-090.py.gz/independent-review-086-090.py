import hashlib
import html
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path('/workspace/scratch/f85ae98f1669')
WORK = ROOT / 'review-work'
SITE = ROOT / 'tmp/batch-engineering/current-site'
PROPOSAL = WORK / 'ois-86-90.json'


def flatten(value):
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return ' '.join(flatten(v) for v in value)
    return ''


def primary_hebrew(value):
    if 'data' in value:
        return primary_hebrew(value['data'])
    if value.get('he'):
        return flatten(value['he'])
    return ' '.join(flatten(v.get('text', '')) for v in value.get('versions', []) if v.get('languageFamilyName') == 'hebrew')


def plain(value):
    return html.unescape(re.sub(r'<[^>]*>', '', value))


def norm(value):
    return re.sub(r'[^\u05d0-\u05ea]', '', plain(value))


entries = json.loads(PROPOSAL.read_text())['entries']
caches = {name: json.loads((WORK / name).read_text()) for name in (
    'primary-86-90.json', 'extra-primary-86-90.json', 'extra-primary-86-90b.json')}
connected = json.loads((SITE / 'library/connected-ideas/catalog.json').read_text())['records']
web_sources = {
    'maharal-possessions-and-life': ('turn89view0', 123),
    'rambam-knowledge-and-the-end-of-hostility': ('turn88view1', 113),
    'noam-elimelech-repairing-a-path': ('turn89view1', 145),
    'zohar-torah-israel-and-god-interconnected': ('turn91view0', '136-139'),
}
books = {}
checks = []
issues = []
resolved_evidence_overlaps = []
for entry in entries:
    rows = json.loads((ROOT / f"live-baseline/{entry['section']-1}.json").read_text())
    row = next(r for r in rows if r['n'] == entry['rowN'])
    assert plain(row['p'][entry['phraseIndex']][0]).startswith(entry['heAnchorPrefix']), entry['id']
    assert len(entry['heAnchorPrefix']) == entry['heCharOffset'], entry['id']
    evidence = entry['sourceEvidence'][0]
    assert evidence['he'] == entry['he'] and evidence['en'] == entry['en'], entry['id']
    assert evidence['heSha256'] == hashlib.sha256(entry['he'].encode()).hexdigest(), entry['id']
    normalized = norm(entry['he'])
    source = None
    if entry.get('readerRef'):
        file = SITE / evidence['canonicalSourceFile']
        if file not in books:
            books[file] = json.loads(file.read_text())['paras']
        paragraph = next(p for p in books[file] if p['r'] == entry['readerRef'])
        original = paragraph.get('t') or ' '.join(pair[0] for pair in paragraph['p'])
        assert normalized in norm(original), (entry['id'], 'canonical mismatch')
        source = {'kind': 'canonical-reader', 'file': evidence['canonicalSourceFile'], 'ref': paragraph['r']}
    else:
        for file, cache in caches.items():
            for ref, value in cache.items():
                if normalized in norm(primary_hebrew(value)):
                    source = {'kind': 'cached-primary-Hebrew', 'file': file, 'ref': ref}
                    break
            if source:
                break
        if entry['id'] in web_sources:
            source = {'kind': 'independently-opened-primary-text', 'url': entry['url'],
                      'retrievalRef': web_sources[entry['id']][0], 'line': web_sources[entry['id']][1]}
    if not source:
        issues.append({'id': entry['id'], 'issue': 'primary source not matched'})
    duplicates = []
    for record in connected:
        if record.get('originRef', '').split(':')[0] == f"Tzidkat HaTzadik {entry['section']}":
            if normalized in norm(record.get('targetHebrew', '')):
                duplicates.append({'kind': 'connected', 'number': record['footnoteNumber']})
    for r in rows:
        for note in r.get('footnotes', []):
            if any(normalized in norm(e.get('he', '')) for e in note.get('sourceExcerptReview', {}).get('evidence', [])):
                if note['number'] == 373 and entry['id'] in (
                    'devarim-rabbah-torah-loosens-the-tongue', 'devarim-rabbah-scrolls-and-greek'):
                    # This old note retains the whole Midrash as hidden source
                    # evidence, but visibly quotes only the middle paragraph.
                    expected_visible = 'Devarim Rabbah 1:1: “The Holy One, blessed be He, said: See how precious the language of Torah is, for it heals the tongue. From where? “A healing tongue is a tree of life,” and the tree of life is Torah, as it is said, “It is a tree of life to those who hold fast to it.””'
                    assert note['paragraphs'][0]['text'] == expected_visible
                    assert entry['en'] not in ' '.join(p['text'] for p in note['paragraphs'])
                    resolved_evidence_overlaps.append({
                        'newEntry': entry['id'], 'existingNumber': 373,
                        'finding': 'Whole-primary-paragraph evidence overlap only; the actual existing quotation is the distinct middle paragraph and remains unchanged.',
                        'existingVisibleQuotation': expected_visible,
                    })
                else:
                    duplicates.append({'kind': 'native-evidence-candidate', 'number': note['number']})
    if duplicates:
        issues.append({'id': entry['id'], 'issue': 'possible existing quotation', 'matches': duplicates})
    visible = ' '.join(entry[k] for k in ('ref', 'url', 'he', 'en', 'context'))
    assert not re.search(r'Biur|Meshulav|Mishulav|Neimos|Ne.imot|\.pdf(?:$|[?#])', visible, re.I), entry['id']
    checks.append({'section': entry['section'], 'id': entry['id'], 'ref': entry['ref'], 'source': source,
                   'exactAnchor': True, 'sourceEvidenceHash': True, 'translationAndContextIndependentlyRead': True,
                   'nativeAndConnectedDuplicates': duplicates})

report = {
    'status': 'passed' if not issues else 'needs-review',
    'reviewedAt': '2026-10-23', 'entries': len(checks),
    'counts': dict(Counter(e['section'] for e in entries)),
    'internalCanonicalQuotations': sum(bool(e.get('readerRef')) for e in entries),
    'proposalSha256': hashlib.sha256(PROPOSAL.read_bytes()).hexdigest(),
    'qualificationReview': [
        'All 42 new Hebrew/Aramaic passages, English translations, explanatory contexts, citations, and destination anchors independently read.',
        'Tzidkat 197 includes the present limitation to individuals and future universal realization.',
        'Avodat Yisrael includes Noach\u2019s inability to save the generation and is presented as an earlier quotation of the additional Idra wording.',
        'Sanhedrin 26a context distinguishes the Jerusalem siege from Rav Tzadok\u2019s application.',
        'Mekor Mayim Chayim preserves the stated chain of transmission and repentance leading to redemption.',
        'Rabbeinu Bahya 29:18 includes the involuntary-thought question, sustained preparation, and response to thoughts; context acknowledges additional interpretations.',
        'The two new Devarim Rabbah 1:1 passages supply the opening scrolls/Greek discussion and closing tongue-healing discussion, distinct from the existing middle quotation.',
        'Zohar Chadash retains the difference between the surrounding brightness and inward light.',
        'Tractate Soferim 1:8 preserves the entire transmitted list under the heading thirteen, with the numerical discrepancy explained rather than silently harmonized.',
        'Peri Tzadik Achrei Mot 5 explicitly preserves that the seven disciplines are permitted.',
        'Zohar III 73a uses interconnectedness and concealed/revealed levels; it is not silently rewritten as the later shorthand.',
        'Shelah preserves the root/branch distinction and its context explains the ensuing Levi discussion.',
        'Peri Tzadik HaAzinu 5 explicitly preserves the nonmatching ordinary letter count and its resolution through sparks.',
        'Takanat HaShavin 6:89 preserves the author\u2019s qualification: it appears to me.',
    ],
    'resolvedEvidenceOverlaps': resolved_evidence_overlaps,
    'checks': checks, 'issues': issues,
}
(WORK / 'independent-review-086-090.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: report[key] for key in ('status', 'entries', 'counts', 'internalCanonicalQuotations', 'proposalSha256', 'issues')}))
assert not issues, issues
