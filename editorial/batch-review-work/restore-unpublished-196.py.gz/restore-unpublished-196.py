"""Restore only the rejected local candidate's changes to authenticated preimages."""
import concurrent.futures, hashlib, json, pathlib, shutil, time, urllib.request

ROOT = pathlib.Path(__file__).resolve().parent.parent
SITE = ROOT / 'site-current'
WORK = ROOT / 'review-work'
ARCHIVE = WORK / 'rejected-196-210-candidate'
REPORT = SITE / 'library/tzidkat-batch-review-196-210-20261023.json'
PACK = ROOT / 'akiva-repo/sources/akiva/overlays/tzidkat-batch-review-196-210-20261023.json.gz'
EXPECTED = '8826dde239171cdf1f7fc500389a7e0e1789ff62880ab17ed53a4c5b2617e3f3'
URL = 'https://akivagutnicki-crypto.github.io/akiva-publishing-kisvei-rav-tzadok/'
sha = lambda b: hashlib.sha256(b).hexdigest()
report = json.loads(REPORT.read_text())
assert report['packSha256'] == EXPECTED == sha(PACK.read_bytes())
assert not ARCHIVE.exists(), 'The rejected candidate is already archived; inspect before retrying.'
before = report['baselineFiles']
public_report_path = WORK / '196-preimage-recovery/public-181-195-report.json'
public_report_bytes = public_report_path.read_bytes()
public_report = json.loads(public_report_bytes)
assert public_report['packSha256'] == 'd007449eff89a1fbe118dbd221bfcaab3ab7b47b2db0afde6c2a9a29892c9288'
public_before = dict(public_report['baselineFiles'])
public_before.update({x['path']:{'bytes':x['bytes'],'sha256':x['sha256']} for x in public_report['changedFiles']})
last_report = 'library/tzidkat-batch-review-181-195-20261023.json'
public_before[last_report] = {'bytes':len(public_report_bytes),'sha256':sha(public_report_bytes)}
prior_reports = ['library/tzidkat-batch-review-%03d-%03d-20261023.json' % (n,n+14) for n in range(1,196,15)]
for item in report['changedFiles']:
    name = item['path']
    if name in before and not name.endswith('.zip'):
        assert before[name] == public_before[name], 'Unexpected local/public predecessor difference: ' + name
for item in report['changedFiles']:
    b = (SITE / item['path']).read_bytes()
    assert len(b) == item['bytes'] and sha(b) == item['sha256'], item['path']

def retrieve(item):
    name = item['path']
    if name not in public_before:
        return name, None
    last = None
    for attempt in range(4):
        try:
            req = urllib.request.Request(URL + name, headers={'User-Agent':'Akiva-source-review/1.0'})
            with urllib.request.urlopen(req, timeout=45) as response:
                data = response.read()
            assert len(data) == public_before[name]['bytes'] and sha(data) == public_before[name]['sha256'], 'Public preimage changed: ' + name
            return name, data
        except Exception as exc:
            last = exc
            if attempt < 3:
                time.sleep(0.5 * (2 ** attempt))
    raise last

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    restored = list(pool.map(retrieve, report['changedFiles'] + [{'path':n} for n in prior_reports]))
# Every local successor and public predecessor has been checked before writing.
ARCHIVE.mkdir()
shutil.copy2(PACK, ARCHIVE / PACK.name)
shutil.copy2(str(PACK)+'.sha256', ARCHIVE / (PACK.name+'.sha256'))
shutil.copy2(REPORT, ARCHIVE / REPORT.name)
for name in prior_reports:
    shutil.copy2(SITE / name, ARCHIVE / pathlib.Path(name).name)
for name, data in restored:
    destination = SITE / name
    if data is None:
        destination.unlink()
    else:
        destination.write_bytes(data)
REPORT.unlink()
PACK.unlink()
pathlib.Path(str(PACK)+'.sha256').unlink()
evidence = {'unpublishedCandidateSha256':EXPECTED,'mainStillAt':'037864c383fa0fbc769f3489be48ec1da4f7ff5e','reason':'Verified original source URL was not declared for the reader exact-URL list. Browser test caught the missing link before publication.','restoredFiles':len(restored),'publicPreimagesVerified':True,'allLocalSuccessorHashesVerified':True,'candidatePreserved':str(ARCHIVE.relative_to(ROOT)),'baselineRefresh':'Public archive bytes and all prior release reports replace local reproduction versions. ZIP bytes differ by build metadata; all nonarchive changed-file predecessor seals agree. Full published chain must pass before building the corrected candidate.'}
(WORK/'unpublished-196-210-correction.json').write_text(json.dumps(evidence,indent=2)+'\n')
print(json.dumps(evidence))
